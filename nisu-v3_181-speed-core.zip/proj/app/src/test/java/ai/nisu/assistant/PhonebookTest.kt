package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhonebookTest {
    private fun e(id: String, cat: String, name: String, num: String) = PhonebookRules.Entry(id, cat, name, num)
    private val book = listOf(
        e("1", "friend", "Rahim", "01712345678"),
        e("2", "friend", "Rahim Uddin", "01811111111"),
        e("3", "friend", "Sumon", "+8801911111111"),
        e("4", "mother", "Ammu", "01611111111"),
        e("5", "father", "Baba", "01511111111"),
        e("6", "delivery", "Karim", "01311111111"),
        e("7", "girlfriend", "Nisha", "01411111111")
    )

    @Test fun exactNameWinsOverLongerNames() {
        val r = PhonebookRules.resolve(book, "rahim")
        assertTrue(r is PhonebookRules.Found.One)
        assertEquals("1", (r as PhonebookRules.Found.One).entry.id)
    }

    @Test fun partialNameWithSeveralPeopleIsAmbiguous() {
        val r = PhonebookRules.resolve(book, "rah")
        assertTrue(r is PhonebookRules.Found.Many)
        assertEquals(2, (r as PhonebookRules.Found.Many).entries.size)
    }

    @Test fun relationWordsFindTheCategory() {
        assertEquals("4", ((PhonebookRules.resolve(book, "mom")) as PhonebookRules.Found.One).entry.id)
        assertEquals("5", ((PhonebookRules.resolve(book, "Dad")) as PhonebookRules.Found.One).entry.id)
        assertEquals("6", ((PhonebookRules.resolve(book, "delivery man")) as PhonebookRules.Found.One).entry.id)
        assertEquals("7", ((PhonebookRules.resolve(book, "gf")) as PhonebookRules.Found.One).entry.id)
        assertEquals("4", ((PhonebookRules.resolve(book, "\u0986\u09AE\u09CD\u09AE\u09C1")) as PhonebookRules.Found.One).entry.id)
    }

    @Test fun relationWithManyPeopleIsAmbiguous() {
        assertTrue(PhonebookRules.resolve(book, "friend") is PhonebookRules.Found.Many)
        assertEquals("2", ((PhonebookRules.resolve(book, "friend Rahim Uddin")) as PhonebookRules.Found.One).entry.id)
    }

    @Test fun unknownNameIsNone() {
        assertTrue(PhonebookRules.resolve(book, "Jamal") is PhonebookRules.Found.None)
        assertTrue(PhonebookRules.resolve(emptyList(), "mom") is PhonebookRules.Found.None)
        assertTrue(PhonebookRules.resolve(book, " ") is PhonebookRules.Found.None)
    }

    @Test fun sameNumberTwiceIsOnePerson() {
        val dup = book + e("8", "other", "Rahim", "+8801712345678")   // same phone as entry 1, written with the country code
        assertTrue(PhonebookRules.resolve(dup, "rahim") is PhonebookRules.Found.One)
        assertTrue(PhonebookRules.sameNumber("01712345678", "+880 1712-345678"))
        assertFalse(PhonebookRules.sameNumber("01712345678", "01712345679"))
        assertNotNull(PhonebookRules.problem(book, "friend", "Tanvir", "+8801712345678"))   // already saved as Rahim
    }

    @Test fun motherAndFatherHoldOnlyOneNumber() {
        assertNotNull(PhonebookRules.problem(book, "mother", "Maa", "01999999999"))
        assertNotNull(PhonebookRules.problem(book, "father", "Abbu", "01999999999"))
        assertNull(PhonebookRules.problem(book, "friend", "Tanvir", "01999999999"))     // many allowed
        assertNull(PhonebookRules.problem(book, "mother", "Ammu 2", "01999999999", ignoreId = "4"))   // editing the saved one is fine
        assertNull(PhonebookRules.problem(emptyList(), "mother", "Ammu", "01999999999"))
    }

    @Test fun badInputIsRefused() {
        assertNotNull(PhonebookRules.problem(book, "friend", "", "01999999999"))
        assertNotNull(PhonebookRules.problem(book, "friend", "Tanvir", "123"))
        assertNotNull(PhonebookRules.problem(book, "friend", "Tanvir", "01712345678"))   // number already saved
        assertNotNull(PhonebookRules.problem(book, "nobody", "Tanvir", "01999999999"))
    }

    @Test fun numbersAreCleaned() {
        assertEquals("01712345678", PhonebookRules.cleanNumber("017 1234-5678"))
        assertEquals("+8801712345678", PhonebookRules.cleanNumber(" +880 1712-345678 "))
        assertEquals("01712345678", PhonebookRules.cleanNumber("\u09E6\u09E7\u09ED\u09E7\u09E8\u09E9\u09EA\u09EB\u09EC\u09ED\u09EE"))   // Bengali digits
        assertNull(PhonebookRules.cleanNumber("12345"))
        assertNull(PhonebookRules.cleanNumber("1234567890123456"))
    }

    @Test fun jsonRoundTripKeepsEntriesAndDropsBrokenOnes() {
        assertEquals(book, PhonebookRules.fromJson(PhonebookRules.toJson(book)))
        assertTrue(PhonebookRules.fromJson("not json").isEmpty())
        assertTrue(PhonebookRules.fromJson("""[{"id":"1","cat":"zzz","name":"X","number":"0171"}]""").isEmpty())
    }

    @Test fun noteIsCleanedAndKeptInJson() {
        assertEquals("My elder sister. Call her Apu.", PhonebookRules.cleanNote("  My elder sister.\n  Call   her Apu. "))
        assertEquals(PhonebookRules.MAX_NOTE, PhonebookRules.cleanNote("a".repeat(500)).length)
        val withNote = listOf(e("1", "sister", "Apu", "01712345678").copy(note = "Talk in Bangla, respectful"))
        assertEquals(withNote, PhonebookRules.fromJson(PhonebookRules.toJson(withNote)))
        // an old entry saved before notes existed still loads
        val old = PhonebookRules.fromJson("""[{"id":"1","cat":"friend","name":"Rahim","number":"01712345678"}]""")
        assertEquals("", old[0].note)
    }

    @Test fun promptBlockHasNamesAndNotesButNoNumbers() {
        assertEquals("", PhonebookRules.promptBlock(emptyList()))
        val list = listOf(
            e("1", "sister", "Apu", "01712345678").copy(note = "Elder sister. Talk in Bangla, warm and respectful."),
            e("2", "friend", "Rahim", "01811111111"))
        val b = PhonebookRules.promptBlock(list)
        assertTrue(b.contains("Apu (Sister): Elder sister."))
        assertTrue(b.contains("Rahim (Friend)"))
        assertFalse(b.contains("01712345678"))
        assertFalse(b.contains("01811111111"))
    }

    @Test fun promptBlockIsCutWhenTooLong() {
        val many = (1..200).map { e("id$it", "friend", "Friend number $it", "0171${1000000 + it}").copy(note = "x".repeat(150)) }
        val b = PhonebookRules.promptBlock(many)
        assertTrue(b.length <= PhonebookRules.MAX_PROMPT + 120)
        assertTrue(b.contains("saved_contacts"))
    }
}
