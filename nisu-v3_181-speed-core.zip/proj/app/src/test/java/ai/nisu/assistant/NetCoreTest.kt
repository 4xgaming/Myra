package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test
import java.util.concurrent.TimeUnit

/** v3.181: every feature's client shares one pool / dispatcher, keeps its own time limits, and the pre-compiled patterns behave as before. */
class NetCoreTest {
    @Test fun clientsShareOnePoolButKeepTheirOwnTimeouts() {
        val a = Net.client { connectTimeout(3, TimeUnit.SECONDS) }
        val live = Net.base.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(18, TimeUnit.SECONDS).build()
        assertSame(Net.base.connectionPool, a.connectionPool)
        assertSame(Net.base.connectionPool, live.connectionPool)
        assertSame(Net.base.dispatcher, live.dispatcher)
        assertEquals(3000, a.connectTimeoutMillis)
        assertEquals(0, live.readTimeoutMillis)
        assertEquals(18000, live.pingIntervalMillis)
    }

    @Test fun precompiledPatternsMatchTheOldInlineOnes() {
        assertEquals("a b c", "a  b\t\n c".replace(Rx.SPACES, " "))
        assertEquals("otp [number]", "otp 1234 5678".replace(Rx.NUM4, "[number]"))   // same greedy behaviour as the old inline pattern
        assertEquals("hi", "<p>hi</p>".replace(Rx.HTML_TAG, ""))
        assertEquals("Hello, world!", "Hello , world !".replace(Rx.SPACE_BEFORE_PUNCT, "$1"))
        assertEquals("abc", "a*b#c".replace(Rx.MARKDOWN, ""))
        assertEquals(listOf("আমি", "ভালো"), "আমি, ভালো!".split(Rx.WORD_SPLIT).filter { it.isNotEmpty() })
    }
}
