package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Avatar3dTest {

    @Test
    fun supportedFormatsGlbGltfAndFbxWork() {
        assertTrue(Avatar3dRules.isSupportedFile("anime_girl.glb"))
        assertTrue(Avatar3dRules.isSupportedFile("Sakura_VRM_Model.GLB"))
        assertTrue(Avatar3dRules.isSupportedFile("miku_dance.fbx"))
        assertTrue(Avatar3dRules.isSupportedFile("waifu.FBX"))
        assertTrue(Avatar3dRules.isSupportedFile("character.gltf"))
        assertFalse(Avatar3dRules.isSupportedFile("photo.png"))
        assertFalse(Avatar3dRules.isSupportedFile("song.mp3"))
    }

    @Test
    fun activeRemoveAndOffLifecycle() {
        val m1 = Avatar3dRules.ModelItem("m1", "Sakura Girl", "m1.glb", "glb", 4_200_000L)
        val m2 = Avatar3dRules.ModelItem("m2", "Hinata FBX", "m2.fbx", "fbx", 6_800_000L)
        val cfg = Avatar3dRules.Cfg(on = true, overlayOn = true, activeId = "m1", models = listOf(m1, m2))

        assertTrue(Avatar3dRules.usable(cfg))
        assertEquals("m1", Avatar3dRules.activeModel(cfg)?.id)

        // Removing the active model falls back to the remaining model and stays usable
        val afterFirstRemoved = Avatar3dRules.afterRemove(cfg, "m1")
        assertTrue(Avatar3dRules.usable(afterFirstRemoved))
        assertEquals("m2", Avatar3dRules.activeModel(afterFirstRemoved)?.id)

        // Removing the last model turns 3D mode off cleanly
        val afterAllRemoved = Avatar3dRules.afterRemove(afterFirstRemoved, "m2")
        assertFalse(Avatar3dRules.usable(afterAllRemoved))
        assertNull(Avatar3dRules.activeModel(afterAllRemoved))
    }

    @Test
    fun jsonRoundTripPreservesGlbAndFbxModels() {
        val items = listOf(
            Avatar3dRules.ModelItem("id1", "Anime Girl GLB", "id1.glb", "glb", 123456L),
            Avatar3dRules.ModelItem("id2", "Anime Girl FBX", "id2.fbx", "fbx", 789012L)
        )
        val encoded = Avatar3dRules.encodeModels(items)
        val decoded = Avatar3dRules.decodeModels(encoded)
        assertEquals(2, decoded.size)
        assertEquals("glb", decoded[0].ext)
        assertEquals("fbx", decoded[1].ext)
        assertEquals("Anime Girl GLB", decoded[0].name)
        assertEquals("Anime Girl FBX", decoded[1].name)
    }

    @Test
    fun pinchScaleClampingWorks() {
        assertEquals(Avatar3dRules.MIN_SCALE, Avatar3dRules.clampScale(0.1f))
        assertEquals(Avatar3dRules.MAX_SCALE, Avatar3dRules.clampScale(9.5f))
        assertEquals(1.35f, Avatar3dRules.clampScale(1.35f))
        assertEquals(Avatar3dRules.DEFAULT_SCALE, Avatar3dRules.clampScale(Float.NaN))
    }
}
