package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CallAiVoiceMsgTest {
    @Test fun answerAndDeclineLabelsAreRecognizedInEnglishBanglaAndHindi() {
        assertTrue(CallAiRules.isAnswerLabel("Answer"))
        assertTrue(CallAiRules.isAnswerLabel("Accept call"))
        assertTrue(CallAiRules.isAnswerLabel("উত্তর দিন"))
        assertTrue(CallAiRules.isAnswerLabel("রিসিভ"))
        assertTrue(CallAiRules.isAnswerLabel("स्वीकार करें"))
        assertFalse(CallAiRules.isAnswerLabel("Decline"))
        assertFalse(CallAiRules.isAnswerLabel("End call"))

        assertTrue(CallAiRules.isDeclineLabel("Decline"))
        assertTrue(CallAiRules.isDeclineLabel("Hang up"))
        assertTrue(CallAiRules.isDeclineLabel("কেটে দিন"))
        assertTrue(CallAiRules.isDeclineLabel("अस्वीकार"))
        assertFalse(CallAiRules.isDeclineLabel("Answer"))
    }

    @Test fun videoCallsAreDetectedAndSkipped() {
        assertTrue(CallAiRules.isVideoCallText("Rahim", "Incoming video call"))
        assertTrue(CallAiRules.isVideoCallText("ভিডিও কল", "হোয়াটসঅ্যাপ"))
        assertFalse(CallAiRules.isVideoCallText("Rahim", "WhatsApp voice call"))
    }

    @Test fun resampleTo48kDoublesSampleCountAndPreservesEndpoints() {
        // 4 samples of 16-bit PCM at 24 kHz: [100, 300, 500, 700]
        val pcm24 = ByteArray(8)
        val vals = intArrayOf(100, 300, 500, 700)
        for (i in vals.indices) {
            pcm24[2 * i] = (vals[i] and 0xFF).toByte()
            pcm24[2 * i + 1] = ((vals[i] shr 8) and 0xFF).toByte()
        }
        val (pcm48, rate48) = VoiceMessage.resampleTo48k(pcm24, 24000)
        assertEquals(48000, rate48)
        assertEquals(16, pcm48.size)
        // Last sample should match 700
        val last = ((pcm48[15].toInt() shl 8) or (pcm48[14].toInt() and 0xFF)).toShort().toInt()
        assertEquals(700, last)
    }

    @Test fun shareRulesSkipsSectionHeadersWhenPickingContact() {
        val pick = ShareRules.pick("contact", listOf("Frequently contacted", "Other contacts", "Rahim Contact"))
        assertTrue(pick is ShareRules.Pick.One)
        assertEquals("Rahim Contact", (pick as ShareRules.Pick.One).label)
    }
}
