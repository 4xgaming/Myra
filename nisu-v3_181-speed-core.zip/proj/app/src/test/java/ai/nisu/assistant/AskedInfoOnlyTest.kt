package ai.nisu.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AskedInfoOnlyTest {
    @Test fun timeIsOnlyForTimeQuestions() {
        listOf("what time is it", "কয়টা বাজে", "koyta baje", "আজকে তারিখ কত", "ajke ki bar", "5 ta te alarm dao", "remind me tomorrow", "अभी कितने बजे हैं")
            .forEach { assertTrue(it, AskedInfoOnly.asked("get_time", it)) }
        listOf("tumi ki korcho", "গান চালাও", "open whatsapp", "ভালো আছো", "tell me a story")
            .forEach { assertFalse(it, AskedInfoOnly.asked("get_time", it)) }
    }

    @Test fun phoneInfoIsOnlyForPhoneQuestions() {
        listOf("battery koto percent", "ফোনের চার্জ কত", "ফোনের ইনফরমেশন দেখাও", "phone er sob information", "how much RAM is used", "wifi connected?", "बैटरी कितनी है")
            .forEach { assertTrue(it, AskedInfoOnly.asked("device_info", it)) }
        listOf("ki khobor", "গান চালাও", "tumi khaiso?", "amar sathe kotha bolo", "ভালো আছো")
            .forEach { assertFalse(it, AskedInfoOnly.asked("device_info", it)) }
    }

    @Test fun phoneStatusNeedsAPermissionOrSetupQuestion() {
        assertTrue(AskedInfoOnly.asked("phone_status", "permission thik ache?"))
        assertTrue(AskedInfoOnly.asked("phone_status", "accessibility কাজ করছে না"))
        assertFalse(AskedInfoOnly.asked("phone_status", "tumi ki korcho"))
    }

    @Test fun otherToolsAreNeverJudgedHere() {
        assertTrue(AskedInfoOnly.asked("open_app", "anything"))
        assertFalse("get_time" !in AskedInfoOnly.GUARDED)
    }

    @Test fun theRuleSaysOnlyWhenHeAsks() {
        assertTrue(AskedInfoOnly.RULE.contains("ONLY WHEN HE ASKS"))
        assertTrue(DeviceInfo.NOTE.contains("ONLY WHEN HE ASKS"))
        assertTrue(DeviceInfo.TYPED_NOTE.contains("ONLY WHEN HE ASKS"))
    }
}
