package ai.nisu.assistant

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameAutoPlayTest {
    @Test fun maintenanceIsDisabledAndGameAutoPlayIsUnlocked() {
        assertFalse(GameAutoPlay.MAINTENANCE)
    }

    @Test fun keymapperDefaultKeysAndJsonRoundTripPreserveCoordinates() {
        val defaults = GameKeyMap.parseKeys("")
        assertTrue(defaults.containsKey("start_btn"))
        assertTrue(defaults.containsKey("mode_btn"))
        assertTrue(defaults.containsKey("event_close"))
        assertTrue(defaults.containsKey("joystick"))
        assertTrue(defaults.containsKey("fire"))
        assertTrue(defaults.containsKey("buy_gun1"))

        val updated = LinkedHashMap(defaults)
        val oldFire = updated["fire"]!!
        updated["fire"] = oldFire.copy(x = 0.812f, y = 0.634f)
        val json = GameKeyMap.toJson(updated)
        val restored = GameKeyMap.parseKeys(json)
        assertEquals(0.812f, restored["fire"]!!.x, 0.002f)
        assertEquals(0.634f, restored["fire"]!!.y, 0.002f)
    }

    @Test fun resolveFingerJsonSupportsBothExplicitCoordsAndSymbolicKeyIds() {
        val keys = GameKeyMap.parseKeys("")
        val byKey = JSONObject().put("key", "start_btn").put("duration_ms", 120)
        val spec1 = GameKeyMap.resolveFingerJson(byKey, keys, 1920.0, 1080.0)
        assertNotNull(spec1)
        assertEquals(keys["start_btn"]!!.x, spec1!!.x1, 0.001f)
        assertEquals(keys["start_btn"]!!.y, spec1.y1, 0.001f)
        assertEquals(120L, spec1.durationMs)

        val byPixels = JSONObject().put("x", 960.0).put("y", 540.0)
        val spec2 = GameKeyMap.resolveFingerJson(byPixels, keys, 1920.0, 1080.0)
        assertNotNull(spec2)
        assertEquals(0.5f, spec2!!.x1, 0.01f)
        assertEquals(0.5f, spec2.y1, 0.01f)
    }

    @Test fun fallbackFingersCoverEventCloseLobbyModeSelectBuyCombatAndRematch() {
        val keys = GameKeyMap.parseKeys("")

        // 1. Event / Popup close
        val popupFingers = GameKeyMap.buildFallbackFingers("popup", 0, 3, "clash", "balanced", true, true, keys)
        assertTrue(popupFingers.isNotEmpty())
        assertEquals(keys["event_close"]!!.x, popupFingers.first().x1, 0.001f)

        // 2. Lobby START tap
        val lobbyFingers = GameKeyMap.buildFallbackFingers("lobby", 1, 0, "clash", "balanced", true, true, keys)
        assertEquals(1, lobbyFingers.size)
        assertEquals(keys["start_btn"]!!.x, lobbyFingers.first().x1, 0.001f)

        // 3. Mode select cycle
        val modeFingers0 = GameKeyMap.buildFallbackFingers("mode_select", 0, 0, "cs_rank", "balanced", true, true, keys)
        assertEquals(keys["mode_btn"]!!.x, modeFingers0.first().x1, 0.001f)

        // 4. Clash Squad weapon buy
        val buyFingers = GameKeyMap.buildFallbackFingers("buy", 0, 0, "clash", "balanced", true, true, keys)
        assertTrue(buyFingers.size >= 2)
        assertEquals(keys["buy_gun1"]!!.x, buyFingers.first().x1, 0.001f)

        // 5. Ground active movement + combat
        val groundFingers = GameKeyMap.buildFallbackFingers("ground", 1, 0, "clash", "aggressive", true, true, keys)
        assertTrue(groundFingers.size >= 2)
        // First finger slides joystick forward (y2 < y1) with fast responsive duration (<= 650ms)
        assertTrue(groundFingers.first().y2 < groundFingers.first().y1)
        assertTrue(groundFingers.first().durationMs <= 650L)

        // 6. Post-match result -> Continue / Play Again
        val resultFingers = GameKeyMap.buildFallbackFingers("result", 0, 2, "clash", "balanced", true, true, keys)
        assertTrue(resultFingers.isNotEmpty())
        assertEquals(keys["back_cont"]!!.x, resultFingers.first().x1, 0.001f)
    }

    @Test fun skyAimDetectionAndPitchTrackerPullCameraDownToHorizon() {
        val keys = GameKeyMap.parseKeys("")
        val tracker = GameKeyMap.PitchTracker()

        // Simulate two upward drag-shots that would raise aim toward the sky
        tracker.recordVerticalDrag(-0.08f, isFireDrag = true)
        tracker.recordVerticalDrag(-0.08f, isFireDrag = true)
        assertTrue(tracker.needsPitchDown())

        // Building fallback fingers when looking at sky MUST include a downward right-half camera swipe (y2 > y1)
        val skySense = GameKeyMap.FrameSense(lookingAtSky = true)
        val fingers = GameKeyMap.buildFallbackFingers("ground", 0, 0, "clash", "balanced", true, true, keys, skySense, tracker)
        assertTrue(fingers.size >= 2)
        val camSwipe = fingers[1]
        assertTrue("Expected downward swipe on right camera area (y2 > y1) to pull aim down from sky", camSwipe.y2 > camSwipe.y1 + 0.15f)
        assertFalse(tracker.needsPitchDown())
    }

    @Test fun sanitizeAndLevelFingersClampsUpwardFireDragAndInjectsPitchDownWhenHigh() {
        val keys = GameKeyMap.parseKeys("")
        val fireKp = keys["fire"]!!
        val tracker = GameKeyMap.PitchTracker()
        tracker.forceSkyDetected()

        // AI tries to drag fire steeply upward (y2 = fire.y - 0.25) while camera is already high
        val badFire = GameKeyMap.FingerSpec(fireKp.x, fireKp.y, fireKp.x, fireKp.y - 0.25f, 0L, 500L)
        val sanitized = GameKeyMap.sanitizeAndLevelFingers(listOf(badFire), keys, tracker, GameKeyMap.FrameSense(lookingAtSky = true))

        // 1) Fire finger is no longer dragging up into the sky (y2 >= y1)
        assertTrue(sanitized.first().y2 >= sanitized.first().y1)
        // 2) An automatic downward camera pitch-correction swipe was appended
        assertTrue(sanitized.size >= 2)
        val pitchFix = sanitized.last()
        assertTrue(pitchFix.y2 > pitchFix.y1 + 0.15f)
    }

    @Test fun enemyLockedInFrameSenseTriggersImmediateAimSteerAndFireBurst() {
        val keys = GameKeyMap.parseKeys("")
        val fireKp = keys["fire"]!!
        val enemySense = GameKeyMap.FrameSense(enemyLocked = true, enemyOffsetX = 0.12f, enemyOffsetY = -0.02f, takingDamage = true)

        val combatFingers = GameKeyMap.buildFallbackFingers("ground", 1, 0, "clash", "balanced", true, true, keys, enemySense)
        // Must contain continuous movement + camera steer toward enemy + fire burst
        assertTrue(combatFingers.any { kotlin.math.abs(it.x1 - fireKp.x) < 0.02f && kotlin.math.abs(it.y1 - fireKp.y) < 0.02f })
        assertTrue(combatFingers.any { it.x1 in 0.55f..0.70f && it.x2 > it.x1 }) // steers right toward +0.12 enemyOffsetX
    }

    @Test fun rgbGridAnalyzerDetectsRedEnemyCrosshairAndSkyView() {
        // 1. Test red enemy marker at slightly right of center (x = 60, y = 45 on 100x100 grid)
        val enemySense = GameKeyMap.analyzeRgbGrid(100, 100) { x, y ->
            if (x in 55..65 && y in 42..48) 0xFFE61919.toInt() // vivid red enemy marker
            else 0xFF3A4A38.toInt() // normal terrain
        }
        assertTrue(enemySense.enemyLocked)
        assertTrue(enemySense.enemyOffsetX > 0.02f)
        assertFalse(enemySense.lookingAtSky)

        // 2. Test bright blue sky filling upper viewport
        val skySense = GameKeyMap.analyzeRgbGrid(100, 100) { _, y ->
            if (y <= 60) 0xFF87CEFA.toInt() else 0xFF40483A.toInt()
        }
        assertTrue(skySense.lookingAtSky)
    }
}
