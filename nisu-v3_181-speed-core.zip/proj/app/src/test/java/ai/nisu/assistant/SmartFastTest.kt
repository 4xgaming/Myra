package ai.nisu.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartFastTest {
    @Test fun fastPathReadsTheSmartNoteButNotTheSlowSteadyBlock() {
        val b = Persona.leanBoost("gemini-3.1-flash-live-preview")
        assertTrue(b.contains("SMART AND FAST"))
        assertFalse(b.contains("PHONE CONTROL DISCIPLINE"))
    }

    @Test fun noteStaysShortSoItAddsNoWaiting() {
        assertTrue(Persona.SMART_FAST_NOTE.length < 2200)
        assertTrue(Persona.SMART_FAST_NOTE.contains("send AT ONCE"))   // told to send = sent at once, he is told afterwards
    }

    @Test fun extraFastCanUseTheClipboard() {
        assertTrue("clipboard_set" in Tools.EXTRA_FAST_TOOLS)
        assertTrue("clipboard_get" in Tools.EXTRA_FAST_TOOLS)
        assertTrue("copy_text" in Tools.EXTRA_FAST_TOOLS)
    }

    @Test fun draftIsWrittenFirstAndReadAfter() {
        assertTrue(Persona.SMART_FAST_NOTE.contains("WRITTEN FIRST AND READ AFTER"))
        assertTrue(Persona.SMART_FAST_NOTE.length < 2200)
    }

    @Test fun pictureRequestsCallTheToolFirst() {
        assertTrue(ImageMaker.FAST_NOTE.contains("FIRST action is the tool call"))
        assertTrue(ImageMaker.FAST_NOTE.contains("prompt = that English prompt"))
        assertTrue(ImageMaker.NOTE.contains("PICTURE REQUESTS ARE INSTANT"))
        assertFalse(ImageMaker.FAST_NOTE.contains("$"))
    }

    @Test fun lockAndUnlockAreSeparateAndSilent() {
        val n = Persona.LOCK_NOTE
        assertTrue(n.contains("lock = lock_screen, unlock = unlock_phone"))
        assertTrue(n.contains("SAY NOTHING"))
        assertTrue(n.contains("you can still lock it"))
        assertTrue(Persona.leanBoost("gemini-3.1-flash-live-preview").contains("LOCK AND UNLOCK"))
        assertTrue(Persona.leanBoost("some-other-live-model").contains("LOCK AND UNLOCK"))
        assertFalse(n.contains("$"))
    }
}
