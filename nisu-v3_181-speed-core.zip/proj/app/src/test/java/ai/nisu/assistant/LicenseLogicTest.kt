package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LicenseLogicTest {
    @Test fun keyIsTrimmedAndUpperCasedBeforeHashing() {
        assertEquals("NISU-AAAA", LicenseLogic.normalize("  nisu-aaaa \n"))
        // same bytes as admin-panel.html keyHash(): sha256 of the upper-case key
        assertEquals("b5d4045c3f466fa91fe2cc6abe79232a1a57cdf104f7a26e716e0a1e2789df78", LicenseLogic.hash("abc"))
        assertEquals("3ed7fe76e5a3040057f0b7f2b0e47831db2d71f0c57751b9202e53c6e59c320d", LicenseLogic.hash(" nisu-abcd-efgh-jklm "))
    }

    @Test fun expiry() {
        assertEquals(0L, LicenseLogic.expiresAt(0L, 0L))            // lifetime, never activated
        assertEquals(0L, LicenseLogic.expiresAt(1_000L, 0L))        // lifetime
        assertEquals(-1L, LicenseLogic.expiresAt(0L, 86_400_000L))  // timed key, timer not started
        assertEquals(1_000L + 86_400_000L, LicenseLogic.expiresAt(1_000L, 86_400_000L))
    }

    @Test fun crackedTimedKeyIsDetected() {
        val now = 1_000_000_000_000L
        val day = 86_400_000L
        assertEquals(false, LicenseLogic.looksCracked(0L, now))              // lifetime: never
        assertEquals(false, LicenseLogic.looksCracked(-1L, now))             // timer not started
        assertEquals(false, LicenseLogic.looksCracked(now + 30 * day, now))  // 1 month
        assertEquals(false, LicenseLogic.looksCracked(now + 60 * day, now))  // 2 months
        assertEquals(true, LicenseLogic.looksCracked(now + 90 * day, now))   // more than 2 months
        assertEquals(true, LicenseLogic.looksCracked(now + 4000 * day, now)) // a patched far-future date
    }

    @Test fun slots() {
        val slots = linkedMapOf<String, String?>("s10" to null, "s2" to null, "s1" to "NISU-DEV-AAAAAAAAAAAA", "s3" to "NISU-DEV-BBBBBBBBBBBB")
        assertEquals("s1", LicenseLogic.ownSlot("NISU-DEV-AAAAAAAAAAAA", slots))
        assertNull(LicenseLogic.ownSlot("NISU-DEV-CCCCCCCCCCCC", slots))
        assertEquals(listOf("s2", "s10"), LicenseLogic.freeSlots(slots))   // numeric order, not text order
        assertEquals(2, LicenseLogic.usedCount(slots))
    }
}
