package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v3.174: the voice menu has 3.1, 3.8 Live, Beta Fast and 2.5 Native Audio; 3.8 Thinking (agent only) and 3.5 Live Translate are removed. 2.5 has no thinking pause. */
class LiveModelsAllTest {
    @Test fun menuHasTheFourVoiceModels() {
        val ids = LiveModels.ALL.map { it.id }
        for (id in listOf("gemini-3.1-flash-live-preview", "gemini-3.8-live", "gemini-2.5-flash-native-audio-preview-12-2025", LiveModels.BETA_ID)) assertTrue(id, id in ids)
        assertTrue(LiveModels.AGENT_ID !in ids)
        assertTrue(LiveModels.TRANSLATE_ID !in ids)
    }

    @Test fun native25HasNoThinkingPauseAndTheOthersAreUnchanged() {
        assertEquals(0, LiveModels.find(LiveModels.NATIVE25_ID)!!.thinkingBudget)
        assertNull(LiveModels.find("gemini-3.8-live")!!.thinkingBudget)
        assertNull(LiveModels.find("gemini-3.1-flash-live-preview")!!.thinkingBudget)
    }

    @Test fun modelSwitchKnowsOnlyTheMenuModels() {
        assertEquals("gemini-3.8-live", ModelSwitch.resolve("3.8")!!.id)
        assertEquals(LiveModels.NATIVE25_ID, ModelSwitch.resolve("2.5 native audio")!!.id)
        assertNull(ModelSwitch.resolve("3.5 live translate"))
    }

    @Test fun underMaintenanceOptionsAreOff() {
        assertTrue(Maintenance.CALL_AI)
        assertTrue(Maintenance.VOICE_MESSAGES)
    }

    // v3.176: the voice follows the model: 2.5 Native Audio = Aoede, 3.1 / 3.8 Live / Beta Fast = Leda
    @Test fun theVoiceFollowsTheModel() {
        assertEquals("Aoede", Voice.forModel(LiveModels.NATIVE25_ID))
        assertEquals("Leda", Voice.forModel("gemini-3.1-flash-live-preview"))
        assertEquals("Leda", Voice.forModel("gemini-3.8-live"))
        assertEquals("Leda", Voice.forModel(LiveModels.BETA_ID))
    }

    // v3.178: 2.5 Native Audio (Aoede) gets the same ultra-fast leanBoost as 3.1 Flash Live (no heavy 3.8 PHONE_STEADY_38 block)
    // and AudioIO defaults to the ultra-fast 40 ms pre-roll (1920 bytes).
    @Test fun native25GetsUltraFastBoostAndLowPreRoll() {
        val b25 = Persona.leanBoost(LiveModels.NATIVE25_ID)
        assertTrue(b25.contains("SMART AND FAST"))
        org.junit.Assert.assertFalse(b25.contains("PHONE CONTROL DISCIPLINE"))
        assertEquals(1920, AudioIO.preRoll)
    }
}
