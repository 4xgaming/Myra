package ai.nisu.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiAgentBuilderTest {

    @Test
    fun detectsAiApkAndWebsiteAiRequests() {
        assertTrue(AiAgentBuilder.isAiProjectRequest("MyNisuAI", "ekta AI apk banao gemini live model ar api key die", ""))
        assertTrue(AiAgentBuilder.isAiProjectRequest("Jarvis", "make an AI app with phone control and screen read", ""))
        assertTrue(AiAgentBuilder.isAiProjectRequest("OmniWeb", "build a website AI with get key system and live voice", ""))
        assertTrue(AiAgentBuilder.isAiProjectRequest("AnyName", "simple description", "ai_apk"))
        assertTrue(AiAgentBuilder.isAiProjectRequest("AnyName", "simple description", "ai_website"))
        assertFalse(AiAgentBuilder.isAiProjectRequest("Calculator", "a simple math calculator with history", "webview"))
    }

    @Test
    fun aiWebsiteScaffoldContainsGeminiLiveGetKeyScreenReadAndSelfUpdate() {
        val files = AiAgentBuilder.aiWebsiteScaffold("omni-ai", "OmniAI", "Aoede", "Custom Persona").toMap()
        assertTrue(files.containsKey("index.html"))
        assertTrue(files.containsKey("style.css"))
        assertTrue(files.containsKey("script.js"))

        val html = files["index.html"]!!
        val js = files["script.js"]!!

        // 1. Get Free API Key link & API Key input
        assertTrue(html.contains("https://aistudio.google.com/app/apikey"))
        assertTrue(html.contains("Get Free API Key"))
        assertTrue(html.contains("webApiKey"))

        // 2. Gemini Live WebSocket BidiGenerateContent & models
        assertTrue(js.contains("BidiGenerateContent"))
        assertTrue(js.contains("gemini-2.5-flash-native-audio-preview-12-2025"))
        assertTrue(js.contains("gemini-3.1-flash-live-preview"))

        // 3. Screen Read & Camera Vision
        assertTrue(js.contains("getDisplayMedia"))
        assertTrue(js.contains("analyzeCurrentScreenOnce"))
        assertTrue(js.contains("toggleWebCamera"))

        // 4. Live Coding & Self-Update Studio
        assertTrue(js.contains("generateWebCode"))
        assertTrue(js.contains("autoFixWebCode"))

        // 5. Standalone HTML inlining works cleanly
        val standalone = WebRules.buildStandaloneHtml(files)
        assertTrue(standalone.contains("BidiGenerateContent"))
        assertTrue(standalone.contains("https://aistudio.google.com/app/apikey"))
    }

    @Test
    fun buildChatDetectsAiBuildAndUpdateCommands() {
        assertTrue(BuildChat.looksLikeBuild("amar jonno ekta AI apk banao"))
        assertTrue(BuildChat.looksLikeBuild("make a website AI with gemini live"))
        assertTrue(BuildChat.looksLikeBuild("ai app ta update koro"))
        assertTrue(BuildChat.looksLikeBuild("fix the ai apk"))
    }

    @Test
    fun enrichedDescriptionsContainAllUnlockedRequirements() {
        val apkBrief = AiAgentBuilder.enrichAiApkDescription("SuperAI", "Make it like NISU with phone control", "Aoede", "")
        assertTrue(apkBrief.contains("ALL UNLOCKED"))
        assertTrue(apkBrief.contains("BidiGenerateContent"))
        assertTrue(apkBrief.contains("https://aistudio.google.com/app/apikey"))
        assertTrue(apkBrief.contains("open_app"))
        assertTrue(apkBrief.contains("close_app"))
        assertTrue(apkBrief.contains("get_screen"))
        assertTrue(apkBrief.contains("self_update_ui"))

        val webBrief = AiAgentBuilder.enrichAiWebsiteDescription("WebNisu", "Website AI with screen share", "Leda")
        assertTrue(webBrief.contains("BidiGenerateContent"))
        assertTrue(webBrief.contains("https://aistudio.google.com/app/apikey"))
        assertTrue(webBrief.contains("getDisplayMedia"))
    }
}
