package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v3.170: a code answer that was cut (too big for one answer) is continued and put together, not given up. */
class CodeGenBigTest {
    @Test fun continuationIsJoinedWithoutRepeatingTheOverlap() {
        assertEquals("abc def ghi", CodeGen.joinOverlap("abc def", "def ghi"))
        assertEquals("<p>one</p><p>two</p>", CodeGen.joinOverlap("<p>one</p>", "<p>two</p>"))
        assertEquals("abcdef", CodeGen.joinOverlap("abc", "def"))
        assertEquals("abc", CodeGen.joinOverlap("abc", ""))
    }

    @Test fun cutAnswerKeepsTheCompleteFilesAndTheCutFileIsTheLastOne() {
        val cut = """{"files":[{"path":"index.html","content":"<html>ok</html>"},{"path":"app.js","content":"function a(){ var x = 1;"""
        val parts = LiveCodeRules.partialFiles(cut)
        assertEquals(2, parts.size)
        assertEquals("index.html", parts[0].first)
        assertEquals("<html>ok</html>", parts[0].second)
        assertEquals("app.js", parts[1].first)
        assertTrue(parts[1].second.startsWith("function a()"))
    }
}
