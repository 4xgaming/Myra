package ai.nisu.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CallBookTest {
    private fun e(id: String, cat: String, name: String, num: String, note: String = "") = PhonebookRules.Entry(id, cat, name, num, note)

    @Test fun boyfriendIsACategoryAndMotherFatherAreSingle() {
        assertEquals("boyfriend", PhonebookRules.catOfWord("bf")?.id)
        assertTrue(PhonebookRules.cat("mother")!!.single)
        assertTrue(PhonebookRules.cat("father")!!.single)
        assertTrue(!PhonebookRules.cat("boyfriend")!!.single)
        assertTrue(!PhonebookRules.cat("delivery")!!.single)
    }

    @Test fun motherHoldsOnlyOneNumberOthersHoldMany() {
        val list = listOf(e("1", "mother", "Ammu", "01711111111"), e("2", "friend", "Rahim", "01722222222"))
        assertNotNull(PhonebookRules.problem(list, "mother", "Amma 2", "01733333333"))
        assertNull(PhonebookRules.problem(list, "friend", "Karim", "01744444444"))
        assertNull(PhonebookRules.problem(list, "mother", "Ammu", "01711111111", ignoreId = "1"))
    }

    @Test fun aNameOrARelationFindsTheNumber() {
        val list = listOf(e("1", "mother", "Ammu", "01711111111"), e("2", "girlfriend", "Tuli", "01722222222"), e("3", "delivery", "Kamal", "01733333333"))
        assertEquals("01711111111", (PhonebookRules.resolve(list, "mom") as PhonebookRules.Found.One).entry.number)
        assertEquals("01722222222", (PhonebookRules.resolve(list, "gf") as PhonebookRules.Found.One).entry.number)
        assertEquals("01733333333", (PhonebookRules.resolve(list, "Kamal") as PhonebookRules.Found.One).entry.number)
        assertTrue(PhonebookRules.resolve(list, "unknown person") is PhonebookRules.Found.None)
    }

    @Test fun twoPeopleInOneCategoryAreAskedNeverGuessed() {
        val list = listOf(e("1", "friend", "Rahim", "01711111111"), e("2", "friend", "Rakib", "01722222222"))
        assertTrue(PhonebookRules.resolve(list, "friend") is PhonebookRules.Found.Many)
    }

    @Test fun theVoicePromptListsNamesAndNotesNeverTheDigits() {
        val block = CallBook.promptBlock(listOf(e("1", "friend", "Rahim", "01711111111", "my school friend")))
        assertTrue(block.contains("DIRECT CALL BOOK"))
        assertTrue(block.contains("Rahim (Friend): my school friend"))
        assertTrue(block.contains("direct_call"))
        assertTrue(!block.contains("01711111111"))
        assertEquals("", CallBook.promptBlock(emptyList<PhonebookRules.Entry>()))
    }
}
