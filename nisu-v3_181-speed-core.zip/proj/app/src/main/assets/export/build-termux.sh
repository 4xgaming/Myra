#!/data/data/com.termux/files/usr/bin/bash
# NISU AI Self-Building APK Script — runs inside Termux (ARM64 / ARM phones).
# Usage:  bash build-termux.sh
# Automatically installs JDK 17, aapt2, Gradle 8.9, Android SDK licenses, compiles the APK,
# and copies the finished APK straight to /sdcard/Download/!
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
PROJ_NAME="$(basename "$SRC")"
HEAP="${NISU_HEAP:-1536m}"
cleanup() { command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock || true; }
trap cleanup EXIT
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true

echo "========================================================"
echo "  NISU AI — Termux Self-Building APK Compiler"
echo "  Project: $PROJ_NAME"
echo "========================================================"

echo "== [1/5] Checking & installing required Termux packages =="
NEED_PKGS=""
command -v java >/dev/null 2>&1 || NEED_PKGS="$NEED_PKGS openjdk-17"
command -v aapt2 >/dev/null 2>&1 || NEED_PKGS="$NEED_PKGS aapt2"
command -v curl >/dev/null 2>&1 || NEED_PKGS="$NEED_PKGS curl"
command -v unzip >/dev/null 2>&1 || NEED_PKGS="$NEED_PKGS unzip"
command -v tar >/dev/null 2>&1 || NEED_PKGS="$NEED_PKGS tar"
if [ -n "$NEED_PKGS" ]; then
  pkg update -y || echo "(pkg update had a minor warning - continuing)"
  pkg install -y openjdk-17 aapt2 curl unzip tar
fi

AAPT2="$PREFIX/bin/aapt2"
if [ ! -x "$AAPT2" ]; then echo "ERROR: aapt2 was not installed. Run: pkg install aapt2"; exit 1; fi
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
if [ ! -x "$JAVA_HOME/bin/java" ]; then echo "ERROR: Java 17 not found. Run: pkg install openjdk-17"; exit 1; fi
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_OPTS="-Dorg.gradle.native=false -Xmx1g"

echo "== [2/5] Preparing isolated Termux build workspace =="
# Shared storage (/sdcard) cannot hold executable files or symlinks; always build in Termux's private home when needed.
case "$SRC" in
  /sdcard/*|/storage/*|/mnt/*|/data/media/*|/sdcard|/storage)
    WORK="$HOME/export-build-$PROJ_NAME"
    echo "Project is on shared storage -> copying to $WORK"
    rm -rf "$WORK"; mkdir -p "$WORK"
    (cd "$SRC" && tar cf - --exclude=./build --exclude=./app/build --exclude=./.gradle .) | (cd "$WORK" && tar xf -)
    ;;
  *) WORK="$SRC" ;;
esac
cd "$WORK"

echo "== [3/5] Configuring Android SDK & auto-accepting licenses =="
mkdir -p "$ANDROID_HOME/licenses"
printf '\n8933bad161af4178b1185d1a37fbf41ea5269c55\nd56f5187479451eabf01fb78af6dfcb131a6481e\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n' > "$ANDROID_HOME/licenses/android-sdk-license"
printf '\n84831b9409646a918e30573bab4c9c91346d8abd\n' > "$ANDROID_HOME/licenses/android-sdk-preview-license"
echo "sdk.dir=$ANDROID_HOME" > local.properties

echo "== [4/5] Ensuring Gradle 8.9 is installed =="
GRADLE_HOME="$HOME/gradle-8.9"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  echo "Downloading Gradle 8.9 (first time only)..."
  rm -f "$HOME/gradle-8.9-bin.zip"
  curl -L --fail --retry 3 -o "$HOME/gradle-8.9-bin.zip" https://services.gradle.org/distributions/gradle-8.9-bin.zip
  unzip -q -o "$HOME/gradle-8.9-bin.zip" -d "$HOME"
  rm -f "$HOME/gradle-8.9-bin.zip"
fi
chmod +x "$GRADLE_HOME/bin/gradle"

echo "== [5/5] Compiling APK (ARM64 native aapt2) =="
set +e
"$GRADLE_HOME/bin/gradle" assembleDebug --no-daemon --stacktrace --console=plain \
  -Pandroid.aapt2FromMavenOverride="$AAPT2" \
  -Pkotlin.compiler.execution.strategy=in-process \
  -Dorg.gradle.jvmargs="-Xmx$HEAP -Dfile.encoding=UTF-8" 2>&1 | tee "$WORK/build.log"
RC=${PIPESTATUS[0]}
set -e
if [ "$RC" -ne 0 ]; then
  echo; echo "=================== BUILD FAILED (exit $RC) ==================="
  grep -n "^e: \|error:\|What went wrong" -A3 "$WORK/build.log" | head -50 || true
  if grep -q "Killed\|OutOfMemory\|exit code 137\|Java heap" "$WORK/build.log"; then
    echo "Out of memory. Close other apps and retry with:  NISU_HEAP=1024m bash build-termux.sh"
  fi
  echo "Full log: $WORK/build.log"
  exit "$RC"
fi

APK="$(find "$WORK/app/build/outputs/apk/debug" -name '*.apk' 2>/dev/null | head -n 1)"
if [ -z "$APK" ]; then echo "Build finished but no APK was found in app/build/outputs/apk/debug."; exit 1; fi
NAME="NISU-AI-${PROJ_NAME}.apk"
if [ -d /sdcard/Download ] && [ -w /sdcard/Download ]; then
  cp "$APK" "/sdcard/Download/$NAME"
  echo "========================================================"
  echo "  SUCCESS! APK saved to: /sdcard/Download/$NAME"
  echo "========================================================"
  command -v termux-open >/dev/null 2>&1 && termux-open --content-type application/vnd.android.package-archive "/sdcard/Download/$NAME" || true
else
  cp "$APK" "$HOME/$NAME"
  echo "========================================================"
  echo "  SUCCESS! APK saved to: $HOME/$NAME"
  echo "  (Run termux-setup-storage to copy to Downloads)"
  echo "========================================================"
fi
