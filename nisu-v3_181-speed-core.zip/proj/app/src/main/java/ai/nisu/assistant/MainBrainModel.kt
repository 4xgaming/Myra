package ai.nisu.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/*
 * The Main Brain's own model, used silently for automatic replies (v2.1).
 *
 * v3.145: When the voice assistant (AssistantService) is running, opening a second concurrent BidiGenerateContent Live WebSocket on the same
 * API key for a background WhatsApp/Messenger auto-reply caused Google to drop or throttle the active voice session ("reconnects every few minutes").
 * Now, MainBrainModel first tries a stateless REST `generateContent` call (which uses zero Live WebSocket slots and never disrupts the voice assistant),
 * and only falls back to the silent Live WebSocket if REST fails.
 */
class MainBrainModel(private val appContext: Context) : BrainAi {

    companion object {
        /** Whole turn (connect + answer). Below the writer's own 75 s limit. */
        const val TURN_TIMEOUT_MS = 60_000L

        private val restHttp: OkHttpClient = Net.base.newBuilder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private fun key(): String = Prefs.get(appContext, Prefs.KEY, "").trim()

    override fun available(): Boolean = key().isNotEmpty()

    private fun restComplete(apiKey: String, system: String, prompt: String, maxOutputTokens: Int): AiResult? {
        val chatPref = Prefs.get(appContext, Prefs.CHAT_MODEL, Prefs.DEFAULT_CHAT_MODEL).trim().ifBlank { Prefs.DEFAULT_CHAT_MODEL }
        val models = listOf(chatPref, "gemini-2.0-flash", "gemini-2.5-flash", "gemini-3.1-flash-lite").distinct()
        for (m in models) {
            try {
                val gen = JSONObject().put("maxOutputTokens", maxOutputTokens.coerceIn(256, 4096))
                if (m.startsWith("gemini-2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", gen)
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()
                restHttp.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        if (resp.code == 401 || resp.code == 403) return AiResult.Error("http_${resp.code}", false)
                        return@use
                    }
                    val raw = resp.body?.string().orEmpty()
                    val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return@use
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
                    }
                    val out = sb.toString().trim()
                    if (out.isNotEmpty()) return AiResult.Text(out)
                    Unit
                }
            } catch (_: Throwable) {}
        }
        return null
    }

    /** [maxOutputTokens] is used by the stateless REST path; the writer also cuts the text to its own length limit. */
    override suspend fun complete(system: String, prompt: String, maxOutputTokens: Int): AiResult {
        if (prompt.isBlank()) return AiResult.Unavailable("empty_prompt")
        val apiKey = key()
        if (apiKey.isEmpty()) return AiResult.Unavailable("no_api_key")
        // v3.145: Try stateless REST first so we never open a competing Live WebSocket on the user's API key while the voice assistant is active.
        val viaRest = withContext(Dispatchers.IO) { restComplete(apiKey, system, prompt, maxOutputTokens) }
        if (viaRest is AiResult.Text) return viaRest
        val model = Prefs.liveModel(appContext)   // the CURRENT Main Brain model, read now
        val rules = LiveModels.rules(model)
        return withTimeoutOrNull(TURN_TIMEOUT_MS) { oneTurn(apiKey, model, rules, system, prompt) } ?: AiResult.Error("timeout", true)
    }

    private suspend fun oneTurn(apiKey: String, model: String, rules: LiveModels.Model, system: String, prompt: String): AiResult =
        suspendCancellableCoroutine { cont ->
            val done = AtomicBoolean(false)
            val busy = AtomicBoolean(false)   // Extended Thinking: the server may still be reasoning after a turn ended
            val text = StringBuilder()
            var live: GeminiLive? = null

            fun result(): AiResult {
                val t = synchronized(text) { text.toString().trim() }
                return if (t.isEmpty()) AiResult.Error("blocked_or_empty", false) else AiResult.Text(t)
            }
            fun finish(r: AiResult) {
                if (!done.compareAndSet(false, true)) return
                try { live?.close() } catch (_: Throwable) {}
                if (cont.isActive) cont.resume(r)
            }

            val cb = object : GeminiLive.Callback {
                override fun onReady() {
                    try { live?.sendText(prompt) } catch (_: Throwable) { finish(AiResult.Error("live_send_failed", true)) }
                }
                override fun onAudio(pcm: ByteArray) { /* silent: the sound is dropped, never played */ }
                override fun onInterrupted() {}
                override fun onTurnComplete() { if (!busy.get()) finish(result()) }
                override fun onInText(t: String) {}
                override fun onOutText(t: String) { synchronized(text) { text.append(t) } }
                override fun onToolCall(id: String, name: String, args: JSONObject) { /* no tools were declared; anything else is ignored */ }
                override fun onClosed(reason: String, fatal: Boolean, quick: Boolean) {
                    // Only a short code leaves this class: the server's wording is not passed on.
                    // A server that closes after it already sent the answer must not lose that answer.
                    val got = synchronized(text) { text.toString().trim() }
                    if (!fatal && got.isNotEmpty()) { finish(AiResult.Text(got)); return }
                    // Diagnostic: the numeric close code only ("closed 1011 ..." -> 1011), never the server's wording.
                    val closeCode = Regex("^closed (\\d{3,4})").find(reason)?.groupValues?.get(1) ?: "none"
                    AutoReplyLog.add("ai", "live_closed_code_" + closeCode + (if (fatal) "_fatal" else "") + (if (quick) "_quick" else ""), true)
                    finish(AiResult.Error(if (fatal) "live_rejected" else "live_closed", !fatal))
                }
                override fun onInteraction(idle: Boolean) {
                    busy.set(!idle)
                    if (idle && synchronized(text) { text.isNotBlank() }) finish(result())
                }
            }

            live = GeminiLive(apiKey, model, Voice.saved(appContext), system, JSONArray(), null, rules.thinkingLevel, rules.apiVersion, 0, cb)
            cont.invokeOnCancellation { done.set(true); try { live?.close() } catch (_: Throwable) {} }
            try { live?.connect() } catch (_: Throwable) { finish(AiResult.Error("live_connect_failed", true)) }
        }
}
