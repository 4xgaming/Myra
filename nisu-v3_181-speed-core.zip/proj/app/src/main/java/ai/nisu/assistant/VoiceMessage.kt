package ai.nisu.assistant

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * v3.126 / v3.171: SEND A VOICE MESSAGE (WhatsApp, Messenger, Telegram and other chat apps).
 *
 * send_voice_message(app, to, text, user_confirmed):
 *   1. the words are spoken into an audio file (her own voice: ElevenLabs when that engine is chosen and set up, otherwise Gemini TTS or Gemini Live audio fallback),
 *   2. the file is turned into Opus (.ogg, Android 10+, resampled to 48 kHz for hardware encoder compatibility; WhatsApp and Telegram show it like a voice note),
 *      or AAC (.m4a), or WAV if the phone's encoder fails,
 *   3. the app's own Share screen is opened with the file, the person / group is picked by name (resolving saved WhatsApp Contacts first) and Send is pressed ([ShareMedia.shareAudio]).
 * When he tells her to send a voice message with the words, user_confirmed true sends it at once. Never to a Status. The files live in the cache and are deleted after a day.
 */
object VoiceMessage {
    const val NAME = "send_voice_message"
    private const val MAX_CHARS = 700
    private val GEMINI_TTS_MODELS = listOf(
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    private val http: OkHttpClient = Net.base.newBuilder()
        .connectTimeout(15, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).callTimeout(75, TimeUnit.SECONDS).build()

    /** v3.171: Default ON so sending voice messages works out of the box unless the owner switches it off in Preferences. */
    fun enabled(c: Context): Boolean = !Maintenance.VOICE_MESSAGES && Prefs.getBool(c, Prefs.VOICE_MSG, true)   // v3.174: under maintenance = off

    private fun err(msg: String, fix: String? = null) = JSONObject().put("ok", false).put("error", msg).also { if (fix != null) it.put("fix", fix) }

    /** No dollar signs: it is a const. */
    const val NOTE = """
VOICE MESSAGES (send_voice_message, while the owner's Voice messages switch is ON): you CAN send a voice message in WhatsApp, Messenger, Telegram and other chat apps, in your own voice, to a person or group he names. When he tells you to send a voice message (voice message pathao, voice e bolo, voice note pathao) and gives the words (or tells you to send it now), call send_voice_message AT ONCE with app (default "whatsapp" if he did not name another app), to (the person or relation he said, like Rahim, mom, gf), text (the exact words in the language of the chat) and user_confirmed true. If you composed the words yourself because he gave no exact text, read the one short line to him first, get his yes, and then call send_voice_message with user_confirmed true. Report honestly: say it is sent only when the result says likely_sent true. If the tool says the switch is off, tell him to turn Voice messages ON in Preferences. Never use it for a Status and never on your own.
"""

    fun run(ctx: Context, a: JSONObject): JSONObject {
        if (Maintenance.VOICE_MESSAGES) return err("Voice messages are under maintenance, so nothing was sent.", "Tell him in one short sentence that voice messages are under maintenance for now and will be back in a later update. Offer to send a normal text message instead.")
        if (!enabled(ctx)) return err("Voice messages are switched OFF, so nothing was sent.", "Tell him to turn Voice messages ON in Preferences, then ask again.")
        val text = a.optString("text", a.optString("message", "")).trim()
        val app = a.optString("app", "whatsapp").trim().ifEmpty { "whatsapp" }
        val toRaw = a.optString("to", a.optString("contact", a.optString("recipient", ""))).trim()
        if (text.isEmpty()) return err("Say what the voice message should say (text).")
        if (toRaw.isEmpty()) return err("Say the person or group to send the voice message to (to).")
        if (text.length > MAX_CHARS) return err("That is too long for one voice message (about " + MAX_CHARS + " characters at most). Split it into two shorter voice messages.")
        if (ShareRules.isStatusTarget(toRaw)) return err("Voice messages are only sent to a person or group, not to a Status.")
        if (!a.optBoolean("user_confirmed", true)) return err("NOT sent. Say the exact words to him in one short line, get his clear yes, then call again with user_confirmed true.")
        val def = ShareRules.findApp(app)
        if (def != null && !def.chat) return err(def.label + " is not a chat app, so a voice message cannot be sent there.")
        if (NisuAccessibilityService.inst == null) PhoneControl.reviveAccessibility(ctx)
        val acc = NisuAccessibilityService.inst ?: return err(PhoneControl.accProblem(ctx) ?: "Phone control is not connected.")

        // Resolve saved WhatsApp phonebook relation / name ("mom", "gf", "bro", "Rahim") so the share picker searches the real contact name
        var to = toRaw
        if (def == null || def.key == "whatsapp") {
            when (val saved = Phonebook.resolve(ctx, toRaw)) {
                is PhonebookRules.Found.One -> to = saved.entry.name
                is PhonebookRules.Found.Many -> return JSONObject().put("ok", false).put("sent_pressed", false)
                    .put("error", "More than one saved contact matches '$toRaw'. Ask the user which one before sending the voice message.")
                    .put("candidates", JSONArray(saved.entries.map { (PhonebookRules.cat(it.cat)?.label ?: it.cat) + ": " + it.name }))
                PhonebookRules.Found.None -> {}
            }
        }

        cleanOld(ctx)
        val sp = speak(ctx, text) ?: return err("The voice for the message could not be made (no internet, or the API key / ElevenLabs refused). Nothing was sent.",
            "Tell him honestly. Check the Gemini API key (or the ElevenLabs key) and the internet, then try again.")
        val (file, mime, kind) = encode(ctx, sp.first, sp.second)
        AppState.add("Voice message: " + kind + ", " + (file.length() / 1024) + " KB, to " + to)
        val r = ShareMedia.shareAudio(ctx, file, mime, app, to)
        r.put("voice_format", kind)
        if (kind == "wav") r.put("format_note", "The phone could not make a compressed voice file, so a plain audio file was sent; it plays fine but may look like an audio file, not a voice note.")
        else if (kind == "m4a") r.put("format_note", "It was sent as an audio file; the chat app may show it as an audio clip instead of a voice note.")
        return r
    }

    private fun dir(ctx: Context): File = File(File(ctx.cacheDir, "shared_uploads"), "voice").also { it.mkdirs() }

    private fun cleanOld(ctx: Context) {
        try { val limit = System.currentTimeMillis() - 24L * 3600_000L; dir(ctx).listFiles()?.forEach { if (it.lastModified() < limit) it.delete() } } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------------------------------------------------- speech (PCM 16 bit mono)

    /** (pcm, sampleRate) or null. */
    private fun speak(ctx: Context, text: String): Pair<ByteArray, Int>? {
        if (VoiceEngine.saved(ctx) == VoiceEngine.ELEVEN && VoiceEngine.elevenReady(ctx)) elevenPcm(ctx, text)?.let { return it to 24000 }
        geminiPcm(ctx, text)?.let { return it }
        return geminiLivePcm(ctx, text)
    }

    private fun elevenPcm(ctx: Context, text: String): ByteArray? = try {
        val k = Prefs.get(ctx, Prefs.ELEVEN_KEY, "").trim()
        val m = Prefs.get(ctx, Prefs.ELEVEN_MODEL, "").trim().ifEmpty { VoiceEngine.DEFAULT_ELEVEN_MODEL }
        val body = JSONObject().put("model_id", m).put("text", ElevenStyle.clean(text))
        val url = "https://api.elevenlabs.io/v1/text-to-speech/" + java.net.URLEncoder.encode(VoiceEngine.elevenVoice(ctx), "UTF-8") + "?output_format=pcm_24000"
        http.newCall(Request.Builder().url(url).header("xi-api-key", k).post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.bytes()?.takeIf { it.size > 1200 }
        }
    } catch (_: Exception) { null }

    private fun geminiPcm(ctx: Context, text: String): Pair<ByteArray, Int>? {
        val key = Prefs.get(ctx, Prefs.KEY, "").trim()
        if (key.isEmpty()) return null
        val voice = Voice.saved(ctx)
        for (model in GEMINI_TTS_MODELS) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "Say this as a real young woman would say it in a voice message to someone she knows, warm, natural and relaxed, in the same language as the words: " + text)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
                val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", key).post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val j = JSONObject(r.body?.string().orEmpty())
                    val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return@use
                    for (i in 0 until parts.length()) {
                        val inl = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                        val data = inl.optString("data")
                        if (data.isEmpty()) continue
                        val rate = Regex("rate=(\\d+)").find(inl.optString("mimeType"))?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                        val pcm = Base64.decode(data, Base64.DEFAULT)
                        if (pcm.size > 1200) return pcm to rate
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Fallback when the REST preview-tts endpoints are unavailable or quota-limited: synthesizes the exact words using
     * the Gemini Live BidiGenerateContent WebSocket (24 kHz PCM) so voice messages ALWAYS work with the user's normal Gemini API key.
     */
    private fun geminiLivePcm(ctx: Context, text: String): Pair<ByteArray, Int>? {
        val key = Prefs.get(ctx, Prefs.KEY, "").trim()
        if (key.isEmpty()) return null
        val model = Prefs.liveModel(ctx)
        val rules = LiveModels.rules(model)
        val voice = Voice.saved(ctx)
        val out = java.io.ByteArrayOutputStream()
        val latch = CountDownLatch(1)
        var liveRef: GeminiLive? = null
        val sys = "You are recording a short voice message. Speak ONLY the exact words the user gives you, naturally and warmly, in that exact language. Do not add any greeting, explanation, or extra words before or after."
        val cb = object : GeminiLive.Callback {
            override fun onReady() {
                liveRef?.sendText(text)
            }
            override fun onAudio(pcm: ByteArray) {
                synchronized(out) { out.write(pcm) }
            }
            override fun onInterrupted() {}
            override fun onTurnComplete() { latch.countDown() }
            override fun onInText(t: String) {}
            override fun onOutText(t: String) {}
            override fun onToolCall(id: String, name: String, args: JSONObject) {}
            override fun onClosed(reason: String, fatal: Boolean, quick: Boolean) { latch.countDown() }
        }
        return try {
            val l = GeminiLive(key, model, voice, sys, JSONArray(), null, null, rules.apiVersion, 1, cb).also {
                it.serverVad = false
                it.thinkingBudget = 0
            }
            liveRef = l
            l.connect()
            latch.await(25, TimeUnit.SECONDS)
            try { l.close() } catch (_: Throwable) {}
            val bytes = synchronized(out) { out.toByteArray() }
            if (bytes.size > 1200) bytes to 24000 else null
        } catch (_: Throwable) {
            try { liveRef?.close() } catch (_: Throwable) {}
            null
        }
    }

    // ---------------------------------------------------------------------------------------------------------- encoding

    /**
     * Upsamples 16-bit mono PCM from 24 kHz to 48 kHz using linear interpolation.
     * Android's hardware/software Ogg Opus encoder (c2.android.opus.encoder) frequently requires 48000 Hz and fails or outputs empty files at 24000 Hz.
     */
    internal fun resampleTo48k(pcm: ByteArray, rate: Int): Pair<ByteArray, Int> {
        if (rate == 48000 || pcm.size < 4) return pcm to rate
        if (rate == 24000) {
            val samples = pcm.size / 2
            val out = ByteArray(samples * 4)
            var prev = ((pcm[1].toInt() shl 8) or (pcm[0].toInt() and 0xFF)).toShort().toInt()
            for (i in 0 until samples) {
                val cur = ((pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)).toShort().toInt()
                val mid = (prev + cur) / 2
                val idx = i * 4
                out[idx] = (mid and 0xFF).toByte()
                out[idx + 1] = ((mid shr 8) and 0xFF).toByte()
                out[idx + 2] = (cur and 0xFF).toByte()
                out[idx + 3] = ((cur shr 8) and 0xFF).toByte()
                prev = cur
            }
            return out to 48000
        }
        return pcm to rate
    }

    private data class Out(val file: File, val mime: String, val kind: String)
    private operator fun Out.component1() = file
    private operator fun Out.component2() = mime
    private operator fun Out.component3() = kind

    private fun encode(ctx: Context, pcm: ByteArray, rate: Int): Out {
        val stamp = System.currentTimeMillis()
        if (Build.VERSION.SDK_INT >= 29) {
            val f = File(dir(ctx), "voice_$stamp.ogg")
            val (pcm48, rate48) = resampleTo48k(pcm, rate)
            if (encodeWith(pcm48, rate48, "audio/opus", MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG, f, 32000) ||
                encodeWith(pcm, rate, "audio/opus", MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG, f, 32000)) {
                return Out(f, "audio/ogg", "ogg-opus")
            }
            f.delete()
        }
        val m4a = File(dir(ctx), "voice_$stamp.m4a")
        if (encodeWith(pcm, rate, "audio/mp4a-latm", MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4, m4a, 48000)) return Out(m4a, "audio/mp4", "m4a")
        m4a.delete()
        val wav = File(dir(ctx), "voice_$stamp.wav")
        writeWav(pcm, rate, wav)
        return Out(wav, "audio/wav", "wav")
    }

    private fun encodeWith(pcm: ByteArray, rate: Int, mime: String, container: Int, out: File, bitrate: Int): Boolean {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var started = false
        return try {
            val format = MediaFormat.createAudioFormat(mime, rate, 1)
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            if (mime == "audio/mp4a-latm") format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            codec = MediaCodec.createEncoderByType(mime)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(out.absolutePath, container)
            val info = MediaCodec.BufferInfo()
            var inOff = 0; var inDone = false; var outDone = false; var track = -1
            val deadline = System.currentTimeMillis() + 30_000L
            while (!outDone && System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        buf.clear()
                        var n = minOf(buf.remaining(), pcm.size - inOff)
                        n -= n % 2
                        val pts = inOff / 2L * 1_000_000L / rate
                        if (n <= 0) { codec.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { buf.put(pcm, inOff, n); inOff += n; codec.queueInputBuffer(i, 0, n, pts, 0) }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                } else if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) { ob.position(info.offset); ob.limit(info.offset + info.size); muxer.writeSampleData(track, ob, info) }
                    codec.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
            outDone && started
        } catch (_: Throwable) { false }
        finally {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { if (started) muxer?.stop() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
        }.let { ok -> ok && out.length() > 400 }
    }

    private fun writeWav(pcm: ByteArray, rate: Int, f: File) {
        RandomAccessFile(f, "rw").use { w ->
            fun le32(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
            fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
            w.setLength(0)
            w.writeBytes("RIFF"); w.write(le32(36 + pcm.size)); w.writeBytes("WAVEfmt "); w.write(le32(16)); w.write(le16(1)); w.write(le16(1))
            w.write(le32(rate)); w.write(le32(rate * 2)); w.write(le16(2)); w.write(le16(16)); w.writeBytes("data"); w.write(le32(pcm.size)); w.write(pcm)
        }
    }
}
