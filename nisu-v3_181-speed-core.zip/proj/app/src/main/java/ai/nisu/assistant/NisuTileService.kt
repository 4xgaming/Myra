package ai.nisu.assistant

import android.Manifest
import android.app.PendingIntent
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * v3.167: CONTROL PANEL BUTTON. A tile in the quick settings panel (the swipe-down panel, like the 1.1.1.1 VPN tile) switches NISU AI on and off
 * without opening the app. Tap = start (blue) or stop (grey). It shows the real state of the assistant (AppState.running) and follows it while the panel is open.
 */
class NisuTileService : TileService() {
    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 700L) } }

    override fun onStartListening() { h.removeCallbacks(poll); poll.run() }
    override fun onStopListening() { h.removeCallbacks(poll) }
    override fun onTileAdded() { refresh() }

    override fun onClick() {
        if (AppState.running.value) {
            try { startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP)) } catch (_: Exception) {}
        } else if (isLocked) {
            unlockAndRun { start() }          // starting the AI needs the phone unlocked; stopping it never does
        } else start()
        h.postDelayed({ refresh() }, 600L)
        h.postDelayed({ refresh() }, 1800L)
    }

    private fun start() {
        if (!FreeTier.canRun(this)) {
            Toast.makeText(this, "Free talk time is over. Add a Premium key in NISU AI.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { openApp(); return }   // the microphone permission is asked inside the app
        try {
            ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_START))
        } catch (_: Exception) { openApp() }
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
            else startActivityAndCollapse(i)
        } catch (_: Exception) {}
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = AppState.running.value
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "NISU AI"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "On" else "Off"
        t.icon = Icon.createWithResource(this, R.drawable.ic_qs_nisu)
        try { t.updateTile() } catch (_: Exception) {}
    }

    companion object {
        /** Android 13+ asks "Add tile?" right away; older Android shows how to add it by hand. */
        fun requestAdd(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    ctx.getSystemService(StatusBarManager::class.java).requestAddTileService(
                        ComponentName(ctx, NisuTileService::class.java), "NISU AI", Icon.createWithResource(ctx, R.drawable.ic_qs_nisu),
                        ContextCompat.getMainExecutor(ctx), java.util.function.Consumer<Int> { })
                    return
                } catch (_: Exception) {}
            }
            Toast.makeText(ctx, "Swipe down twice, tap the pencil / Edit icon, then drag the NISU AI tile into the panel.", Toast.LENGTH_LONG).show()
        }
    }
}
