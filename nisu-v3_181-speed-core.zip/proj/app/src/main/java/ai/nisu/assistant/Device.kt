package ai.nisu.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject

/** Things a normal phone user can do, plus a root-powered self-setup that grants NISU AI its own permissions. */
object Device {
    fun findContact(ctx: Context, q: String): JSONObject {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return JSONObject().put("error", "Contacts permission is missing. Run setup_self (needs root) or ask the user to allow it.")
        val out = JSONArray()
        ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use { c ->
            while (c.moveToNext() && out.length() < 8)
                out.put(JSONObject().put("name", c.getString(0)).put("number", c.getString(1)))
        }
        return JSONObject().put("contacts", out)
    }

    /** v3.152: an SMS DRAFT: opens the phone's SMS app with the number and the words filled in. Nothing is sent. */
    fun draftSms(ctx: Context, number: String, text: String): JSONObject {
        val raw = number.trim()
        if (raw.isEmpty() || text.isBlank()) return JSONObject().put("ok", false).put("error", "Both recipient number/name and message text are required.")
        var target = raw
        if (raw.filter { it.isDigit() }.length < 3) {
            val saved = Phonebook.resolve(ctx, raw)
            if (saved is PhonebookRules.Found.One) target = saved.entry.number
            else if (saved is PhonebookRules.Found.Many) return JSONObject().put("ok", false).put("error", "More than one saved contact matches '$raw'. Ask the user which one.")
            else {
                val found = findContact(ctx, raw)
                val arr = found.optJSONArray("contacts") ?: JSONArray()
                val nums = (0 until arr.length()).map { arr.getJSONObject(it).optString("number") }.distinctBy { it.filter { c -> c.isDigit() } }
                if (nums.isEmpty()) return JSONObject().put("ok", false).put("error", "No saved contact matches '$raw'. Ask the user for the phone number.")
                if (nums.size > 1) return JSONObject().put("ok", false).put("error", "More than one contact matches '$raw'. Ask the user which one.").put("candidates", arr)
                target = nums[0]
            }
        }
        return try {
            val i = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:" + android.net.Uri.encode(target)))
                .putExtra("sms_body", text).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            JSONObject().put("ok", true).put("drafted", true).put("note", "The SMS app is open with the words filled in. Nothing has been sent.")
        } catch (e: Exception) { JSONObject().put("ok", false).put("error", "Could not open the SMS app: ${e.message}") }
    }

    fun sendSms(ctx: Context, number: String, text: String): JSONObject {
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            return JSONObject().put("ok", false).put("error", "SMS permission is missing. Run setup_self (needs root) or ask the user to allow it.")
        val raw = number.trim()
        if (raw.isEmpty() || text.isBlank()) return JSONObject().put("ok", false).put("error", "Both recipient number/name and message text are required.")
        var targetNum = raw
        var targetName = ""
        val digitsOnly = raw.filter { it.isDigit() }
        // v3.144: if the model passed a contact name instead of digits, resolve it safely from saved contacts (refusing if ambiguous)
        if (digitsOnly.length < 3) {
            val found = findContact(ctx, raw)
            if (found.has("error")) return found.put("ok", false)
            val arr = found.optJSONArray("contacts") ?: JSONArray()
            if (arr.length() == 0) return JSONObject().put("ok", false).put("error", "No saved contact matches '$raw'. Ask the user for the phone number or exact contact name.")
            val rows = (0 until arr.length()).map { arr.getJSONObject(it) }
            val exact = rows.filter { it.optString("name").equals(raw, true) }
            val chosenPool = if (exact.isNotEmpty()) exact else rows
            val distinctNums = chosenPool.map { it.optString("number").filter { c -> c.isDigit() } }.distinct()
            if (distinctNums.size > 1) {
                return JSONObject().put("ok", false).put("error", "More than one contact matches '$raw'. Ask the user which one before sending SMS.")
                    .put("candidates", arr)
            }
            targetNum = chosenPool[0].optString("number")
            targetName = chosenPool[0].optString("name")
        }
        @Suppress("DEPRECATION")
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(targetNum, null, sm.divideMessage(text), null, null)
        return JSONObject().put("ok", true).put("sent_to", targetNum).also { if (targetName.isNotEmpty()) it.put("contact_name", targetName) }
    }

    private val RUNTIME = listOf("READ_CONTACTS", "WRITE_CONTACTS", "READ_CALL_LOG", "WRITE_CALL_LOG", "CALL_PHONE",
        "SEND_SMS", "READ_SMS", "RECEIVE_SMS", "READ_CALENDAR", "WRITE_CALENDAR", "CAMERA", "RECORD_AUDIO",
        "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "READ_PHONE_STATE", "POST_NOTIFICATIONS",
        "READ_MEDIA_IMAGES", "READ_MEDIA_VIDEO", "READ_MEDIA_AUDIO", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE",
        "BLUETOOTH_CONNECT", "BLUETOOTH_SCAN", "WRITE_SECURE_SETTINGS")

    /** With root: grant NISU AI every permission it declares, exempt it from battery limits, and switch on its accessibility service. */
    fun setupSelf(ctx: Context): JSONObject {
        val pkg = ctx.packageName
        val comp = "$pkg/ai.nisu.assistant.NisuAccessibilityService"
        val sb = StringBuilder()
        RUNTIME.forEach { sb.append("pm grant $pkg android.permission.$it 2>/dev/null; ") }
        listOf("SYSTEM_ALERT_WINDOW", "WRITE_SETTINGS", "MANAGE_EXTERNAL_STORAGE", "RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND", "REQUEST_INSTALL_PACKAGES", "READ_CLIPBOARD")
            .forEach { sb.append("appops set $pkg $it allow 2>/dev/null; ") }
        sb.append("pm grant $pkg com.termux.permission.RUN_COMMAND 2>/dev/null; ")
        sb.append("cmd notification allow_listener $pkg/ai.nisu.assistant.NisuNotificationService 2>/dev/null; ")
        sb.append("cmd notification allow_dnd $pkg 2>/dev/null; ")
        sb.append("dumpsys deviceidle whitelist +$pkg 2>/dev/null; ")
        sb.append("cur=\$(settings get secure enabled_accessibility_services); ")
        sb.append("case \"\$cur\" in *$comp*) ;; null|'') settings put secure enabled_accessibility_services $comp;; ")
        sb.append("*) settings put secure enabled_accessibility_services \"\$cur:$comp\";; esac; ")
        sb.append("settings put secure accessibility_enabled 1; ")
        sb.append("echo granted_count=\$(dumpsys package $pkg | grep -c 'granted=true')")
        val (code, out) = Root.exec(sb.toString(), 40000)
        // Android connects the accessibility service a moment after the setting changes: wait for it instead of guessing
        val end = System.currentTimeMillis() + 6000
        while (NisuAccessibilityService.inst == null && System.currentTimeMillis() < end) { try { Thread.sleep(250) } catch (_: InterruptedException) { break } }
        return JSONObject().put("ok", code == 0).put("exit_code", code).put("result", out.trim())
            .put("accessibility_connected", NisuAccessibilityService.inst != null)
            .put("status", PhoneControl.status(ctx, rootKnown = true))
            .put("note", "Report what status says is still missing; do not claim a permission was granted unless status shows it.")
    }
}
