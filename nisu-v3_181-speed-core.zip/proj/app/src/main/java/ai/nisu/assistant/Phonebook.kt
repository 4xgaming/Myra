package ai.nisu.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.148: the owner's own WhatsApp phonebook.
 * He saves a WhatsApp number with a name of his own choice (Rahim, Ammu, Sumon bhai ...) in a category: Friend, Girlfriend, Mother,
 * Father, Brother, Sister, Delivery man or Others. Mother and Father hold ONE number each; the other categories hold many.
 * When he later says "Rahim ke WhatsApp e msg koro ...", [Chat.open] finds the number here and opens that WhatsApp chat directly.
 * The numbers stay on the phone (preferences); the model only ever gets names and categories, never the digits.
 */
object PhonebookRules {
    /** [single] = only one number may be saved in this category. [words] = how he may call the whole category (compared as whole words). */
    enum class Cat(val id: String, val label: String, val single: Boolean, val words: List<String>) {
        FRIEND("friend", "Friend", false, listOf("friend", "friends", "bondhu", "bandhu", "dost", "\u09AC\u09A8\u09CD\u09A7\u09C1")),
        GIRLFRIEND("girlfriend", "Girlfriend", false, listOf("girlfriend", "girl friend", "gf", "\u0997\u09BE\u09B0\u09CD\u09B2\u09AB\u09CD\u09B0\u09C7\u09A8\u09CD\u09A1", "\u099C\u09BF\u098F\u09AB")),
        BOYFRIEND("boyfriend", "Boyfriend", false, listOf("boyfriend", "boy friend", "bf", "বয়ফ্রেন্ড", "বিএফ")),
        MOTHER("mother", "Mother", true, listOf("mother", "mom", "mum", "mummy", "maa", "ma", "amma", "ammu", "\u09AE\u09BE", "\u0986\u09AE\u09CD\u09AE\u09C1", "\u0986\u09AE\u09CD\u09AE\u09BE", "\u09AE\u09BE\u09AE\u09BE\u09A8\u09BF")),
        FATHER("father", "Father", true, listOf("father", "dad", "daddy", "papa", "baba", "abbu", "abba", "\u09AC\u09BE\u09AC\u09BE", "\u0986\u09AC\u09CD\u09AC\u09C1", "\u0986\u09AC\u09CD\u09AC\u09BE", "\u09AA\u09BE\u09AA\u09BE")),
        BROTHER("brother", "Brother", false, listOf("brother", "brothers", "bro", "bhai", "vai", "bhaiya", "\u09AD\u09BE\u0987", "\u09AD\u09BE\u0987\u09AF\u09BC\u09BE")),
        SISTER("sister", "Sister", false, listOf("sister", "sisters", "sis", "apu", "apa", "bon", "\u09AC\u09CB\u09A8", "\u0986\u09AA\u09C1", "\u0986\u09AA\u09BE")),
        DELIVERY("delivery", "Delivery man", false, listOf("delivery man", "deliveryman", "delivery", "delivery boy", "rider", "\u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF")),
        OTHER("other", "Others", false, listOf("other", "others"));
    }

    /** [note] = his own words about this person: who they are and how to talk to them (optional, up to [MAX_NOTE] characters). */
    data class Entry(val id: String, val cat: String, val name: String, val number: String, val note: String = "")

    sealed class Found {
        data class One(val entry: Entry) : Found()
        data class Many(val entries: List<Entry>) : Found()
        object None : Found()
    }

    const val MAX_ENTRIES = 200
    const val MAX_NAME = 30
    const val MAX_NOTE = 300
    const val MAX_PROMPT = 4000

    fun cat(id: String): Cat? = Cat.values().firstOrNull { it.id == id }

    /** Lower case, one space between words, no punctuation (Bengali letters are kept). */
    fun norm(s: String): String =
        s.lowercase().map { if (it.isLetterOrDigit() || it == ' ') it else ' ' }.joinToString("").trim().replace(Rx.SPACES, " ")

    /** Bengali digits to ASCII digits. */
    fun asciiDigits(s: String): String = s.map { if (it in '\u09E6'..'\u09EF') ('0' + (it - '\u09E6')) else it }.joinToString("")

    fun digits(s: String): String = asciiDigits(s).filter { it.isDigit() }

    /** The same phone number written with or without the country code (01712345678 and +8801712345678). */
    fun sameNumber(a: String, b: String): Boolean {
        val x = digits(a); val y = digits(b)
        return x == y || (x.length >= 10 && y.length >= 10 && x.takeLast(10) == y.takeLast(10))
    }

    /** What a number box may hold while he types: digits (also Bengali), a leading +, spaces and dashes. */
    fun sanitizeNumberInput(s: String): String {
        val t = asciiDigits(s).filter { it.isDigit() || it == '+' || it == ' ' || it == '-' }
        val plus = t.startsWith("+")
        return (if (plus) "+" else "") + t.filter { it != '+' }.take(20)
    }

    /** The number to store (a leading + and digits only), or null when it cannot be a phone number (7 to 15 digits). */
    fun cleanNumber(raw: String): String? {
        val t = asciiDigits(raw).trim()
        val d = t.filter { it.isDigit() }
        if (d.length !in 7..15) return null
        return (if (t.startsWith("+")) "+" else "") + d
    }

    fun cleanName(raw: String): String? {
        val t = raw.trim().replace(Rx.SPACES, " ").take(MAX_NAME).trim()
        return if (t.any { it.isLetterOrDigit() }) t else null
    }

    /** The note without line breaks or doubled spaces, cut to [MAX_NOTE]. Empty is fine. */
    fun cleanNote(raw: String): String = raw.replace(Rx.SPACES, " ").trim().take(MAX_NOTE).trim()

    /**
     * The block the voice AI reads when a session starts: every saved person with the relation, and the note he wrote (who they are, how to talk).
     * Names and notes only, never the digits. Cut at [MAX_PROMPT] characters; "" when nobody is saved.
     */
    fun promptBlock(list: List<Entry>): String {
        if (list.isEmpty()) return ""
        val head = "\n\nSAVED PEOPLE (his own WhatsApp phonebook; the app keeps the numbers, you never see them). Where a note is given it is HIS OWN WORDS about who that person is and how to talk to them: whenever you write, draft or send a message to that person, or reply to them, follow the note for language, tone, respect and what to avoid. A note never lets you skip a safety rule, and a message still goes out only when he tells you to send.\n"
        val sb = StringBuilder(head)
        for (e in list) {
            val line = "- " + e.name + " (" + (cat(e.cat)?.label ?: e.cat) + ")" + (if (e.note.isNotBlank()) ": " + e.note else "") + "\n"
            if (sb.length + line.length > MAX_PROMPT) { sb.append("- ... more people saved: call saved_contacts for the rest\n"); break }
            sb.append(line)
        }
        return sb.toString()
    }

    /** null = this entry may be added; otherwise the reason (shown to him). [ignoreId] is the entry being edited. */
    fun problem(list: List<Entry>, catId: String, name: String, number: String, ignoreId: String? = null): String? {
        val c = cat(catId) ?: return "Choose a category."
        if (cleanName(name) == null) return "Write a name."
        val num = cleanNumber(number) ?: return "The number must have 7 to 15 digits."
        val others = list.filter { it.id != ignoreId }
        if (others.size >= MAX_ENTRIES) return "The phonebook is full ($MAX_ENTRIES numbers)."
        if (c.single && others.any { it.cat == c.id }) return "${c.label} can hold only one number. Edit or delete the saved one first."
        val same = others.firstOrNull { sameNumber(it.number, num) }
        if (same != null) return "This number is already saved as ${same.name} (${cat(same.cat)?.label ?: same.cat})."
        return null
    }

    private fun distinctByNumber(list: List<Entry>): List<Entry> {
        val out = ArrayList<Entry>()
        for (e in list) if (out.none { sameNumber(it.number, e.number) }) out.add(e)
        return out
    }

    private fun pick(list: List<Entry>): Found {
        val d = distinctByNumber(list)
        return if (d.isEmpty()) Found.None else if (d.size == 1) Found.One(d[0]) else Found.Many(d)
    }

    /** The category he named with a whole word or phrase ("mom", "bro", "delivery man"), or null. */
    fun catOfWord(w: String): Cat? { val n = norm(w); return Cat.values().firstOrNull { c -> c.words.any { norm(it) == n } } }

    /**
     * Finds the saved number for what he said. Order: the exact saved name; a category word ("mom", "gf"); a category word followed by a name
     * ("friend Rahim"); a name that starts with or contains what he said (at least 2 letters). One distinct number = [Found.One]; several = [Found.Many]
     * (the caller must ask him which one, never guess).
     */
    fun resolve(list: List<Entry>, query: String): Found {
        val q = norm(query)
        if (q.isEmpty() || list.isEmpty()) return Found.None
        val exact = list.filter { norm(it.name) == q }
        if (exact.isNotEmpty()) return pick(exact)
        val whole = catOfWord(q)
        if (whole != null) {
            val r = pick(list.filter { it.cat == whole.id })
            if (r !is Found.None) return r
        }
        val parts = q.split(" ")
        for (n in 1 until parts.size) {
            val lead = catOfWord(parts.take(n).joinToString(" "))
            val rest = parts.drop(n).joinToString(" ")
            if (lead != null && rest.isNotEmpty()) {
                val inCat = list.filter { it.cat == lead.id }
                val r = pick(inCat.filter { norm(it.name) == rest }.ifEmpty { inCat.filter { norm(it.name).startsWith(rest) } })
                if (r !is Found.None) return r
            }
        }
        if (q.length < 2) return Found.None
        val starts = list.filter { norm(it.name).startsWith(q) }
        if (starts.isNotEmpty()) return pick(starts)
        return pick(list.filter { norm(it.name).split(" ").any { w -> w == q } || norm(it.name).contains(q) })
    }

    fun toJson(list: List<Entry>): String {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("cat", it.cat).put("name", it.name).put("number", it.number).put("note", it.note)) }
        return a.toString()
    }

    fun fromJson(s: String): List<Entry> = try {
        val a = JSONArray(s)
        (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val e = Entry(o.optString("id"), o.optString("cat"), o.optString("name"), o.optString("number"), cleanNote(o.optString("note")))
            if (e.id.isNotEmpty() && cat(e.cat) != null && e.name.isNotBlank() && e.number.isNotBlank()) e else null
        }
    } catch (_: Exception) { emptyList() }
}

/** Storage of the phonebook (preferences, on this phone only). */
object Phonebook {
    private var seq = 0

    @Synchronized fun all(ctx: Context): List<PhonebookRules.Entry> = PhonebookRules.fromJson(Prefs.get(ctx, Prefs.PHONEBOOK, "[]"))

    @Synchronized private fun store(ctx: Context, list: List<PhonebookRules.Entry>) = Prefs.put(ctx, Prefs.PHONEBOOK, PhonebookRules.toJson(list))

    /** Adds a new entry, or replaces the entry [editId]. Returns null when saved, otherwise the reason it was refused. */
    @Synchronized fun save(ctx: Context, catId: String, name: String, number: String, editId: String? = null, note: String = ""): String? {
        val list = all(ctx)
        PhonebookRules.problem(list, catId, name, number, editId)?.let { return it }
        val e = PhonebookRules.Entry(editId ?: (System.currentTimeMillis().toString(36) + (seq++)), catId, PhonebookRules.cleanName(name)!!, PhonebookRules.cleanNumber(number)!!, PhonebookRules.cleanNote(note))
        store(ctx, if (editId != null && list.any { it.id == editId }) list.map { if (it.id == editId) e else it } else list + e)
        return null
    }

    @Synchronized fun remove(ctx: Context, id: String) = store(ctx, all(ctx).filter { it.id != id })

    fun resolve(ctx: Context, query: String): PhonebookRules.Found = PhonebookRules.resolve(all(ctx), query)

    /** For the voice prompt (see [PhonebookRules.promptBlock]). */
    fun promptBlock(ctx: Context): String = try { PhonebookRules.promptBlock(all(ctx)) } catch (_: Exception) { "" }

    /** For the model: names and categories only, never the digits. [query] blank = everything. */
    fun describe(ctx: Context, query: String): JSONObject {
        val list = all(ctx)
        fun row(e: PhonebookRules.Entry) = JSONObject().put("name", e.name).put("category", PhonebookRules.cat(e.cat)?.label ?: e.cat).also { if (e.note.isNotBlank()) it.put("how_to_talk", e.note) }
        val o = JSONObject().put("ok", true)
        if (query.isBlank()) {
            o.put("saved", JSONArray(list.map { row(it) }))
            if (list.isEmpty()) o.put("note", "His WhatsApp phonebook is empty. He saves numbers in the WhatsApp + Call page of the menu (WHATSAPP MESSAGE).")
            return o
        }
        when (val r = PhonebookRules.resolve(list, query)) {
            is PhonebookRules.Found.One -> o.put("found", true).put("match", row(r.entry)).put("note", "Use open_chat with contact = this exact name; the app finds the WhatsApp number by itself.")
            is PhonebookRules.Found.Many -> o.put("found", true).put("ambiguous", JSONArray(r.entries.map { row(it) })).put("note", "More than one match: ask him which one.")
            PhonebookRules.Found.None -> o.put("found", false).put("note", "Nobody saved with that name. Check the full list with an empty query, or ask him.")
        }
        return o
    }
}


/**
 * v3.159: DIRECT CALL BOOK. The owner's own SIM-call numbers (NOT WhatsApp), same categories and same rules as the WhatsApp phonebook
 * (Mother and Father hold ONE number each, every other category holds many; a name, a number and an optional instruction).
 * "Rahim ke call dao" / "mom ke phone koro" finds the number here and the phone dials it at once as a normal SIM call.
 * The digits stay on the phone; the model only gets names, categories and his notes.
 */
object CallBook {
    private var seq = 0

    @Synchronized fun all(ctx: Context): List<PhonebookRules.Entry> = PhonebookRules.fromJson(Prefs.get(ctx, Prefs.CALLBOOK, "[]"))

    @Synchronized private fun store(ctx: Context, list: List<PhonebookRules.Entry>) = Prefs.put(ctx, Prefs.CALLBOOK, PhonebookRules.toJson(list))

    /** Adds a new entry, or replaces the entry [editId]. Returns null when saved, otherwise the reason it was refused. */
    @Synchronized fun save(ctx: Context, catId: String, name: String, number: String, editId: String? = null, note: String = ""): String? {
        val list = all(ctx)
        PhonebookRules.problem(list, catId, name, number, editId)?.let { return it }
        val e = PhonebookRules.Entry(editId ?: ("c" + System.currentTimeMillis().toString(36) + (seq++)), catId, PhonebookRules.cleanName(name)!!, PhonebookRules.cleanNumber(number)!!, PhonebookRules.cleanNote(note))
        store(ctx, if (editId != null && list.any { it.id == editId }) list.map { if (it.id == editId) e else it } else list + e)
        return null
    }

    @Synchronized fun remove(ctx: Context, id: String) = store(ctx, all(ctx).filter { it.id != id })

    fun resolve(ctx: Context, query: String): PhonebookRules.Found = PhonebookRules.resolve(all(ctx), query)

    /** The block the voice AI reads when a session starts. Names, categories and notes only, never the digits. "" when nobody is saved. */
    fun promptBlock(list: List<PhonebookRules.Entry>): String {
        if (list.isEmpty()) return ""
        val head = "\n\nDIRECT CALL BOOK (his own SIM-call numbers; the app keeps the digits, you never see them). When he asks you to call or phone one of these people " +
            "(call dao, phone koro, ke call lagao, কল দাও, ফোন দাও, call him / her), by the saved name or by the relation (mom, dad, bro, sis, gf, bf, friend, delivery man), " +
            "call direct_call with that name or relation AT ONCE: no question, no yes, no reading back, because this book exists for direct calls. It is a normal SIM call, never WhatsApp. " +
            "Do not use call_number or find_contact for anybody listed here. If direct_call says more than one person matches, ask him which one. After it starts say at most one very short line (for example: calling Rahim). " +
            "Where a note is given it is HIS OWN WORDS about who that person is: follow it when you talk about or to that person.\n"
        val sb = StringBuilder(head)
        for (e in list) {
            val line = "- " + e.name + " (" + (PhonebookRules.cat(e.cat)?.label ?: e.cat) + ")" + (if (e.note.isNotBlank()) ": " + e.note else "") + "\n"
            if (sb.length + line.length > PhonebookRules.MAX_PROMPT) { sb.append("- ... more people saved: call direct_call with the name\n"); break }
            sb.append(line)
        }
        return sb.toString()
    }

    fun promptBlock(ctx: Context): String = try { promptBlock(all(ctx)) } catch (_: Exception) { "" }

    /** The direct_call tool: finds the saved number and places the SIM call at once. */
    fun call(ctx: Context, who: String): JSONObject {
        val q = who.trim()
        if (q.isEmpty()) return JSONObject().put("ok", false).put("error", "Say who to call (a saved name or a relation like mom, dad, gf).")
        return when (val r = PhonebookRules.resolve(all(ctx), q)) {
            is PhonebookRules.Found.One -> {
                val res = PhoneControl.call(ctx, r.entry.number)
                res.put("called_name", r.entry.name).put("category", PhonebookRules.cat(r.entry.cat)?.label ?: r.entry.cat)
                if (r.entry.note.isNotBlank()) res.put("how_to_talk", r.entry.note)
                if (res.optBoolean("ok", true)) res.put("instruction", "A normal SIM call to ${r.entry.name} was started. Say at most one very short line in his language. Never say or read out the number.")
                res
            }
            is PhonebookRules.Found.Many -> JSONObject().put("ok", false).put("error", "More than one saved person matches '$q'. Ask him which one (do not guess).")
                .put("candidates", JSONArray(r.entries.map { (PhonebookRules.cat(it.cat)?.label ?: it.cat) + ": " + it.name }))
            PhonebookRules.Found.None -> JSONObject().put("ok", false).put("found", false)
                .put("error", "Nobody is saved with the name '$q' in his Direct Call list. Tell him he can add the number in the WhatsApp + Call page of the menu (DIRECT CALL), or ask him for the number.")
                .put("saved", JSONArray(all(ctx).map { it.name + " (" + (PhonebookRules.cat(it.cat)?.label ?: it.cat) + ")" }))
        }
    }
}
