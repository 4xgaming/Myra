package ai.nisu.assistant

/**
 * v3.156: "ONLY WHEN I ASK". The time, the date, the battery / charge and every other phone fact (RAM, storage, Wi-Fi, permissions ...) are
 * looked at ONLY when his own words in this turn ask for them. The model never checks them by itself: not at the start of a chat, not as a
 * greeting, not between two answers, not "to be helpful". This object is pure (no Android classes) so it is unit tested in AskedInfoOnlyTest.
 *
 * It is a real limit, not only advice: the voice service refuses the tool calls and the typed chat refuses the [[DEVICE: ..]] marker
 * when his words do not ask for them (see AssistantService and TextChat).
 */
object AskedInfoOnly {
    /** Tools that read the clock or the phone's state. */
    val GUARDED = setOf("get_time", "device_info", "phone_status")

    // Deliberately wide (English, Banglish, Bangla, Hindi): a wrong "allowed" only means the old behaviour for that one sentence,
    // a wrong "blocked" would refuse something he really asked. Anything that does not match is treated as "he did not ask".
    private val TIME = Regex(
        "\\b(time|date|clock|o'clock|oclock|what day|which day|day is it|day today|remind|reminder|alarm|wake me|timer)\\b" +
            "|somoy|shomoy|samay|tarikh|tarik\\b|ghori|ghoti|koyta|kota baje|koita|kayta|kto baje|koto baje|baje\\b|ki bar\\b|ki baar\\b" +
            "|সময়|টাইম|কয়টা|কয়টায়|কটা|বাজে|বাজল|বাজলো|তারিখ|ঘড়ি|ঘড়ীতে|কি বার|কী বার|কোন বার|রিমাইন্ডার|রিমাইন্ড|অ্যালার্ম|এলার্ম|মনে করিয়ে|ডেকে দাও|জাগিয়ে|জাগিও" +
            "|समय|टाइम|कितने बजे|बजे|तारीख|घड़ी|अलार्म|याद दिला"
    )

    private val PHONE = Regex(
        "\\b(battery|charge|charging|charger|percent|percentage|ram|rom|cpu|gpu|chipset|processor|storage|memory|wifi|wi-fi|bluetooth|network|signal|sim|" +
            "temperature|heat|heating|hot|android|version|model|device|sensor|sensors|display|screen|info|information|status|specs|spec|health|uptime|speed)\\b" +
            "|chaj|charj|garom|phone er|phoner|phone-er|fon er|foner|sob information|shob information|tothyo|tothho" +
            "|ব্যাটারি|ব্যাটারী|চার্জ|চার্জিং|পার্সেন্ট|শতাংশ|র‍্যাম|র্যাম|প্রসেসর|সিপিইউ|চিপসেট|স্টোরেজ|মেমোরি|মেমরি|ওয়াইফাই|ওয়াই-ফাই|ব্লুটুথ|নেটওয়ার্ক|সিগন্যাল|সিম" +
            "|গরম|তাপ|ডিসপ্লে|স্ক্রিন|সেন্সর|ভার্সন|মডেল|ইনফরমেশন|ইনফো|তথ্য|ফোনের|ফোন এর|ফোনে|ফোনটা|স্পেস|স্পিড" +
            "|बैटरी|चार्ज|फोन|जानकारी|स्टोरेज|मेमोरी|वाईफाई|ब्लूटूथ"
    )

    private val PERMISSIONS = Regex(
        "\\b(permission|permissions|access|accessibility|root|setup|set up|problem|not working|broken|ready|check)\\b" +
            "|পারমিশন|অ্যাক্সেস|এক্সেস|অ্যাকসেসিবিলিটি|রুট|সেটআপ|সমস্যা|কাজ করছে না|কাজ করে না|চেক|ঠিক আছে" +
            "|permisn|permision|kaj korche na|kaj kore na|thik ache"
    )

    fun wantsTime(userText: String): Boolean = TIME.containsMatchIn(userText.lowercase())

    fun wantsPhoneInfo(userText: String): Boolean = PHONE.containsMatchIn(userText.lowercase())

    fun wantsPermissionCheck(userText: String): Boolean = PERMISSIONS.containsMatchIn(userText.lowercase())

    /** True when his words ask for what [tool] reads. Blank text is NOT judged here: the caller decides what to do when no transcript has arrived. */
    fun asked(tool: String, userText: String): Boolean = when (tool) {
        "get_time" -> wantsTime(userText)
        "device_info" -> wantsPhoneInfo(userText)
        "phone_status" -> wantsPermissionCheck(userText) || wantsPhoneInfo(userText)
        else -> true
    }

    /** Tool answer when the model called one of the guarded tools without being asked. */
    const val REFUSED = "NOT DONE: he did not ask for the time or for any phone information. Never check or mention the time, the date, the battery, the charge or any " +
        "phone detail by yourself. Do not say that you tried, do not call this again, and carry on talking about what he really said."

    /** Same refusal for the typed chat, as a system note for the next model step. */
    const val REFUSED_TYPED = "\n\nHe did NOT ask about the phone. Do not mention the time, the date, the battery, the charge or any phone information, " +
        "and do not write a [[DEVICE: ..]] line. Answer only what his message says."

    /** The rule as it is written into the prompts (voice and typed). */
    const val RULE = "ONLY WHEN HE ASKS: never look at or mention the time, the date, the battery percent, the charge or any other phone information by yourself. " +
        "Not at the start of a chat, not as a greeting, not between two answers, not to be helpful, not as small talk. Check it only when HIS words in this very turn ask for it " +
        "(for example the time, the date, the battery, the RAM, the storage, Wi-Fi, or \"phone er information\"). After you answered, never repeat it on your own: " +
        "when he asks again, check again; until then say nothing about it. "
}
