package ai.nisu.assistant

import android.app.job.JobParameters
import android.app.job.JobService

/** v3.141: runs about every 6 hours (also when the app is closed): looks at the GitHub Releases and shows a notification when a newer version exists. */
class UpdateJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        val app = applicationContext
        Thread {
            try {
                val (reached, found) = Updater.fetchLatest(app)
                if (reached && found != null) Updater.notifyUpdate(app, found)
            } catch (_: Throwable) {}
            try { jobFinished(params, false) } catch (_: Throwable) {}
        }.start()
        return true
    }
    override fun onStopJob(params: JobParameters?): Boolean = true
}
