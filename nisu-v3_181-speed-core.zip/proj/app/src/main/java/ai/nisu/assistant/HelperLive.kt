package ai.nisu.assistant

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/*
 * v3.94 / v3.147 SUPER-FAST HELPER ENGINE:
 *
 * Why Helper used to feel slow:
 *  - Opening a BidiGenerateContent Live WebSocket took 2-5 seconds for handshake + setupComplete, then generated AUDIO PCM tokens
 *    at speaking speed and read outputTranscription, plus waited for GRACE_MS / turnComplete!
 *  - Even on `restTurn`, it tried models sequentially without setting `thinkingBudget: 0` on `gemini-2.5-flash` (which thinks for 2-4s by default),
 *    and `fileTools` jobs always forced the slow Live WebSocket.
 *
 * v3.147 Ultra-Fast Architecture:
 *  1. STATELESS REST FIRST FOR ALL JOBS (Search, Image Prompt, AND File Tools!):
 *     - Uses `gemini-3.1-flash-lite` / `gemini-2.0-flash` / `gemini-2.5-flash` (with `thinkingBudget: 0` so there is zero thinking pause)
 *       over a pre-warmed HTTP/2 connection pool.
 *     - Supports multi-turn `functionDeclarations` (`file_search`, `file_list`, `file_read`) directly over REST `generateContent`!
 *     - Answers in ~0.4s - 1.2s instead of 6s - 25s, and uses ZERO Live WebSocket slots.
 *  2. LIVE WEBSOCKET FALLBACK:
 *     - If the user explicitly typed the `gemini-3.8-live-extended-thinking` model in Worker settings AND has a separate helper key,
 *       or if REST is unavailable, the persistent Live WebSocket session is used seamlessly with 250ms grace finish.
 */
internal object HelperLive {
    class Out(val text: String?, val error: String, val model: String, val toolCalls: Int, /** v3.119: the short, key-free reason the session ended (for the activity log and the Main Brain). */ val detail: String = "", /** v3.128: for error "quota": how long the helper rests, in ms. */ val restMs: Long = 0L)

    private val restHttp: OkHttpClient = Net.base.newBuilder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Remembers which REST model answered fastest most recently so we hit it first on the very next call. */
    @Volatile private var fastestRestModel: String = "gemini-2.0-flash"

    private fun orderedRestModels(preferred: String): List<String> {
        val base = listOf("gemini-2.0-flash", "gemini-3.1-flash-lite", "gemini-2.5-flash", "gemini-2.0-flash-lite")
        val p = preferred.trim().removePrefix("models/")
        val customRest = if (p.isNotEmpty() && !p.contains("live") && !p.contains("thinking")) listOf(p) else emptyList()
        return (customRest + listOf(fastestRestModel) + base).distinct()
    }

    private fun generationConfigFor(model: String): JSONObject {
        val gen = JSONObject().put("maxOutputTokens", 1200).put("temperature", 0.2)
        // Disable thinking pause on 2.5-flash so synthesis is instantaneous (~400ms)
        if (model.startsWith("gemini-2.5-flash")) {
            gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        return gen
    }

    /**
     * Fast stateless REST generateContent call (zero WebSocket slots used).
     * Supports both plain text synthesis (search / image prompt) AND multi-turn read-only file tool calls!
     */
    private fun restTurn(ctx: Context, apiKey: String, preferredModel: String, system: String, prompt: String, fileTools: Boolean, timeoutMs: Long): Out? {
        val models = orderedRestModels(preferredModel)
        val deadline = System.currentTimeMillis() + timeoutMs.coerceIn(2500L, 20000L)
        for (m in models) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining < 1200L) break
            try {
                val res = restSingleModel(ctx, apiKey, m, system, prompt, fileTools, remaining)
                if (res != null) {
                    if (res.text != null) {
                        fastestRestModel = m
                        return res
                    }
                    if (res.error == "auth") return null
                }
            } catch (_: Throwable) {}
        }
        return null
    }

    private fun restSingleModel(ctx: Context, apiKey: String, m: String, system: String, prompt: String, fileTools: Boolean, budgetMs: Long): Out? {
        val contents = JSONArray().put(
            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        )
        val toolsJson = if (fileTools) JSONArray().put(JSONObject().put("functionDeclarations", fileDeclarations(null))) else null
        var callsCount = 0
        val maxRounds = if (fileTools) HelperRules.MAX_ROUNDS else 1
        val start = System.currentTimeMillis()

        for (round in 0 until maxRounds) {
            val left = (budgetMs - (System.currentTimeMillis() - start)).coerceIn(1500L, 12000L)
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", generationConfigFor(m))
            if (toolsJson != null) body.put("tools", toolsJson)

            val client = restHttp.newBuilder().callTimeout(left, TimeUnit.MILLISECONDS).build()
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                .header("x-goog-api-key", apiKey)
                .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            var funcCalls: List<Pair<String, JSONObject>>? = null
            var modelContent: JSONObject? = null
            var textAns: String? = null
            var authFail = false

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    if (resp.code == 401 || resp.code == 403) authFail = true
                    return@use
                }
                val raw = resp.body?.string().orEmpty()
                val candContent = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content") ?: return@use
                modelContent = candContent
                val parts = candContent.optJSONArray("parts") ?: return@use
                val sb = StringBuilder()
                val fcs = ArrayList<Pair<String, JSONObject>>()
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    if (p.optBoolean("thought", false)) continue
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val fnName = fc.optString("name")
                        val fnArgs = fc.optJSONObject("args") ?: JSONObject()
                        if (fnName.isNotEmpty()) fcs.add(fnName to fnArgs)
                    } else {
                        val t = p.optString("text")
                        if (t.isNotEmpty()) sb.append(t)
                    }
                }
                if (fcs.isNotEmpty() && fileTools) {
                    funcCalls = fcs
                } else {
                    val ans = sb.toString().trim()
                    if (ans.isNotEmpty()) textAns = ans
                }
            }

            if (authFail) return Out(null, "auth", m, callsCount)
            if (textAns != null) return Out(textAns, "", m, callsCount)

            val calls = funcCalls ?: return null
            val mc = modelContent ?: return null
            contents.put(mc)
            val respParts = JSONArray()
            for ((fnName, fnArgs) in calls) {
                val out: JSONObject = try {
                    if (fnName !in HelperRules.FILE_TOOLS) JSONObject().put("error", "This tool is not available to the helper (read only).")
                    else if (++callsCount > HelperRules.MAX_ROUNDS * 2) JSONObject().put("error", "Too many steps. Answer now with what you have.")
                    else Tools.run(ctx.applicationContext, fnName, fnArgs)
                } catch (_: Exception) {
                    JSONObject().put("error", "the file tool failed")
                }
                val shown = if (out.toString().length <= 14_000) out else JSONObject().put("result", HelperRules.clip(out.toString(), 14_000))
                respParts.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", fnName).put("response", shown)
                    )
                )
            }
            contents.put(JSONObject().put("role", "user").put("parts", respParts))
        }
        return null
    }

    fun fileDeclarations(behavior: String?): JSONArray {
        fun d(name: String, desc: String, props: Map<String, String>, req: List<String>): JSONObject = HelperAgent.decl(name, desc, props, req, behavior)
        return JSONArray()
            .put(d("file_search", "Find files on the phone instantly from the file index. Use it first. Newest first.",
                mapOf("query" to "name words", "kind" to "photo | video | music | document | text | archive | apk | any", "folder" to "optional folder path", "limit" to "how many, default 8, max 30"), emptyList()))
            .put(d("file_list", "List what is inside a folder, for example /sdcard/Download.", mapOf("path" to "folder path"), listOf("path")))
            .put(d("file_read", "Read the text inside a text file (txt, md, json, log, srt ...).", mapOf("path" to "full file path", "max_chars" to "default 3000, max 12000"), listOf("path")))
    }

    // v3.128: a quota / rate / session-limit end is NEVER tried again straight away (it used to be: 3 more sessions on the empty key every time, so the quota never came back).
    private val RETRY = setOf("live_closed", "live_rejected", "connect_failed", "send_failed")

    /** v3.128: at most [HelperRules.MAX_PARALLEL] helper sessions at once. */
    private val gate = java.util.concurrent.Semaphore(HelperRules.MAX_PARALLEL, true)

    /** v3.128: after a quota problem the helper rests (per key, the key itself is never stored: only its hash). While it rests no session is opened at all. */
    private val restUntil = java.util.concurrent.ConcurrentHashMap<Int, Long>()

    fun restLeftMs(apiKey: String): Long = ((restUntil[apiKey.hashCode()] ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun resting(apiKey: String, model: String): Out? {
        val left = restLeftMs(apiKey)
        return if (left > 0L) Out(null, "quota", model, 0, "resting " + (left / 1000) + " s after a quota limit", left) else null
    }

    private fun redact(s: String, key: String): String = s.replace(key, "***").replace(Regex("key=[^&\\s\\\"]+"), "key=***").take(160)

    // ---- v3.129: the helper is a Live model like the Main Brain: ONE long-lived silent session per kind of job, not a new session for every job ----

    private val sessions = java.util.concurrent.ConcurrentHashMap<String, Sess>()
    @Volatile private var reaper: Thread? = null

    /** Closes a session that nobody used for [HelperRules.IDLE_MS] (it gives its place on the key back). The next job opens it again by itself. */
    private fun startReaper() {
        synchronized(this) {
            if (reaper != null) return
            reaper = Thread {
                while (true) {
                    try { Thread.sleep(30_000L) } catch (_: InterruptedException) { return@Thread }
                    val now = System.currentTimeMillis()
                    for (s in sessions.values) s.idleCheck(now)
                }
            }.also { it.isDaemon = true; it.start() }
        }
    }

    /**
     * One silent Live session that stays open between jobs.
     */
    private class Sess(private val app: Context, private val apiKey: String, private val model: String, private val system: String, private val search: Boolean, private val fileTools: Boolean) {
        class JobState {
            val text = StringBuilder()
            val latch = CountDownLatch(1)
            val result = AtomicReference<Out?>(null)
            val done = AtomicBoolean(false)
            val busy = AtomicBoolean(false)
            val pending = AtomicInteger(0)
            val awaiting = AtomicBoolean(false)
            val calls = AtomicInteger(0)
        }

        val lock = java.util.concurrent.locks.ReentrantLock(true)
        private val rules = LiveModels.agentRules(model)
        private val worker = Executors.newSingleThreadExecutor(java.util.concurrent.ThreadFactory { r -> Thread(r).also { it.isDaemon = true } })
        @Volatile private var live: GeminiLive? = null
        @Volatile private var job: JobState? = null
        @Volatile private var alive = false
        @Volatile private var retire = false
        @Volatile private var connectLatch = CountDownLatch(1)
        @Volatile private var connectError: Out? = null
        @Volatile private var lastUsed = System.currentTimeMillis()
        private var jobs = 0   // v3.132: jobs done on this connection (guarded by [lock])

        private fun cur(j: JobState): String = synchronized(j.text) { j.text.toString().trim() }
        private fun finish(j: JobState, o: Out) { if (!j.done.compareAndSet(false, true)) return; j.result.set(o); j.latch.countDown() }
        private fun tryFinish(j: JobState) {
            if (j.pending.get() > 0 || j.awaiting.get() || j.busy.get()) return
            val t = cur(j)
            if (t.isNotEmpty()) finish(j, Out(t, "", model, j.calls.get()))
        }
        // Extended Thinking sometimes never sends IDLE after the answer: a turn that ended with text, no tool pending and no new words for GRACE_MS is the answer.
        private fun grace(j: JobState) {
            val seen = cur(j).length
            val t = Thread {
                try { Thread.sleep(HelperRules.GRACE_MS) } catch (_: InterruptedException) { return@Thread }
                val now = cur(j)
                if (!j.done.get() && j.pending.get() == 0 && !j.awaiting.get() && now.length == seen && now.isNotEmpty()) finish(j, Out(now, "", model, j.calls.get()))
            }
            t.isDaemon = true
            t.start()
        }
        private fun closedOut(reason: String, fatal: Boolean, calls: Int): Out {
            val d = "$model: " + HelperLive.redact(reason, apiKey)
            return if (HelperRules.isQuota(reason)) Out(null, "quota", model, calls, d) else Out(null, if (fatal) "live_rejected" else "live_closed", model, calls, d)
        }
        private fun closeLive() {
            alive = false
            val l = live
            live = null
            try { l?.close() } catch (_: Throwable) {}
        }

        private val cb = object : GeminiLive.Callback {
            override fun onReady() { alive = true; connectLatch.countDown() }
            override fun onAudio(pcm: ByteArray) { /* silent: the sound is dropped, never played */ }
            override fun onInterrupted() {}
            override fun onTurnComplete() {
                val j = job ?: return
                if (j.pending.get() > 0 || j.awaiting.get()) return
                if (j.busy.get()) { if (cur(j).isNotEmpty()) grace(j); return }
                if (cur(j).isEmpty()) finish(j, Out(null, "empty", model, j.calls.get())) else tryFinish(j)
            }
            override fun onInText(t: String) {}
            override fun onOutText(t: String) { val j = job ?: return; synchronized(j.text) { j.text.append(t) }; j.awaiting.set(false) }
            override fun onToolCall(id: String, name: String, args: JSONObject) {
                val j = job ?: return
                j.pending.incrementAndGet()
                synchronized(j.text) { j.text.setLength(0) }   // what was said before a tool call is not the answer
                try {
                    worker.execute {
                        val out: JSONObject = try {
                            if (name !in HelperRules.FILE_TOOLS) JSONObject().put("error", "This tool is not available to the helper (read only).")
                            else if (j.calls.incrementAndGet() > HelperRules.MAX_ROUNDS * 2) JSONObject().put("error", "Too many steps. Answer now with what you have.")
                            else Tools.run(app, name, args)
                        } catch (e: Exception) { JSONObject().put("error", "the file tool failed") }
                        val shown = if (out.toString().length <= 14_000) out else JSONObject().put("result", HelperRules.clip(out.toString(), 14_000))
                        j.awaiting.set(true)
                        try { live?.sendToolResponse(id, name, shown, if (rules.tools == LiveModels.ToolMode.NON_BLOCKING) "WHEN_IDLE" else null) } catch (_: Throwable) {}
                        j.pending.decrementAndGet()
                    }
                } catch (_: Throwable) { j.pending.decrementAndGet() }
            }
            override fun onClosed(reason: String, fatal: Boolean, quick: Boolean) {
                alive = false
                live = null
                if (connectLatch.count > 0L) { connectError = closedOut(reason, fatal, 0); connectLatch.countDown() }
                val j = job ?: return
                val got = cur(j)
                if (!fatal && got.isNotEmpty() && j.pending.get() == 0) { finish(j, Out(got, "", model, j.calls.get())); return }
                finish(j, closedOut(reason, fatal, j.calls.get()))
            }
            override fun onInteraction(idle: Boolean) { val j = job ?: return; j.busy.set(!idle); if (idle) tryFinish(j) }
            override fun onGoAway(timeLeftMs: Long) { retire = true; if (job == null) closeLive() }
        }

        /** null = the session is open and ready, otherwise why it could not be opened. */
        private fun ensure(): Out? {
            val l = live
            if (alive && l != null && l.ready && !retire) return null
            closeLive()
            retire = false
            connectError = null
            val latch = CountDownLatch(1)
            connectLatch = latch
            val decls = if (fileTools) HelperLive.fileDeclarations(rules.tools.wire) else JSONArray()
            val g = GeminiLive(apiKey, model, Voice.saved(app), system, decls, null, rules.thinkingLevel, rules.apiVersion, 0, cb)
            g.googleSearch = search
            live = g
            try { g.connect() } catch (_: Throwable) { closeLive(); return Out(null, "connect_failed", model, 0) }
            try { latch.await(10, TimeUnit.SECONDS) } catch (_: InterruptedException) {}
            if (alive && g.ready) return null
            val e = connectError
            closeLive()
            return e ?: Out(null, "live_closed", model, 0, "$model: no answer from the server")
        }

        fun run(prompt: String, timeoutMs: Long): Out {
            val got = try { lock.tryLock(HelperRules.LOCK_WAIT_MS, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
            if (!got) return Out(null, "busy", model, 0)
            try {
                ensure()?.let { return it }
                val g = live ?: return Out(null, "live_closed", model, 0)
                val j = JobState()
                job = j
                lastUsed = System.currentTimeMillis()
                g.sendText("[New request: ignore all earlier requests.]\n" + prompt)
                val inTime = try { j.latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
                if (!inTime) {
                    val t = cur(j)
                    finish(j, if (t.isNotEmpty() && j.pending.get() == 0) Out(t, "", model, j.calls.get()) else Out(null, "timeout", model, j.calls.get()))
                }
                val out = j.result.get() ?: Out(null, "no_result", model, j.calls.get())
                job = null
                lastUsed = System.currentTimeMillis()
                if (out.text == null || j.busy.get() || retire || !alive) { closeLive(); jobs = 0 }   // not a clean end: the next job starts on a fresh session
                else if (++jobs >= HelperRules.SESSION_JOBS) { closeLive(); jobs = 0 }   // v3.132: every job stays in a session's memory, so it gets slower: a fresh connection every few jobs
                return out
            } finally {
                lock.unlock()
            }
        }

        /** v3.132: opens the connection now (so the next job finds it ready); does nothing when a job is running or it is already open. */
        fun warm() {
            if (!lock.tryLock()) return
            try { if (ensure() == null) lastUsed = System.currentTimeMillis() } finally { lock.unlock() }
        }

        fun idleCheck(now: Long) {
            if (live == null || now - lastUsed < HelperRules.IDLE_MS) return
            if (lock.tryLock()) { try { if (now - lastUsed >= HelperRules.IDLE_MS) closeLive() } finally { lock.unlock() } }
        }
    }

    private fun sessionFor(ctx: Context, apiKey: String, model: String, system: String, search: Boolean, fileTools: Boolean): Sess {
        val key = apiKey.hashCode().toString() + "|" + model + "|" + search + "|" + fileTools + "|" + system.hashCode()
        return sessions.getOrPut(key) { Sess(ctx.applicationContext, apiKey, model, system, search, fileTools) }
    }

    /**
     * v3.147: Pre-warms the HTTPS connection pool to `generativelanguage.googleapis.com` immediately while the browser is searching,
     * so the subsequent `restTurn` call has zero DNS/TLS handshake latency!
     */
    fun warm(ctx: Context, apiKey: String, model: String, system: String, search: Boolean = false, fileTools: Boolean = false) {
        Net.warm()   // v3.181: one shared warm connection for every feature (no new thread per search)
    }

    private fun rested(apiKey: String, o: Out): Out {
        val rest = HelperRules.restMs(o.detail)
        restUntil[apiKey.hashCode()] = System.currentTimeMillis() + rest
        return Out(null, "quota", o.model, o.toolCalls, o.detail, rest)
    }

    /**
     * Blocking. Call from a worker thread.
     * v3.147 SUPER-FAST TURN:
     * Always tries the ultra-fast stateless REST `generateContent` path first (including for `fileTools`!), unless the user explicitly
     * configured `gemini-3.8-live-extended-thinking` with a dedicated helper key.
     * This eliminates the 3-15 second Live WebSocket setup and audio-transcription bottleneck, delivering answers in ~0.5 - 1.5 seconds!
     */
    fun turn(ctx: Context, apiKey: String, model: String, system: String, prompt: String, search: Boolean, fileTools: Boolean, timeoutMs: Long): Out {
        val mainKey = try { Prefs.get(ctx, Prefs.KEY, "").trim() } catch (_: Throwable) { "" }
        val wantsDeepLiveThinking = model == HelperRules.THINKING_MODEL && apiKey != mainKey && restLeftMs(apiKey) == 0L
        if (!search && !wantsDeepLiveThinking) {
            restTurn(ctx, apiKey, model, system, prompt, fileTools, timeoutMs)?.let { return it }
        }
        resting(apiKey, model)?.let { return it }
        val got = try { gate.tryAcquire(HelperRules.GATE_WAIT_MS, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
        if (!got) {
            restTurn(ctx, apiKey, model, system, prompt, fileTools, timeoutMs)?.let { return it }
            return Out(null, "busy", model, 0)
        }
        try {
            resting(apiKey, model)?.let {
                restTurn(ctx, apiKey, model, system, prompt, fileTools, timeoutMs)?.let { r -> return r }
                return it
            }
            val started = System.currentTimeMillis()
            val sess = sessionFor(ctx, apiKey, model, system, search, fileTools)
            startReaper()
            var last = sess.run(prompt, timeoutMs)
            if (last.text != null) return last
            val left = (timeoutMs - (System.currentTimeMillis() - started)).coerceAtLeast(3500L)
            restTurn(ctx, apiKey, model, system, prompt, fileTools, left)?.let { return it }
            if (last.error == "quota") return rested(apiKey, last)
            if (last.error !in RETRY) return last
            val plain = "gemini-3.8-live"
            val tries = listOf(model to 2) + (if (model != plain) listOf(plain to 0) else emptyList())
            for (t in tries) {
                val rem = timeoutMs - (System.currentTimeMillis() - started)
                if (rem < 6_000L) break
                last = attempt(ctx, apiKey, t.first, t.second, system, prompt, search, fileTools, rem)
                if (last.text == null && last.error == "quota") return rested(apiKey, last)
                if (last.text != null || last.error !in RETRY) return last
            }
            return last
        } finally {
            gate.release()
        }
    }

    private fun attempt(ctx: Context, apiKey: String, model: String, compat: Int, system: String, prompt: String, search: Boolean, fileTools: Boolean, timeoutMs: Long): Out {
        val app = ctx.applicationContext
        val rules = LiveModels.agentRules(model)
        val decls = if (fileTools) fileDeclarations(rules.tools.wire) else JSONArray()
        val latch = CountDownLatch(1)
        val text = StringBuilder()
        val result = AtomicReference<Out?>(null)
        val done = AtomicBoolean(false)
        val busy = AtomicBoolean(false)          // Extended Thinking: the server may still be reasoning after a turn ended
        val pending = AtomicInteger(0)           // tool calls being carried out
        val awaiting = AtomicBoolean(false)      // a tool result was sent and the model has not answered yet
        val calls = AtomicInteger(0)
        val liveRef = AtomicReference<GeminiLive?>(null)
        val worker = Executors.newSingleThreadExecutor()

        fun current(): String = synchronized(text) { text.toString().trim() }
        fun finish(o: Out) {
            if (!done.compareAndSet(false, true)) return
            result.set(o)
            try { liveRef.get()?.close() } catch (_: Throwable) {}
            worker.shutdown()
            latch.countDown()
        }
        fun tryFinish() {
            if (pending.get() > 0 || awaiting.get() || busy.get()) return
            val t = current()
            if (t.isNotEmpty()) finish(Out(t, "", model, calls.get()))
        }

        fun graceFinish() {
            val seen = current().length
            val t = Thread {
                try { Thread.sleep(HelperRules.GRACE_MS) } catch (_: InterruptedException) { return@Thread }
                val now = current()
                if (!done.get() && pending.get() == 0 && !awaiting.get() && now.length == seen && now.isNotEmpty()) finish(Out(now, "", model, calls.get()))
            }
            t.isDaemon = true
            t.start()
        }

        val cb = object : GeminiLive.Callback {
            override fun onReady() { try { liveRef.get()?.sendText(prompt) } catch (_: Throwable) { finish(Out(null, "send_failed", model, calls.get())) } }
            override fun onAudio(pcm: ByteArray) { /* silent: the sound is dropped, never played */ }
            override fun onInterrupted() {}
            override fun onTurnComplete() {
                if (pending.get() > 0 || awaiting.get()) return
                if (busy.get()) { if (current().isNotEmpty()) graceFinish(); return }
                if (current().isEmpty()) finish(Out(null, "empty", model, calls.get())) else tryFinish()
            }
            override fun onInText(t: String) {}
            override fun onOutText(t: String) { synchronized(text) { text.append(t) }; awaiting.set(false) }
            override fun onToolCall(id: String, name: String, args: JSONObject) {
                pending.incrementAndGet()
                synchronized(text) { text.setLength(0) }   // what was said before a tool call is not the answer
                try {
                    worker.execute {
                        val out: JSONObject = try {
                            if (name !in HelperRules.FILE_TOOLS) JSONObject().put("error", "This tool is not available to the helper (read only).")
                            else if (calls.incrementAndGet() > HelperRules.MAX_ROUNDS * 2) JSONObject().put("error", "Too many steps. Answer now with what you have.")
                            else Tools.run(app, name, args)
                        } catch (e: Exception) { JSONObject().put("error", "the file tool failed") }
                        val shown = if (out.toString().length <= 14_000) out else JSONObject().put("result", HelperRules.clip(out.toString(), 14_000))
                        awaiting.set(true)
                        try { liveRef.get()?.sendToolResponse(id, name, shown, if (rules.tools == LiveModels.ToolMode.NON_BLOCKING) "WHEN_IDLE" else null) } catch (_: Throwable) {}
                        pending.decrementAndGet()
                    }
                } catch (_: Throwable) { pending.decrementAndGet() }
            }
            override fun onClosed(reason: String, fatal: Boolean, quick: Boolean) {
                val got = current()
                if (!fatal && got.isNotEmpty() && pending.get() == 0) { finish(Out(got, "", model, calls.get())); return }
                if (HelperRules.isQuota(reason)) { finish(Out(null, "quota", model, calls.get(), "$model: " + redact(reason, apiKey))); return }
                finish(Out(null, if (fatal) "live_rejected" else "live_closed", model, calls.get(), "$model: " + redact(reason, apiKey)))
            }
            override fun onInteraction(idle: Boolean) { busy.set(!idle); if (idle) tryFinish() }
        }

        val live = GeminiLive(apiKey, model, Voice.saved(app), system, decls, null, rules.thinkingLevel, rules.apiVersion, compat, cb)
        live.googleSearch = search
        liveRef.set(live)
        try { live.connect() } catch (_: Throwable) { finish(Out(null, "connect_failed", model, 0)) }
        val inTime = try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
        if (!inTime) {
            val got = current()
            finish(if (got.isNotEmpty() && pending.get() == 0) Out(got, "", model, calls.get()) else Out(null, "timeout", model, calls.get()))
        }
        return result.get() ?: Out(null, "no_result", model, calls.get())
    }
}
