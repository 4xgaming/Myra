package ai.nisu.assistant

import android.app.Application

/** Application class. Its only job is to give the custom lock a place to start in every process start (also when Android starts a service at boot). */
class NishuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Personal.init(this)
        WaVoiceNotes.init(this)   // v3.71: WhatsApp voice messages are understood silently
        Prefs.migrateDefaults(this)   // v2.33: Gemini 3.1 Flash Live + Leda voice become the active choice once
        Prefs.migrateModel352(this)   // v3.52: Gemini 3.8 Live becomes the active model once
        Prefs.migrateBeta376(this)    // v3.76: back to the fast setup (Beta Fast + FAST) once
        Prefs.migrateModel369(this)   // v3.69: Gemini 3.1 Flash Live becomes the active model once (faster replies)
        ReplySettings.init(this)
        Feelings.on(this)   // v3.78: primes the feelings switch for code that has no Context
        NishuLockManager.init(this)
        // v3.181: alarms are put back on a background thread: reading / writing the reminder list no longer delays the first screen
        Thread({ Reminders.rescheduleAll(this) }, "nisu-reminders").apply { isDaemon = true }.start()   // v3.58: alarms are put back after a restart / update
        EdgeGlow.init(this)   // v2.38: the glow around the screen edge while NISU AI is on
        Avatar3d.init(this)   // v3.161: 3D anime character (.glb / .fbx) with floating screen overlay and lip-sync
        NetWatch.start(this)   // v3.148: premium key / free time are checked at once when the internet comes back
        if (Prefs.get(this, Prefs.KEY, "").isNotBlank()) Net.warm()   // v3.181: the shared Google connection is ready before the first question
    }

    /** v3.181: when Android is short of memory, idle network sockets are freed so the assistant itself is not killed. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) Net.trim()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Net.trim()
    }
}
