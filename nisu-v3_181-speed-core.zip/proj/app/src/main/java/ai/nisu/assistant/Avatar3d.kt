package ai.nisu.assistant

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Pure JVM rules for 3D Anime Avatar models (.glb, .gltf, .fbx) so unit tests run without Android dependencies.
 */
object Avatar3dRules {
    const val MAX_MODELS = 10
    const val MIN_SCALE = 0.5f
    const val MAX_SCALE = 2.5f
    const val DEFAULT_SCALE = 1.0f

    val SUPPORTED_EXTS = setOf("glb", "gltf", "fbx")

    val ACTIVITIES = listOf(
        "auto" to "Auto (Natural + Talk)",
        "idle" to "Calm Breathing",
        "wave" to "Cute Wave",
        "dance" to "Happy Sway / Dance",
        "nod" to "Head Nod",
        "jump" to "Excited Bounce",
        "spin" to "360\u00B0 Turn"
    )

    data class ModelItem(
        val id: String,
        val name: String,
        val fileName: String,
        val ext: String,
        val sizeBytes: Long
    )

    data class Cfg(
        val on: Boolean = false,
        val overlayOn: Boolean = true,
        val activeId: String = "",
        val scale: Float = DEFAULT_SCALE,
        val activity: String = "auto",
        val posX: Int = -1,
        val posY: Int = -1,
        val models: List<ModelItem> = emptyList()
    )

    fun extractExt(fileName: String): String {
        val clean = fileName.trim().substringAfterLast('/').substringAfterLast('\\')
        val dot = clean.lastIndexOf('.')
        if (dot < 0 || dot == clean.length - 1) return ""
        return clean.substring(dot + 1).lowercase()
    }

    fun isSupportedFile(fileName: String): Boolean = extractExt(fileName) in SUPPORTED_EXTS

    fun cleanDisplayName(rawName: String): String {
        val base = rawName.trim().substringAfterLast('/').substringAfterLast('\\').substringBeforeLast('.')
        val cleaned = base.replace(Regex("[_\\-]+"), " ").trim()
        return if (cleaned.isEmpty()) "Anime 3D Model" else cleaned.take(40)
    }

    fun clampScale(s: Float): Float = if (s.isNaN() || s.isInfinite()) DEFAULT_SCALE else s.coerceIn(MIN_SCALE, MAX_SCALE)

    fun usable(c: Cfg): Boolean = c.on && c.models.isNotEmpty() && activeModel(c) != null

    fun activeModel(c: Cfg): ModelItem? {
        if (c.models.isEmpty()) return null
        return c.models.firstOrNull { it.id == c.activeId } ?: c.models.first()
    }

    fun afterRemove(c: Cfg, removedId: String): Cfg {
        val remaining = c.models.filter { it.id != removedId }
        val nextActive = if (c.activeId == removedId) (remaining.firstOrNull()?.id ?: "") else c.activeId
        return c.copy(
            models = remaining,
            activeId = nextActive,
            on = c.on && remaining.isNotEmpty()
        )
    }

    fun encodeModels(list: List<ModelItem>): String {
        val arr = JSONArray()
        for (m in list.take(MAX_MODELS)) {
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("name", m.name)
                    .put("fileName", m.fileName)
                    .put("ext", m.ext)
                    .put("sizeBytes", m.sizeBytes)
            )
        }
        return arr.toString()
    }

    fun decodeModels(json: String): List<ModelItem> {
        if (json.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val out = ArrayList<ModelItem>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id").trim()
                val name = o.optString("name").trim()
                val fn = o.optString("fileName").trim()
                val ext = o.optString("ext").trim().lowercase()
                val sz = o.optLong("sizeBytes", 0L)
                if (id.isNotEmpty() && fn.isNotEmpty() && ext in SUPPORTED_EXTS) {
                    out.add(ModelItem(id, name.ifEmpty { "Anime 3D Model" }, fn, ext, sz))
                }
            }
            out.distinctBy { it.id }.take(MAX_MODELS)
        } catch (_: Throwable) {
            emptyList()
        }
    }
}

/**
 * 3D Anime Character Manager + Always-On-Top Floating Screen Overlay (`TYPE_APPLICATION_OVERLAY`).
 *
 * Features:
 * - Supports importing `.glb`, `.gltf`, and `.fbx` 3D character models directly from device storage.
 * - Renders the 3D character on the Home screen AND in a floating window over all apps (survives minimize / home / other apps).
 * - Multi-touch pinch-to-zoom (resize smaller/bigger with fingers) and drag-to-move anywhere on the phone screen.
 * - Real-time lip-sync with `AppState.speechLevel()`, emotion reactions (`AppState.emotion`), and built-in activities.
 * - Full controls: Add Model, Activate, Turn Off, and Remove.
 */
object Avatar3d {
    private const val DIR = "avatar_3d"
    private const val K_ON = "av3d_on"
    private const val K_OVERLAY = "av3d_overlay_on"
    private const val K_ACTIVE = "av3d_active_id"
    private const val K_SCALE = "av3d_scale"
    private const val K_ACT = "av3d_activity"
    private const val K_POS_X = "av3d_pos_x"
    private const val K_POS_Y = "av3d_pos_y"
    private const val K_MODELS = "av3d_models_json"

    private const val VIRTUAL_HOST = "https://nisu3d.local"
    private val seq = AtomicInteger(0)

    val cfg = MutableStateFlow(Avatar3dRules.Cfg())
    /** True while MainActivity is in the foreground on the HOME screen so we don't duplicate if user only wants overlay outside, or we can show overlay anytime. */
    val inAppHome = MutableStateFlow(false)

    private var app: Application? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var overlayView: FloatingAvatarView? = null
    private var overlayLp: WindowManager.LayoutParams? = null

    private fun dir(ctx: Context): File = File(ctx.filesDir, DIR)

    fun init(a: Application) {
        app = a
        sync(a)
        scope.launch {
            combine(cfg, AppState.running, AppState.emotion, AppState.thinking) { _, _, _, _ -> 0 }.collect {
                updateOverlay()
            }
        }
    }

    fun sync(ctx: Context) {
        val d = dir(ctx)
        val savedModels = Avatar3dRules.decodeModels(Prefs.get(ctx, K_MODELS, ""))
            .filter { File(d, it.fileName).isFile }
        val activeId = Prefs.get(ctx, K_ACTIVE, "").let { act ->
            if (savedModels.any { it.id == act }) act else (savedModels.firstOrNull()?.id ?: "")
        }
        val on = Prefs.getBool(ctx, K_ON, false) && savedModels.isNotEmpty()
        val overlayOn = Prefs.getBool(ctx, K_OVERLAY, true)
        val scale = Avatar3dRules.clampScale(Prefs.get(ctx, K_SCALE, "1.0").toFloatOrNull() ?: 1.0f)
        val activity = Prefs.get(ctx, K_ACT, "auto").ifBlank { "auto" }
        val px = Prefs.getInt(ctx, K_POS_X, -1)
        val py = Prefs.getInt(ctx, K_POS_Y, -1)
        cfg.value = Avatar3dRules.Cfg(
            on = on,
            overlayOn = overlayOn,
            activeId = activeId,
            scale = scale,
            activity = activity,
            posX = px,
            posY = py,
            models = savedModels
        )
    }

    @Synchronized
    private fun update(ctx: Context, f: (Avatar3dRules.Cfg) -> Avatar3dRules.Cfg) {
        val next = f(cfg.value)
        Prefs.putBool(ctx, K_ON, next.on)
        Prefs.putBool(ctx, K_OVERLAY, next.overlayOn)
        Prefs.put(ctx, K_ACTIVE, next.activeId)
        Prefs.put(ctx, K_SCALE, next.scale.toString())
        Prefs.put(ctx, K_ACT, next.activity)
        Prefs.putInt(ctx, K_POS_X, next.posX)
        Prefs.putInt(ctx, K_POS_Y, next.posY)
        Prefs.put(ctx, K_MODELS, Avatar3dRules.encodeModels(next.models))
        cfg.value = next
        main.post { updateOverlay() }
    }

    fun setOn(ctx: Context, on: Boolean) = update(ctx) { c ->
        val validOn = on && c.models.isNotEmpty()
        val actId = if (c.activeId.isNotEmpty()) c.activeId else (c.models.firstOrNull()?.id ?: "")
        c.copy(on = validOn, activeId = actId)
    }

    fun setOverlayOn(ctx: Context, overlayOn: Boolean) = update(ctx) { c ->
        c.copy(overlayOn = overlayOn)
    }

    fun activateModel(ctx: Context, id: String) = update(ctx) { c ->
        if (c.models.none { it.id == id }) c else c.copy(activeId = id, on = true)
    }

    fun setScale(ctx: Context, scale: Float) = update(ctx) { c ->
        c.copy(scale = Avatar3dRules.clampScale(scale))
    }

    fun setActivity(ctx: Context, activity: String) = update(ctx) { c ->
        c.copy(activity = activity)
    }

    fun savePosition(ctx: Context, x: Int, y: Int) = update(ctx) { c ->
        c.copy(posX = x, posY = y)
    }

    fun removeModel(ctx: Context, id: String) {
        val appCtx = ctx.applicationContext
        val target = cfg.value.models.firstOrNull { it.id == id }
        if (target != null) {
            try { File(dir(appCtx), target.fileName).delete() } catch (_: Throwable) {}
        }
        update(appCtx) { c -> Avatar3dRules.afterRemove(c, id) }
    }

    fun removeAll(ctx: Context) {
        val appCtx = ctx.applicationContext
        cfg.value.models.forEach {
            try { File(dir(appCtx), it.fileName).delete() } catch (_: Throwable) {}
        }
        update(appCtx) { c -> c.copy(on = false, activeId = "", models = emptyList()) }
    }

    /**
     * Imports a `.glb`, `.gltf`, or `.fbx` file from a content Uri into private app storage and activates it immediately.
     */
    fun importModel(ctx: Context, uri: Uri, done: ( Avatar3dRules.ModelItem?, String ) -> Unit) {
        val appCtx = ctx.applicationContext
        Thread {
            try {
                val cr = appCtx.contentResolver
                var origName = ""
                cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) origName = cursor.getString(idx) ?: ""
                    }
                }
                if (origName.isBlank()) {
                    origName = uri.lastPathSegment ?: "model.glb"
                }
                var ext = Avatar3dRules.extractExt(origName)
                if (ext !in Avatar3dRules.SUPPORTED_EXTS) {
                    // Check MIME or magic header bytes (GLB starts with "glTF" = 0x67 0x6C 0x54 0x46)
                    val header = ByteArray(24)
                    val read = cr.openInputStream(uri)?.use { it.read(header) } ?: 0
                    val magic = if (read >= 4) String(header, 0, 4, Charsets.US_ASCII) else ""
                    val fbxMagic = if (read >= 18) String(header, 0, 18, Charsets.US_ASCII) else ""
                    ext = when {
                        magic == "glTF" -> "glb"
                        fbxMagic.contains("Kaydara FBX") -> "fbx"
                        else -> ""
                    }
                }
                if (ext !in Avatar3dRules.SUPPORTED_EXTS) {
                    main.post { done(null, "Only .glb, .gltf, and .fbx 3D model files are supported.") }
                    return@Thread
                }

                val d = dir(appCtx)
                d.mkdirs()
                val id = "m" + java.lang.Long.toString(System.currentTimeMillis(), 36) + seq.incrementAndGet()
                val storedName = "$id.$ext"
                val destFile = File(d, storedName)

                var bytesCopied = 0L
                cr.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val r = input.read(buf)
                            if (r <= 0) break
                            output.write(buf, 0, r)
                            bytesCopied += r
                        }
                    }
                }
                if (bytesCopied <= 0L || !destFile.isFile) {
                    destFile.delete()
                    main.post { done(null, "Could not read the selected 3D file.") }
                    return@Thread
                }

                val item = Avatar3dRules.ModelItem(
                    id = id,
                    name = Avatar3dRules.cleanDisplayName(origName),
                    fileName = storedName,
                    ext = ext,
                    sizeBytes = bytesCopied
                )
                update(appCtx) { c ->
                    val updatedList = (listOf(item) + c.models).take(Avatar3dRules.MAX_MODELS)
                    c.copy(
                        on = true,
                        activeId = item.id,
                        models = updatedList
                    )
                }
                // Ensure background service is running if possible so the overlay survives app close
                try { NisuBackgroundService.start(appCtx, persist = true) } catch (_: Throwable) {}
                main.post { done(item, "3D model \"${item.name}\" (.${item.ext.uppercase()}) added and activated!") }
            } catch (e: Throwable) {
                main.post { done(null, "Error importing 3D model: " + (e.message ?: "unknown error")) }
            }
        }.start()
    }

    @Composable
    fun active(): Boolean = Avatar3dRules.usable(cfg.collectAsState().value)

    fun canDrawOverlays(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    // ------------------------------------------------------------------------------------ WebView 3D Engine Bridge

    @SuppressLint("SetJavaScriptEnabled")
    internal fun createConfiguredWebView(ctx: Context): WebView {
        val appCtx = ctx.applicationContext
        return WebView(appCtx).apply {
            setBackgroundColor(AndroidColor.TRANSPARENT)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_NO_CACHE
            }

            webViewClient = AssetClient(appCtx)   // v3.162: ONE shared client, created once per WebView (never per request)
        }
    }

    /**
     * v3.162: serves the 3D viewer page (the assets three folder) and the saved models (the avatar_3d folder) for every 3D WebView.
     * shouldInterceptRequest runs on a background thread, so it must never create a WebView or touch a View.
     */
    internal open class AssetClient(private val appCtx: Context) : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            val url = request?.url ?: return null
            if (url.host != "nisu3d.local") return super.shouldInterceptRequest(view, request)
            val path = (url.path ?: "").removePrefix("/")
            return try {
                if (path.startsWith("models/")) {
                    val fileName = path.removePrefix("models/")
                    val f = File(dir(appCtx), fileName)
                    if (!f.isFile) return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    val mime = when {
                        fileName.endsWith(".glb", true) -> "model/gltf-binary"
                        fileName.endsWith(".gltf", true) -> "model/gltf+json"
                        fileName.endsWith(".fbx", true) -> "application/octet-stream"
                        else -> "application/octet-stream"
                    }
                    WebResourceResponse(
                        mime,
                        null,
                        200,
                        "OK",
                        mapOf("Access-Control-Allow-Origin" to "*"),
                        FileInputStream(f)
                    )
                } else {
                    val assetName = if (path.isEmpty()) "viewer.html" else path
                    val stream = appCtx.assets.open("three/$assetName")
                    val mime = when {
                        assetName.endsWith(".html") -> "text/html"
                        assetName.endsWith(".js") -> "application/javascript"
                        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(assetName.substringAfterLast('.', "")) ?: "application/octet-stream"
                    }
                    WebResourceResponse(
                        mime,
                        "UTF-8",
                        200,
                        "OK",
                        mapOf("Access-Control-Allow-Origin" to "*"),
                        stream
                    )
                }
            } catch (_: Throwable) {
                null
            }
        }
    }

    // ------------------------------------------------------------------------------------ In-App Home Composable View

    @Composable
    fun HomeScene(
        modifier: Modifier = Modifier,
        speech: () -> Float = { 0f },
        emotion: String = "calm",
        thinking: () -> Boolean = { false },
        attentive: () -> Boolean = { false }
    ) {
        val c by cfg.collectAsState()
        val activeModel = Avatar3dRules.activeModel(c) ?: return
        var loadedId by remember { mutableStateOf("") }
        var loadedAct by remember { mutableStateOf("") }
        var webViewRef by remember { mutableStateOf<WebView?>(null) }

        DisposableEffect(Unit) {
            inAppHome.value = true
            updateOverlay()
            onDispose {
                inAppHome.value = false
                webViewRef?.destroy()
                webViewRef = null
                updateOverlay()
            }
        }

        // Push 25fps lip-sync, emotion, thinking, attentive, and activity updates to the 3D scene
        LaunchedEffect(activeModel.id, c.activity) {
            while (true) {
                val wv = webViewRef
                if (wv != null) {
                    if (loadedId != activeModel.id) {
                        val url = "$VIRTUAL_HOST/models/${activeModel.fileName}"
                        val safeName = activeModel.name.replace("'", "\\'")
                        wv.evaluateJavascript(
                            "if(window.Nisu3D){window.Nisu3D.loadModel('$url','${activeModel.ext}','$safeName');}",
                            null
                        )
                        loadedId = activeModel.id
                    }
                    if (loadedAct != c.activity) {
                        wv.evaluateJavascript("if(window.Nisu3D){window.Nisu3D.setActivity('${c.activity}');}", null)
                        loadedAct = c.activity
                    }
                    val sp = speech()
                    val th = thinking()
                    val at = attentive()
                    wv.evaluateJavascript(
                        "if(window.Nisu3D){window.Nisu3D.updateState($sp,'$emotion',$th,$at,'${c.activity}');}",
                        null
                    )
                }
                delay(40L)
            }
        }

        Box(modifier.fillMaxSize()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    createConfiguredWebView(context).apply {
                        webViewClient = object : AssetClient(context.applicationContext) {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                val modelUrl = "$VIRTUAL_HOST/models/${activeModel.fileName}"
                                val safeName = activeModel.name.replace("'", "\\'")
                                view?.evaluateJavascript(
                                    "if(window.Nisu3D){window.Nisu3D.loadModel('$modelUrl','${activeModel.ext}','$safeName');}",
                                    null
                                )
                                loadedId = activeModel.id
                            }
                        }
                        loadUrl("$VIRTUAL_HOST/viewer.html")
                        webViewRef = this
                    }
                }
            )
        }
    }

    // ------------------------------------------------------------------------------------ System-Wide Floating 3D Overlay

    private fun shouldShowOverlay(a: Application): Boolean {
        val c = cfg.value
        return Avatar3dRules.usable(c) && c.overlayOn && canDrawOverlays(a)
    }

    fun updateOverlay() {
        val a = app ?: return
        if (shouldShowOverlay(a)) {
            showOverlay(a)
            overlayView?.syncWithConfig(cfg.value)
        } else {
            hideOverlay(a)
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(a: Application): Pair<Int, Int> = try {
        val wm = a.getSystemService(WindowManager::class.java)
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    } catch (_: Throwable) {
        1080 to 2400
    }

    private fun computeOverlayDimensions(a: Application, scale: Float): Pair<Int, Int> {
        val dens = a.resources.displayMetrics.density
        val s = Avatar3dRules.clampScale(scale)
        val baseW = (210f * dens * s).roundToInt().coerceIn((115f * dens).roundToInt(), (450f * dens).roundToInt())
        val baseH = (320f * dens * s).roundToInt().coerceIn((175f * dens).roundToInt(), (660f * dens).roundToInt())
        return baseW to baseH
    }

    private fun showOverlay(a: Application) {
        if (overlayView != null) return
        val c = cfg.value
        val (w, h) = computeOverlayDimensions(a, c.scale)
        val (sw, sh) = screenSize(a)
        val startX = if (c.posX >= 0) c.posX.coerceIn(0, (sw - w).coerceAtLeast(0)) else (sw - w - (16 * a.resources.displayMetrics.density).toInt()).coerceAtLeast(0)
        val startY = if (c.posY >= 0) c.posY.coerceIn(0, (sh - h).coerceAtLeast(0)) else (sh / 4)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            w,
            h,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
        }

        val v = FloatingAvatarView(a)
        try {
            a.getSystemService(WindowManager::class.java).addView(v, lp)
            overlayView = v
            overlayLp = lp
        } catch (_: Throwable) {
            overlayView = null
            overlayLp = null
        }
    }

    private fun hideOverlay(a: Application) {
        val v = overlayView ?: return
        overlayView = null
        overlayLp = null
        v.dispose()
        try {
            a.getSystemService(WindowManager::class.java).removeView(v)
        } catch (_: Throwable) {}
    }

    internal fun resizeAndMoveOverlay(newScale: Float? = null, newX: Int? = null, newY: Int? = null, persist: Boolean = false) {
        val a = app ?: return
        val v = overlayView ?: return
        val lp = overlayLp ?: return
        val (sw, sh) = screenSize(a)

        val s = newScale?.let { Avatar3dRules.clampScale(it) } ?: cfg.value.scale
        val (w, h) = computeOverlayDimensions(a, s)
        lp.width = w
        lp.height = h
        if (newX != null) lp.x = newX.coerceIn(-w / 3, (sw - w * 2 / 3).coerceAtLeast(0))
        if (newY != null) lp.y = newY.coerceIn(0, (sh - h / 2).coerceAtLeast(0))

        try {
            a.getSystemService(WindowManager::class.java).updateViewLayout(v, lp)
        } catch (_: Throwable) {}

        if (persist) {
            update(a) { c -> c.copy(scale = s, posX = lp.x, posY = lp.y) }
        }
    }

    /**
     * Touch-enabled Floating 3D Character Window:
     * - 1-finger drag moves the character anywhere on the screen.
     * - 2-finger pinch-to-zoom scales the character bigger or smaller smoothly.
     * - Double-tap cycles through cute activities (Auto -> Wave -> Dance -> Nod -> Jump -> Spin) or shows quick mini controls.
     */
    private class FloatingAvatarView(context: Context) : FrameLayout(context) {
        private val webView: WebView = createConfiguredWebView(context)
        private var loadedModelId = ""
        private var loadedActivity = ""
        private var pageReady = false
        private var alive = true
        private var liveScale = cfg.value.scale

        private var downRawX = 0f
        private var downRawY = 0f
        private var startWinX = 0
        private var startWinY = 0
        private var dragging = false
        private var pinching = false
        private var lastTapMs = 0L

        private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                pinching = true
                liveScale = cfg.value.scale
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                liveScale = Avatar3dRules.clampScale(liveScale * detector.scaleFactor)
                resizeAndMoveOverlay(newScale = liveScale, persist = false)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                resizeAndMoveOverlay(newScale = liveScale, persist = true)
            }
        })

        private val tickRunnable = object : Runnable {
            override fun run() {
                if (!alive) return
                if (pageReady) {
                    val c = cfg.value
                    val m = Avatar3dRules.activeModel(c)
                    if (m != null && m.id != loadedModelId) {
                        val url = "$VIRTUAL_HOST/models/${m.fileName}"
                        val safeName = m.name.replace("'", "\\'")
                        webView.evaluateJavascript(
                            "if(window.Nisu3D){window.Nisu3D.loadModel('$url','${m.ext}','$safeName');}",
                            null
                        )
                        loadedModelId = m.id
                    }
                    if (c.activity != loadedActivity) {
                        webView.evaluateJavascript("if(window.Nisu3D){window.Nisu3D.setActivity('${c.activity}');}", null)
                        loadedActivity = c.activity
                    }
                    val sp = if (AppState.running.value) AppState.speechLevel() else 0f
                    val emo = if (AppState.running.value) AppState.emotion.value else "calm"
                    val th = AppState.running.value && AppState.thinking.value
                    val att = AppState.running.value && !AppState.muted.value
                    webView.evaluateJavascript(
                        "if(window.Nisu3D){window.Nisu3D.updateState($sp,'$emo',$th,$att,'${c.activity}');}",
                        null
                    )
                }
                main.postDelayed(this, 45L)
            }
        }

        init {
            setBackgroundColor(AndroidColor.TRANSPARENT)
            clipChildren = false
            clipToPadding = false

            webView.isClickable = false
            webView.isFocusable = false
            webView.webViewClient = object : AssetClient(context.applicationContext) {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageReady = true
                    loadedModelId = ""
                }
            }
            addView(webView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            webView.loadUrl("$VIRTUAL_HOST/viewer.html")
            main.post(tickRunnable)
        }

        fun syncWithConfig(c: Avatar3dRules.Cfg) {
            if (!pinching) {
                liveScale = c.scale
                resizeAndMoveOverlay(newScale = c.scale, persist = false)
            }
        }

        override fun onConfigurationChanged(newConfig: Configuration?) {
            super.onConfigurationChanged(newConfig)
            post { resizeAndMoveOverlay(persist = false) }
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            scaleDetector.onTouchEvent(event)
            val lp = overlayLp ?: return true

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pinching = false
                    dragging = false
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = lp.x
                    startWinY = lp.y
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    pinching = true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!pinching && event.pointerCount == 1) {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        if (dragging || hypot(dx.toDouble(), dy.toDouble()) > 8.0) {
                            dragging = true
                            resizeAndMoveOverlay(
                                newX = (startWinX + dx.roundToInt()),
                                newY = (startWinY + dy.roundToInt()),
                                persist = false
                            )
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        resizeAndMoveOverlay(newX = lp.x, newY = lp.y, persist = true)
                    } else if (!pinching && abs(event.rawX - downRawX) < 12f && abs(event.rawY - downRawY) < 12f) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTapMs < 350L) {
                            // Double tap cycles through built-in 3D activities
                            val acts = Avatar3dRules.ACTIVITIES.map { it.first }
                            val idx = (acts.indexOf(cfg.value.activity) + 1) % acts.size
                            setActivity(context, acts[idx])
                        }
                        lastTapMs = now
                    }
                    dragging = false
                    pinching = false
                }
            }
            return true
        }

        fun dispose() {
            alive = false
            main.removeCallbacks(tickRunnable)
            try {
                removeView(webView)
                webView.destroy()
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------------------------ Compose Management Panel UI

    @Composable
    fun ManagerSection(onPickFile: () -> Unit, onRequestOverlayPerm: () -> Unit) {
        val ctx = LocalContext.current
        val c by cfg.collectAsState()
        val hasOverlayPerm = canDrawOverlays(ctx)
        var scaleVal by remember(c.scale) { mutableFloatStateOf(c.scale) }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("3D Anime Character (.GLB / .FBX)", fontSize = 16.sp, color = NisuUi.Cyan, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Add your own 3D anime girl model (.glb, .gltf, or .fbx) from your phone files. " +
                            "She breathes, blinks, moves naturally, lip-syncs with NISU AI's voice, and floats anywhere on your screen even when you minimize or close the app.",
                        fontSize = 12.sp,
                        color = NisuUi.Muted
                    )
                }
            }

            // Status & Master Active / Off controls
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MChip(
                    text = if (c.on && c.models.isNotEmpty()) "3D MODEL: ACTIVE" else "ACTIVATE 3D MODEL",
                    color = if (c.on && c.models.isNotEmpty()) NisuUi.Green else NisuUi.Cyan,
                    enabled = true
                ) {
                    if (c.models.isEmpty()) {
                        onPickFile()
                    } else {
                        setOn(ctx, true)
                    }
                }
                MChip(
                    text = "TURN OFF",
                    color = if (!c.on) NisuUi.Amber else NisuUi.Muted,
                    enabled = c.on
                ) {
                    setOn(ctx, false)
                }
                MChip(
                    text = "+ ADD .GLB / .FBX",
                    color = NisuUi.Cyan
                ) {
                    onPickFile()
                }
            }

            // Always-on-screen Floating Overlay toggle & permission check
            Column(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(NisuUi.CardHi.copy(alpha = 0.55f))
                    .border(1.dp, NisuUi.Line, RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Always on Screen (Floating 3D Overlay)", fontSize = 14.sp, color = NisuUi.Text)
                        Text(
                            if (!hasOverlayPerm) "Needs 'Display over other apps' permission so she stays on screen when you leave or close the app."
                            else if (c.overlayOn) "ON: Stays on screen over all apps. Drag with 1 finger to move anywhere, pinch with 2 fingers to resize!"
                            else "OFF: Only shows inside the NISU AI home screen.",
                            fontSize = 11.sp,
                            color = if (!hasOverlayPerm) NisuUi.Amber else if (c.overlayOn) NisuUi.Green else NisuUi.Muted
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    if (!hasOverlayPerm) {
                        MChip("ALLOW OVERLAY", color = NisuUi.Amber) { onRequestOverlayPerm() }
                    } else {
                        MChip(if (c.overlayOn) "OVERLAY ON" else "OVERLAY OFF", color = if (c.overlayOn) NisuUi.Cyan else NisuUi.Muted) {
                            setOverlayOn(ctx, !c.overlayOn)
                        }
                    }
                }
            }

            // Size / Pinch Scale slider
            if (c.models.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Character Size: ${(scaleVal * 100).roundToInt()}%  (You can also pinch with 2 fingers directly on the model)",
                        fontSize = 13.sp,
                        color = NisuUi.Text
                    )
                    Slider(
                        value = scaleVal,
                        onValueChange = {
                            scaleVal = it
                            resizeAndMoveOverlay(newScale = it, persist = false)
                        },
                        valueRange = Avatar3dRules.MIN_SCALE..Avatar3dRules.MAX_SCALE,
                        onValueChangeFinished = { setScale(ctx, scaleVal) },
                        colors = SliderDefaults.colors(
                            thumbColor = NisuUi.Cyan,
                            activeTrackColor = NisuUi.Cyan,
                            inactiveTrackColor = NisuUi.Line
                        )
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MChip("SMALLER") {
                            val s = Avatar3dRules.clampScale(scaleVal - 0.2f)
                            scaleVal = s
                            setScale(ctx, s)
                        }
                        MChip("DEFAULT (100%)") {
                            scaleVal = 1.0f
                            setScale(ctx, 1.0f)
                        }
                        MChip("BIGGER") {
                            val s = Avatar3dRules.clampScale(scaleVal + 0.2f)
                            scaleVal = s
                            setScale(ctx, s)
                        }
                        MChip("CENTER SCREEN") {
                            savePosition(ctx, -1, -1)
                            resizeAndMoveOverlay(newX = 120, newY = 260, persist = true)
                        }
                    }
                }

                // Built-in Movement & Activity Selector
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Built-in 3D Movement & Activity (Double-tap model to switch)", fontSize = 13.sp, color = NisuUi.Cyan)
                    Avatar3dRules.ACTIVITIES.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (actId, label) ->
                                val selected = c.activity == actId
                                MChip(
                                    text = label,
                                    color = if (selected) NisuUi.Cyan else NisuUi.Muted
                                ) {
                                    setActivity(ctx, actId)
                                }
                            }
                        }
                    }
                }

                // Saved 3D Models List (Active / Off / Remove per model)
                Text("Your 3D Models (${c.models.size} / ${Avatar3dRules.MAX_MODELS})", fontSize = 14.sp, color = NisuUi.Cyan)
                c.models.forEach { item ->
                    val isCurrent = c.on && (c.activeId == item.id || (c.activeId.isEmpty() && c.models.firstOrNull()?.id == item.id))
                    Column(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isCurrent) NisuUi.Cyan.copy(alpha = 0.12f) else NisuUi.Card)
                            .border(1.dp, if (isCurrent) NisuUi.Cyan else NisuUi.Line, RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                Modifier.size(36.dp).clip(CircleShape)
                                    .background(if (isCurrent) NisuUi.Cyan.copy(alpha = 0.25f) else NisuUi.CardHi),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(item.ext.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NisuUi.Cyan)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.name,
                                    fontSize = 14.sp,
                                    color = NisuUi.Text,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1
                                )
                                val mb = "%.2f MB".format(item.sizeBytes / (1024.0 * 1024.0))
                                Text(
                                    "${item.ext.uppercase()} 3D Model  \u2022  $mb" + (if (isCurrent) "  \u2022  ACTIVE" else ""),
                                    fontSize = 11.sp,
                                    color = if (isCurrent) NisuUi.Green else NisuUi.Muted,
                                    maxLines = 1
                                )
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isCurrent) {
                                MChip("TURN OFF", color = NisuUi.Amber) {
                                    setOn(ctx, false)
                                }
                            } else {
                                MChip("ACTIVATE", color = NisuUi.Cyan) {
                                    activateModel(ctx, item.id)
                                }
                            }
                            MChip("REMOVE", color = NisuUi.Red) {
                                removeModel(ctx, item.id)
                            }
                        }
                    }
                }
            } else {
                Text(
                    "No 3D model added yet. Tap '+ ADD .GLB / .FBX' above to pick any .glb or .fbx anime girl file from your phone.",
                    fontSize = 12.sp,
                    color = NisuUi.Muted
                )
            }
        }
    }
}
