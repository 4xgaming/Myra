package ai.nisu.assistant

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/**
 * v3.181: ONE shared network core for the whole app.
 *
 * Before, every feature (Text chat, Main Brain, Helper, Voice message, WhatsApp voice notes, ElevenLabs, Game Auto Play, Live voice ...)
 * built its own OkHttpClient. Each one had its own connection pool and its own thread pool, so a TLS connection that was already open to
 * generativelanguage.googleapis.com in one feature was useless to the next one: every first request paid DNS + TCP + TLS again
 * (often 300-800 ms on mobile data) and the phone kept many idle sockets and threads alive.
 *
 * Now every client is made with [client] (= [base].newBuilder()), which keeps each feature's own time limits but SHARES the connection pool
 * and the dispatcher. A connection warmed by any feature (or by [warm]) is reused by all others (HTTP/2 multiplexing to Google), so the first
 * answer starts sooner, and memory / battery use go down.
 */
object Net {
    const val GEMINI_HOST = "https://generativelanguage.googleapis.com/"

    /** Keeps up to 8 idle connections for 5 minutes: enough for Gemini, ElevenLabs, Firebase and the hidden browser together. */
    private val pool = ConnectionPool(8, 5, TimeUnit.MINUTES)

    private val dispatcher = Dispatcher().apply {
        maxRequests = 64   // OkHttp default: long-lived Live WebSockets each hold one slot, so the total is kept high
        maxRequestsPerHost = 10
    }

    /** The base client. Do not change its time limits; make a copy with [client] instead. */
    val base: OkHttpClient = OkHttpClient.Builder()
        .connectionPool(pool)
        .dispatcher(dispatcher)
        .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
        .retryOnConnectionFailure(true)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    /** A client with its own settings that still shares the pool and threads of [base]. */
    fun client(cfg: OkHttpClient.Builder.() -> Unit = {}): OkHttpClient = base.newBuilder().apply(cfg).build()

    /** Short-lived client only for warming: never blocks a thread for long. */
    private val warmHttp: OkHttpClient by lazy { client { connectTimeout(5, TimeUnit.SECONDS); readTimeout(5, TimeUnit.SECONDS); callTimeout(7, TimeUnit.SECONDS) } }

    private val lastWarm = AtomicLong(0L)

    /**
     * Opens (or refreshes) the shared HTTP/2 connection to Google in the background, so the next Gemini call starts at once.
     * Cheap: at most one real warm-up every 60 s, it never throws and never runs on the caller's thread.
     */
    fun warm(url: String = GEMINI_HOST) {
        val now = System.currentTimeMillis()
        val prev = lastWarm.get()
        if (now - prev < 60_000L || !lastWarm.compareAndSet(prev, now)) return
        val t = Thread({
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
            try { warmHttp.newCall(Request.Builder().url(url).head().build()).execute().close() } catch (_: Throwable) {}
        }, "nisu-net-warm")
        t.isDaemon = true
        try { t.start() } catch (_: Throwable) {}
    }

    /** Frees idle sockets (called when the system says memory is low). Active calls are not touched. */
    fun trim() { try { pool.evictAll() } catch (_: Throwable) {} }
}

/**
 * v3.181: regular expressions that were compiled again on every call in hot paths (every screen node, every spoken sentence,
 * every chat line). Compiling a Regex costs far more than using one; now each is compiled once.
 */
internal object Rx {
    val SPACES = Regex("\\s+")
    val TABS2 = Regex("[ \\t]{2,}")
    val SPACE_BEFORE_PUNCT = Regex("\\s+([,.!?।])")
    val MARKDOWN = Regex("[*#_`~<>|]")
    val NOT_LETTER_DIGIT = Regex("[^\\p{L}\\p{N}]")
    val NUM4 = Regex("(?:\\d[ -]?){4,}")
    val NUM6 = Regex("(?:\\d[ -]?){6,}")
    val HTML_TAG = Regex("<[^>]+>")
    val HTML_ENTITY_NUM = Regex("&#(\\d{2,5});")
    val HTML_BLOCKS = Regex("<(script|style|noscript|svg|head|template|nav|footer)[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    val HTML_COMMENT = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
    val HTML_BREAKS = Regex("<(br|/p|/div|/li|/h[1-6]|/tr|/section|/article)[^>]*>", RegexOption.IGNORE_CASE)
    val HSPACE_NBSP = Regex("[ \\t\\u00A0]+")
    val SPACE_PUNCT = Regex(" +([.,!?])")
    val NL3 = Regex("\\n{3,}")
    val WORD_SPLIT = Regex("[^\\p{L}\\p{M}]+")
    val WORD_SPLIT_N = Regex("[^\\p{L}\\p{M}\\p{N}]+")
}
