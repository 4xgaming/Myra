package ai.nisu.assistant

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File

/*
 * v3.164: PROFESSIONAL LIVE CODE VIEWER & STUDIO ENGINE.
 * Every time the Main Brain writes code (a website, an APK app, a design plan, a build fix, a CodeWriter snippet,
 * or a code block in typed chat) the files appear on the "Live Code" page WHILE they are being written (streamed in real time)
 * AND stay available at all times by loading saved Website / App projects on demand.
 */
class CodeFile(
    val path: String,
    val content: String,
    val rev: Int,
    val kind: String,
    val who: String,
    val at: Long,
    val project: String = "",
    val projectType: String = "" // "website" | "app" | "snippet" | ""
)

data class LiveSnap(
    val files: List<CodeFile> = emptyList(),
    val busy: Boolean = false,
    val step: String = "",
    val who: String = "",
    val startedAt: Long = 0L,
    val error: String = "",
    /** A short remark for the status line ("the model is busy, trying again in 20 s"). */
    val note: String = "",
    /** Counts every publish so the page knows a new file arrived and types it out. */
    val tick: Int = 0,
    /** Currently active project slug ("my-portfolio", "calculator", etc.). */
    val activeProject: String = "",
    /** Currently active project type ("website" or "app"). */
    val activeType: String = "",
    /** LocalWeb URL of the latest built website, ready to run in-app or in browser. */
    val websiteUrl: String = "",
    /** Last exported ZIP or built APK path for quick actions. */
    val lastSavedZip: String = "",
    val lastBuiltApk: String = ""
)

/** Pure helpers (no Android classes): JVM-testable. */
object LiveCodeRules {
    const val MAX_FILES = 80
    const val MAX_FILE_CHARS = 300_000
    const val MAX_TOTAL_CHARS = 900_000

    class Block(val lang: String, val code: String)

    /** Fenced code blocks (``` or ~~~) of a chat answer. An unclosed last block is kept (a long answer that was cut off or is still streaming). */
    fun fences(text: String): List<Block> {
        val out = ArrayList<Block>()
        var lang = ""
        var inBlock = false
        val sb = StringBuilder()
        for (line in text.lines()) {
            val t = line.trimStart()
            if (t.startsWith("```") || t.startsWith("~~~")) {
                if (!inBlock) {
                    inBlock = true
                    lang = t.drop(3).trim().lowercase().takeWhile { it.isLetterOrDigit() || it in "+#-_." }
                    sb.clear()
                } else {
                    inBlock = false
                    if (sb.isNotBlank()) out.add(Block(lang, sb.toString().trimEnd('\n')))
                    sb.clear()
                }
            } else if (inBlock) {
                sb.append(line).append('\n')
            }
        }
        if (inBlock && sb.isNotBlank()) out.add(Block(lang, sb.toString().trimEnd('\n')))
        return out
    }

    private class Str(val v: String, val end: Int, val complete: Boolean)

    /** Reads a JSON string whose opening quote is just before [start]; an unfinished string (text cut off) comes back with complete = false. */
    private fun readStr(t: String, start: Int): Str {
        val sb = StringBuilder()
        var j = start
        val n = t.length
        while (j < n) {
            val c = t[j]
            if (c == '"') return Str(sb.toString(), j + 1, true)
            if (c == '\\') {
                if (j + 1 >= n) return Str(sb.toString(), n, false)
                when (val e = t[j + 1]) {
                    'n' -> { sb.append('\n'); j += 2 }
                    't' -> { sb.append('\t'); j += 2 }
                    'r' -> { j += 2 }
                    'b', 'f' -> { j += 2 }
                    'u' -> {
                        if (j + 6 > n) return Str(sb.toString(), n, false)
                        val code = t.substring(j + 2, j + 6).toIntOrNull(16)
                        if (code != null) sb.append(code.toChar())
                        j += 6
                    }
                    else -> { sb.append(e); j += 2 }
                }
            } else {
                sb.append(c)
                j++
            }
        }
        return Str(sb.toString(), n, false)
    }

    /**
     * Extracts streaming files from ANY partial JSON response produced by the AI:
     * 1) {"files":[{"path":"a.html","content":"<html>..."}, ...]}
     * 2) {"edits":[{"path":"index.html","find":"...","replace":"..."}, ...]}
     * 3) {"code":"<!DOCTYPE html>..."} (from CodeWriter)
     * 4) {"brand":"...","sections":[...]} (from Website Design Brief)
     * Whatever is complete is returned, and the currently streaming item is returned even while cut off in the middle!
     */
    fun partialFiles(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        // 1. Check "files" array
        val k = text.indexOf("\"files\"")
        if (k >= 0) {
            var i = text.indexOf('[', k)
            if (i >= 0) {
                i++
                val n = text.length
                while (i < n) {
                    while (i < n && text[i] != '{' && text[i] != ']') i++
                    if (i >= n || text[i] == ']') break
                    i++
                    var path = ""
                    var pathOk = false
                    var content = ""
                    var closed = false
                    while (i < n) {
                        while (i < n && text[i] != '"' && text[i] != '}') i++
                        if (i >= n) break
                        if (text[i] == '}') { i++; closed = true; break }
                        val key = readStr(text, i + 1)
                        if (!key.complete) { i = n; break }
                        i = key.end
                        while (i < n && (text[i] == ' ' || text[i] == '\t' || text[i] == '\r' || text[i] == '\n' || text[i] == ':')) i++
                        if (i >= n) break
                        if (text[i] == '"') {
                            val v = readStr(text, i + 1)
                            if (key.v == "path") { path = v.v; pathOk = v.complete }
                            else if (key.v == "content") content = v.v
                            i = v.end
                            if (!v.complete) { i = n; break }
                        } else {
                            while (i < n && text[i] != ',' && text[i] != '}') i++
                        }
                    }
                    if (pathOk && path.isNotBlank()) out.add(path to content)
                    if (!closed) break
                }
            }
        }
        // 2. Check "edits" array (live diff preview while fixing/editing)
        val ke = text.indexOf("\"edits\"")
        if (ke >= 0) {
            var i = text.indexOf('[', ke)
            if (i >= 0) {
                i++
                val n = text.length
                while (i < n) {
                    while (i < n && text[i] != '{' && text[i] != ']') i++
                    if (i >= n || text[i] == ']') break
                    i++
                    var path = ""
                    var pathOk = false
                    var find = ""
                    var replace = ""
                    var closed = false
                    while (i < n) {
                        while (i < n && text[i] != '"' && text[i] != '}') i++
                        if (i >= n) break
                        if (text[i] == '}') { i++; closed = true; break }
                        val key = readStr(text, i + 1)
                        if (!key.complete) { i = n; break }
                        i = key.end
                        while (i < n && (text[i] == ' ' || text[i] == '\t' || text[i] == '\r' || text[i] == '\n' || text[i] == ':')) i++
                        if (i >= n) break
                        if (text[i] == '"') {
                            val v = readStr(text, i + 1)
                            when (key.v) {
                                "path" -> { path = v.v; pathOk = v.complete }
                                "find" -> find = v.v
                                "replace" -> replace = v.v
                            }
                            i = v.end
                            if (!v.complete) { i = n; break }
                        } else {
                            while (i < n && text[i] != ',' && text[i] != '}') i++
                        }
                    }
                    if (pathOk && path.isNotBlank() && (find.isNotEmpty() || replace.isNotEmpty())) {
                        val diffText = "- " + find.lines().joinToString("\n- ") + "\n+ " + replace.lines().joinToString("\n+ ")
                        out.add("$path (fix)" to diffText)
                    }
                    if (!closed) break
                }
            }
        }
        // 3. Check "code" field (CodeWriter single-file streaming)
        if (out.isEmpty()) {
            val kc = text.indexOf("\"code\"")
            if (kc >= 0) {
                var i = kc + 6
                val n = text.length
                while (i < n && (text[i] == ' ' || text[i] == '\t' || text[i] == '\r' || text[i] == '\n' || text[i] == ':')) i++
                if (i < n && text[i] == '"') {
                    val v = readStr(text, i + 1)
                    if (v.v.isNotBlank()) {
                        val ext = guessExtFromCode(v.v)
                        out.add("snippet.$ext" to v.v)
                    }
                }
            }
        }
        // 4. Check "brand" + "sections" (Design Brief streaming)
        if (out.isEmpty() && text.contains("\"brand\"") && (text.contains("\"palette\"") || text.contains("\"sections\""))) {
            val trimmed = text.trim()
            if (trimmed.startsWith("{")) {
                out.add("design-brief.json" to trimmed)
            }
        }
        return out
    }

    fun guessExtFromCode(code: String): String {
        val t = code.trimStart()
        return when {
            t.startsWith("<!DOCTYPE", ignoreCase = true) || t.startsWith("<html", ignoreCase = true) || t.startsWith("<div", ignoreCase = true) -> "html"
            t.startsWith("package ") || t.contains("fun ") && t.contains("val ") -> "kt"
            t.startsWith(":root") || (t.contains("{") && t.contains("color:") && t.contains("margin")) -> "css"
            t.startsWith("function ") || t.startsWith("const ") || t.startsWith("document.") -> "js"
            t.startsWith("def ") || t.startsWith("import ") && t.contains("print(") -> "py"
            t.startsWith("#!/") -> "sh"
            t.startsWith("{") && t.endsWith("}") -> "json"
            else -> "html"
        }
    }

    fun extFor(lang: String): String = when (lang) {
        "kotlin", "kt" -> "kt"; "java" -> "java"; "javascript", "js", "jsx" -> "js"; "typescript", "ts", "tsx" -> "ts"
        "python", "py" -> "py"; "html" -> "html"; "css" -> "css"; "json" -> "json"; "xml" -> "xml"; "bash", "sh", "shell" -> "sh"
        "c" -> "c"; "cpp", "c++" -> "cpp"; "go" -> "go"; "rust", "rs" -> "rs"; "php" -> "php"; "sql" -> "sql"; "yaml", "yml" -> "yml"
        "" -> "txt"; else -> lang.take(5)
    }

    /** Adds or replaces [f] by path (a new version of a file keeps its place and counts up), then applies the size limits (oldest files go first). */
    fun merge(
        list: List<CodeFile>,
        path: String,
        content: String,
        kind: String,
        who: String,
        now: Long,
        project: String = "",
        projectType: String = ""
    ): List<CodeFile> {
        val c = if (content.length > MAX_FILE_CHARS) content.take(MAX_FILE_CHARS) + "\n... (cut, ${content.length - MAX_FILE_CHARS} more characters)" else content
        val old = list.firstOrNull { it.path == path }
        // "live" = a half-written file that is still streaming in: it keeps its version number, and the finished file replaces it with the same number
        val rev = if (old == null) 1 else if (old.kind == "live" || kind == "live") old.rev else if (old.content == c) old.rev else old.rev + 1
        val proj = project.ifBlank { old?.project.orEmpty() }
        val pType = projectType.ifBlank { old?.projectType.orEmpty() }
        val nf = CodeFile(path, c, rev, kind, who, now, proj, pType)
        val idx = list.indexOfFirst { it.path == path }
        val res = ArrayList<CodeFile>(list.size + 1)
        if (idx >= 0 && (kind == "live" || old?.kind == "live")) {
            // Keep position in tab bar while streaming so tabs don't jump around on every chunk
            res.addAll(list)
            res[idx] = nf
        } else {
            res.addAll(list.filter { it.path != path })
            res.add(nf)
        }
        while (res.size > MAX_FILES || (res.size > 1 && res.sumOf { it.content.length } > MAX_TOTAL_CHARS)) res.removeAt(0)
        return res
    }
}

object LiveCode {
    val state = MutableStateFlow(LiveSnap())

    /** What the builder is doing right now ("writing the website", "fixing build errors"); set by the builders' status lines. */
    @Volatile var step: String = ""
    @Volatile var currentProject: String = ""
    @Volatile var currentProjectType: String = "" // "website" | "app" | "snippet"

    private fun upd(f: (LiveSnap) -> LiveSnap) { synchronized(this) { state.value = f(state.value) } }

    fun setProjectContext(project: String, type: String, url: String = "") {
        currentProject = project
        currentProjectType = type
        upd {
            it.copy(
                activeProject = project.ifBlank { it.activeProject },
                activeType = type.ifBlank { it.activeType },
                websiteUrl = url.ifBlank { it.websiteUrl }
            )
        }
    }

    fun setWebsiteUrl(url: String, project: String = "") = upd {
        it.copy(websiteUrl = url, activeProject = project.ifBlank { it.activeProject }, activeType = "website")
    }

    fun setLastZip(path: String) = upd { it.copy(lastSavedZip = path) }
    fun setLastApk(path: String) = upd { it.copy(lastBuiltApk = path) }

    fun begin(who: String) = upd {
        it.copy(
            busy = true,
            step = step,
            who = who,
            startedAt = System.currentTimeMillis(),
            error = "",
            note = "",
            activeProject = currentProject.ifBlank { it.activeProject },
            activeType = currentProjectType.ifBlank { it.activeType }
        )
    }

    fun note(msg: String) = upd { it.copy(note = msg.take(160), step = step.ifBlank { it.step }) }

    fun fail(msg: String) = upd { it.copy(busy = false, error = msg.take(200), step = step.ifBlank { it.step }) }

    fun done(who: String) = upd {
        val fixedFiles = it.files.map { f ->
            if (f.kind == "live") CodeFile(f.path, f.content, f.rev, "new", who.ifBlank { f.who }, f.at, f.project, f.projectType)
            else f
        }
        it.copy(busy = false, who = who, error = "", note = "", step = step.ifBlank { it.step }, files = fixedFiles)
    }

    fun clear() = upd { LiveSnap() }

    fun files(
        items: List<Pair<String, String>>,
        who: String,
        kind: String = "new",
        project: String = currentProject,
        projectType: String = currentProjectType
    ) = upd { s ->
        var l = s.files
        var fresh = false      // a file that was not on the page yet, or one that was not streaming: the page jumps to it
        val now = System.currentTimeMillis()
        items.forEach { (p, c) ->
            if (p.isNotBlank() && c.isNotEmpty()) {
                val path = p.take(160)
                val old = l.firstOrNull { it.path == path }
                if (old == null || (old.kind != "live" && kind != "live" && old.content != c)) fresh = true
                l = LiveCodeRules.merge(l, path, c, kind, who, now, project, projectType)
            }
        }
        if (l === s.files) s else s.copy(
            files = l,
            tick = if (fresh || kind == "live") s.tick + 1 else s.tick,
            step = step.ifBlank { s.step },
            activeProject = project.ifBlank { s.activeProject },
            activeType = projectType.ifBlank { s.activeType }
        )
    }

    /** The files of the answer that is still streaming in (see [LiveCodeRules.partialFiles]). */
    fun partial(items: List<Pair<String, String>>) {
        if (items.isEmpty()) return
        files(items, state.value.who.ifBlank { "Main Brain" }, "live")
    }

    /** Reads {"files":[{path,content}], "edits":[{path,find,replace}], "code":"..."} (the code writer's answer). */
    fun fromJson(o: JSONObject, who: String) {
        val fl = ArrayList<Pair<String, String>>()
        o.optJSONArray("files")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let {
                val p = it.optString("path")
                val c = it.optString("content")
                if (p.isNotBlank() && c.isNotEmpty()) fl.add(p to c)
            }
        }
        if (fl.isNotEmpty()) files(fl, who)
        val el = ArrayList<Pair<String, String>>()
        o.optJSONArray("edits")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let {
                val p = it.optString("path")
                if (p.isNotBlank()) el.add("$p (fix)" to ("- " + it.optString("find").lines().joinToString("\n- ") + "\n+ " + it.optString("replace").lines().joinToString("\n+ ")))
            }
        }
        if (el.isNotEmpty()) files(el, who, "fix")
        // Also support single "code" response from CodeWriter
        val singleCode = o.optString("code", "").trim()
        if (singleCode.isNotEmpty() && fl.isEmpty()) {
            val ext = LiveCodeRules.guessExtFromCode(singleCode)
            files(listOf("snippet.$ext" to singleCode), who, "new")
        }
        // Also support design brief JSON
        if (o.has("brand") && o.has("sections") && fl.isEmpty()) {
            files(listOf("design-brief.json" to o.toString(2)), who, "new")
        }
    }

    /** A chat answer with code blocks (the typed chat, including while streaming): every block becomes a file and updates in place. */
    fun fromText(text: String, who: String, streaming: Boolean = false) {
        val blocks = LiveCodeRules.fences(text)
        if (blocks.isEmpty()) return
        val kind = if (streaming) "live" else "chat"
        files(blocks.mapIndexed { i, b -> "chat-code-${i + 1}.${LiveCodeRules.extFor(b.lang)}" to b.code }, who, kind, "chat-snippets", "snippet")
    }

    /**
     * Ensures the Live Code viewer always has code to show!
     * If memory is currently empty, loads the most recent Website or App project from disk so the user can view, run, or export it immediately.
     */
    fun ensureLoadedFromDisk(ctx: Context) {
        if (state.value.files.isNotEmpty()) return
        try {
            val webRoot = LocalWeb.root(ctx)
            val newestWeb = webRoot.listFiles()?.filter { it.isDirectory && File(it, "index.html").isFile }?.maxByOrNull { it.lastModified() }
            val appRoot = AppBuilder.localRoot(ctx)
            val newestApp = appRoot.listFiles()?.filter { it.isDirectory }?.maxByOrNull { it.lastModified() }

            if (newestWeb != null && (newestApp == null || newestWeb.lastModified() >= newestApp.lastModified())) {
                loadWebsiteProject(ctx, newestWeb.name)
            } else if (newestApp != null) {
                loadAppProject(ctx, newestApp.name)
            }
        } catch (_: Exception) {}
    }

    /** Loads all files of a saved website project into LiveCode viewer. */
    fun loadWebsiteProject(ctx: Context, slug: String): Boolean {
        val dir = File(LocalWeb.root(ctx), slug)
        if (!dir.isDirectory) return false
        val items = ArrayList<Pair<String, String>>()
        dir.walkTopDown().filter { it.isFile }.sortedBy { it.path }.forEach { f ->
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            if (WebRules.safePath(rel) != null) {
                try { items.add(rel to f.readText()) } catch (_: Exception) {}
            }
        }
        if (items.isEmpty()) return false
        val url = LocalWeb.url(ctx, slug)
        step = "Website: $slug (loaded)"
        setProjectContext(slug, "website", url)
        files(items, "Saved Website", "new", slug, "website")
        return true
    }

    /** Loads all files of a saved APK project into LiveCode viewer. */
    fun loadAppProject(ctx: Context, slug: String): Boolean {
        val items = AppBuilder.readLocalOrTermuxProject(ctx, slug)
        if (items.isEmpty()) return false
        step = "App: $slug (loaded)"
        setProjectContext(slug, "app", "")
        files(items.toList(), "Saved APK Project", "new", slug, "app")
        return true
    }
}
