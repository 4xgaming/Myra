package ai.nisu.assistant

/**
 * v3.174: options that are UNDER MAINTENANCE. They are switched off everywhere (the code that would run does not run) and Preferences shows an
 * "Under maintenance" notice instead of the ON / OFF buttons. To bring one back later, set it to false here.
 * (Not a const on purpose: no "always true" compiler warnings.)
 */
object Maintenance {
    @JvmField val CALL_AI: Boolean = true          // Call AI: answering calls and talking with the caller
    @JvmField val VOICE_MESSAGES: Boolean = true   // sending voice messages (voice replies) in WhatsApp / Messenger / Telegram
    const val NOTE = "This option is under maintenance. It is switched off for now and will come back in a later update."
}
