package ai.nisu.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Pure, JVM-testable rules, state machine, camera pitch controller, enemy/horizon detector,
 * and autonomous path navigator for Game Auto Play & Keymapper (v3.177).
 *
 * Fixes all issues from v3.172-v3.176:
 *  1. High-speed non-blocking architecture: fast continuous action ticks (no gesture overlap cancellation)
 *     while AI Vision runs asynchronously in the background.
 *  2. Continuous movement & autonomous path navigation: continuous joystick forward/diagonal glides + sprint +
 *     camera turns toward open corridors + automatic wall/obstacle unsticking (strafe + jump + 110° camera turn).
 *  3. Camera pitch & horizon lock: tracks vertical aim pitch (`pitchEstimate`), detects when the camera is looking
 *     up at the sky or lost horizon (`skyRatio > 0.44` or repeated drag-fire upward), and automatically injects a
 *     downward camera swipe on the right-half look zone (`y: 0.28 -> 0.64`) to pull the crosshair back down to eye/chest level.
 *  4. Fast enemy targeting & responsive shooting: detects red crosshair / enemy nametag / damage indicators in the center
 *     aim box (`EnemyScanResult`), steers the camera horizontally & vertically toward the enemy, aims (ADS/scope),
 *     fires controlled bursts with automatic recoil pitch compensation, and drops Gloo Wall / crouches under fire.
 */
object GameKeyMap {
    const val PREF_KEY = "game_keymapper_json"
    const val PREF_ENABLED = "game_keymapper_enabled"
    const val PREF_FALLBACK = "game_keymapper_fallback"
    const val PREF_CUSTOM_PKG = "game_custom_pkg"

    data class KeyPoint(
        val id: String,
        val label: String,
        val shortLabel: String,
        val x: Float,
        val y: Float,
        val colorHex: Int = 0xFF38B6FF.toInt(),
        val radiusDp: Float = 24f,
        val isJoystick: Boolean = false
    )

    data class FingerSpec(
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1,
        val startMs: Long = 0L,
        val durationMs: Long = 80L
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x", x1.toDouble())
            put("y", y1.toDouble())
            if (x2 != x1 || y2 != y1) {
                put("x2", x2.toDouble())
                put("y2", y2.toDouble())
            }
            if (startMs > 0L) put("start_ms", startMs)
            put("duration_ms", durationMs)
        }
    }

    /**
     * Result of ultra-fast local pixel analysis on the current game frame (or synthetic test state):
     * - [enemyLocked]: true when red crosshair / enemy marker / red nametag is detected in the aim region.
     * - [enemyOffsetX]: horizontal offset from screen center (-0.35 = left of crosshair, +0.35 = right of crosshair).
     * - [enemyOffsetY]: vertical offset from crosshair (-0.25 = above crosshair, +0.25 = below crosshair).
     * - [lookingAtSky]: true when top 55% of the view is dominated by uniform sky/ceiling or aim drifted too high.
     * - [takingDamage]: true when red damage vignette/hit indicator flashes on screen edges.
     * - [openPathDir]: -1 = more open space on left, +1 = more open space on right, 0 = straight ahead open.
     * - [wallBlocked]: true when center-front is visually blocked at close range or frame hasn't changed while moving.
     */
    data class FrameSense(
        val enemyLocked: Boolean = false,
        val enemyOffsetX: Float = 0f,
        val enemyOffsetY: Float = 0f,
        val lookingAtSky: Boolean = false,
        val lookingAtGround: Boolean = false,
        val takingDamage: Boolean = false,
        val openPathDir: Int = 0,
        val wallBlocked: Boolean = false
    )

    /**
     * Tracks camera pitch (vertical angle: positive = looking up toward sky, negative = looking down at ground)
     * and consecutive upward drag-shots so the aim NEVER gets stuck pointing at the sky.
     */
    class PitchTracker {
        var pitch: Float = 0f
            private set
        var consecutiveUpDrags: Int = 0
            private set

        /** Record a vertical camera or fire drag where `dy = y2 - y1` (negative `dy` means finger dragged UP -> camera/aim moved UP). */
        fun recordVerticalDrag(dy: Float, isFireDrag: Boolean) {
            // Finger dragging UP (dy < 0) raises aim upward (+pitch)
            val deltaPitch = -dy * (if (isFireDrag) 0.85f else 1.25f)
            pitch = (pitch + deltaPitch).coerceIn(-0.65f, 0.85f)
            if (dy < -0.02f) {
                consecutiveUpDrags++
            } else if (dy > 0.04f) {
                consecutiveUpDrags = 0
            }
        }

        fun forceSkyDetected() {
            pitch = maxOf(pitch, 0.36f)
        }

        fun forceGroundDetected() {
            pitch = minOf(pitch, -0.32f)
        }

        fun needsPitchDown(sense: FrameSense? = null): Boolean =
            sense?.lookingAtSky == true || pitch >= 0.16f || consecutiveUpDrags >= 2

        fun needsPitchUp(sense: FrameSense? = null): Boolean =
            sense?.lookingAtGround == true || pitch <= -0.24f

        fun resetAfterCorrection() {
            pitch = 0f
            consecutiveUpDrags = 0
        }
    }

    /**
     * Builds a dedicated right-side camera swipe gesture that brings the aim back to horizontal eye-level (`y = 0.48`)
     * when the aim has drifted up toward the sky or down toward the feet.
     *
     * Note on mobile TPS/FPS touch controls (Free Fire / BGMI / CODM):
     * - Swiping a finger DOWN on the right look area (`y1 = 0.28 -> y2 = 0.62`) tilts the camera DOWN from the sky back to the ground/horizon!
     * - Swiping a finger UP on the right look area (`y1 = 0.64 -> y2 = 0.38`) raises the camera UP from the feet to the horizon.
     */
    fun buildPitchCorrectionSwipe(
        lookingUpAtSky: Boolean,
        pitchAmount: Float = 0.28f,
        horizontalSteer: Float = 0f,
        startMs: Long = 20L
    ): FingerSpec {
        val xStart = 0.64f
        val xEnd = (xStart + horizontalSteer.coerceIn(-0.18f, 0.18f)).coerceIn(0.46f, 0.82f)
        return if (lookingUpAtSky) {
            val drop = pitchAmount.coerceIn(0.18f, 0.38f)
            FingerSpec(
                x1 = xStart,
                y1 = 0.26f,
                x2 = xEnd,
                y2 = (0.26f + drop).coerceIn(0.46f, 0.68f),
                startMs = startMs,
                durationMs = 260L
            )
        } else {
            val lift = pitchAmount.coerceIn(0.15f, 0.30f)
            FingerSpec(
                x1 = xStart,
                y1 = 0.64f,
                x2 = xEnd,
                y2 = (0.64f - lift).coerceIn(0.32f, 0.50f),
                startMs = startMs,
                durationMs = 240L
            )
        }
    }

    /**
     * Inspects any list of fingers (from AI or fallback) and ensures:
     *  1. Upward fire drags are capped to a gentle headshot micro-drag (`max 0.035` screen height) so aim never flies into the sky.
     *  2. If `pitchTracker.needsPitchDown(sense)` is true, automatically replaces or appends a downward camera pitch-reset swipe
     *     and converts upward fire drags into downward/level recoil-compensated fire!
     */
    fun sanitizeAndLevelFingers(
        fingers: List<FingerSpec>,
        keys: Map<String, KeyPoint>,
        pitchTracker: PitchTracker,
        sense: FrameSense? = null
    ): List<FingerSpec> {
        if (fingers.isEmpty()) return fingers
        val fireKp = getPoint(keys, "fire")
        val joyKp = getPoint(keys, "joystick")
        val needDown = pitchTracker.needsPitchDown(sense)
        val needUp = !needDown && pitchTracker.needsPitchUp(sense)

        val out = ArrayList<FingerSpec>(fingers.size + 1)
        var hasRightCameraSwipe = false

        for (f in fingers) {
            val nearFire = hypot((f.x1 - fireKp.x).toDouble(), (f.y1 - fireKp.y).toDouble()) < 0.11
            val nearJoy = hypot((f.x1 - joyKp.x).toDouble(), (f.y1 - joyKp.y).toDouble()) < 0.14
            val isRightHalfLook = !nearFire && !nearJoy && f.x1 in 0.42f..0.88f && (abs(f.x2 - f.x1) > 0.02f || abs(f.y2 - f.y1) > 0.02f)

            if (nearFire) {
                // Clamp upward fire drag so it never yanks the camera into the sky
                val rawDy = f.y2 - f.y1
                val safeY2 = when {
                    needDown -> (f.y1 + 0.025f).coerceIn(0.15f, 0.92f) // pull slightly down while firing if aim was high
                    rawDy < -0.035f -> (f.y1 - 0.032f).coerceAtLeast(0.22f) // gentle 3.2% headshot micro-drag max
                    else -> f.y2
                }
                val safeX2 = if (sense?.enemyLocked == true) {
                    (f.x1 + sense.enemyOffsetX.coerceIn(-0.06f, 0.06f)).coerceIn(0.10f, 0.96f)
                } else f.x2
                val adjusted = f.copy(x2 = safeX2, y2 = safeY2)
                pitchTracker.recordVerticalDrag(adjusted.y2 - adjusted.y1, isFireDrag = true)
                out.add(adjusted)
            } else if (isRightHalfLook) {
                hasRightCameraSwipe = true
                val adjusted = when {
                    needDown && f.y2 <= f.y1 -> {
                        // Force camera look swipe to also pull the pitch DOWN back to horizon
                        f.copy(
                            y1 = 0.28f,
                            y2 = 0.58f,
                            durationMs = f.durationMs.coerceIn(180L, 340L)
                        )
                    }
                    needUp && f.y2 >= f.y1 -> {
                        f.copy(
                            y1 = 0.62f,
                            y2 = 0.40f,
                            durationMs = f.durationMs.coerceIn(180L, 340L)
                        )
                    }
                    else -> {
                        // Prevent random extreme upward look swipes
                        val clampedY2 = if (f.y2 - f.y1 < -0.06f) f.y1 - 0.04f else f.y2
                        f.copy(y2 = clampedY2.coerceIn(0.22f, 0.78f))
                    }
                }
                pitchTracker.recordVerticalDrag(adjusted.y2 - adjusted.y1, isFireDrag = false)
                if (needDown || needUp) pitchTracker.resetAfterCorrection()
                out.add(adjusted)
            } else {
                out.add(f)
            }
        }

        // If camera is pointing at the sky and no right-half look swipe corrected it yet, inject an immediate pitch-down swipe
        if ((needDown || needUp) && !hasRightCameraSwipe && out.size < 4) {
            val corr = buildPitchCorrectionSwipe(
                lookingUpAtSky = needDown,
                pitchAmount = if (needDown) maxOf(0.26f, pitchTracker.pitch) else 0.22f,
                horizontalSteer = sense?.enemyOffsetX ?: 0f,
                startMs = 30L
            )
            out.add(corr)
            pitchTracker.resetAfterCorrection()
        }
        return out
    }

    /**
     * Default Free Fire / Battle Royale landscape HUD coordinates (fractions 0.0 .. 1.0 of landscape width x height).
     * Every key can be dragged on-screen via the floating Keymapper Overlay or edited in the Game Auto Play page.
     */
    val DEFAULT_KEYS: List<KeyPoint> = listOf(
        KeyPoint("event_close", "Event / Ad Close (X)", "X CLOSE", 0.935f, 0.085f, 0xFFEA6F66.toInt(), 22f),
        KeyPoint("mode_btn", "Mode Selector (above Start)", "MODE", 0.865f, 0.775f, 0xFFF0BE6A.toInt(), 24f),
        KeyPoint("start_btn", "START / Play Again Button", "START", 0.875f, 0.895f, 0xFF63D6A0.toInt(), 28f),
        KeyPoint("joystick", "Left Movement Joystick", "MOVE", 0.145f, 0.720f, 0xFF38B6FF.toInt(), 34f, isJoystick = true),
        KeyPoint("sprint", "Sprint / Run Button", "RUN", 0.125f, 0.485f, 0xFF38B6FF.toInt(), 22f),
        KeyPoint("fire", "Right Fire / Shoot Button", "FIRE", 0.835f, 0.650f, 0xFFEA6F66.toInt(), 30f),
        KeyPoint("aim", "Scope / Aim (ADS)", "AIM", 0.925f, 0.485f, 0xFFF0BE6A.toInt(), 22f),
        KeyPoint("jump", "Jump / Parachute Button", "JUMP", 0.935f, 0.625f, 0xFF8A6CFF.toInt(), 22f),
        KeyPoint("crouch", "Crouch Button", "CROUCH", 0.915f, 0.785f, 0xFF8A6CFF.toInt(), 22f),
        KeyPoint("prone", "Prone / Lie Down", "PRONE", 0.815f, 0.855f, 0xFF8A6CFF.toInt(), 20f),
        KeyPoint("reload", "Reload / Weapon Slot", "GUN/RLD", 0.825f, 0.145f, 0xFFF0BE6A.toInt(), 22f),
        KeyPoint("gloo", "Gloo Wall / Grenade", "GLOO", 0.365f, 0.825f, 0xFF38B6FF.toInt(), 22f),
        KeyPoint("heal", "Medkit / Heal", "HEAL", 0.065f, 0.565f, 0xFF63D6A0.toInt(), 22f),
        KeyPoint("revive", "Revive / Help Teammate", "REVIVE", 0.555f, 0.680f, 0xFF63D6A0.toInt(), 20f),
        KeyPoint("loot1", "Loot / Pick Up Item 1", "LOOT 1", 0.725f, 0.360f, 0xFFF0BE6A.toInt(), 22f),
        KeyPoint("loot2", "Loot / Pick Up Item 2", "LOOT 2", 0.725f, 0.460f, 0xFFF0BE6A.toInt(), 20f),
        KeyPoint("buy_gun1", "CS Buy Slot 1 (SMG/Rifle)", "BUY 1", 0.320f, 0.380f, 0xFF63D6A0.toInt(), 22f),
        KeyPoint("buy_gun2", "CS Buy Slot 2 (Shotgun/AR)", "BUY 2", 0.500f, 0.380f, 0xFF63D6A0.toInt(), 22f),
        KeyPoint("buy_vest", "CS Buy Vest / Helmet / Gloo", "VEST", 0.320f, 0.660f, 0xFF38B6FF.toInt(), 20f),
        KeyPoint("buy_close", "CS Close Buy Menu (X)", "BUY X", 0.905f, 0.125f, 0xFFEA6F66.toInt(), 20f),
        KeyPoint("back_cont", "Result Continue / Next / Exit", "NEXT/OK", 0.875f, 0.895f, 0xFF63D6A0.toInt(), 24f)
    )

    /** Common popup / event banner close spots across Free Fire, Free Fire MAX, and mobile games (fractions 0..1). */
    val POPUP_CLOSE_SPOTS: List<Pair<Float, Float>> = listOf(
        0.935f to 0.085f, // Top-right standard X on event poster
        0.955f to 0.065f, // Extreme top-right X
        0.905f to 0.125f, // Inner dialog top-right X
        0.880f to 0.145f, // Smaller modal top-right X
        0.850f to 0.160f, // Sub-banner X
        0.960f to 0.120f, // Side close tab
        0.500f to 0.885f, // Bottom center "Tap to close" / "OK" / "Confirm"
        0.065f to 0.085f, // Top-left Back arrow
        0.150f to 0.885f  // Bottom-left "Cancel" / "Later"
    )

    fun parseKeys(rawJson: String?): Map<String, KeyPoint> {
        val out = LinkedHashMap<String, KeyPoint>()
        for (d in DEFAULT_KEYS) out[d.id] = d
        if (rawJson.isNullOrBlank()) return out
        try {
            val obj = JSONObject(rawJson)
            for (d in DEFAULT_KEYS) {
                val item = obj.optJSONObject(d.id) ?: continue
                val nx = item.optDouble("x", d.x.toDouble()).toFloat().coerceIn(0.01f, 0.99f)
                val ny = item.optDouble("y", d.y.toDouble()).toFloat().coerceIn(0.01f, 0.99f)
                out[d.id] = d.copy(x = nx, y = ny)
            }
        } catch (_: Exception) {}
        return out
    }

    fun toJson(keys: Map<String, KeyPoint>): String {
        val root = JSONObject()
        for ((id, kp) in keys) {
            root.put(id, JSONObject()
                .put("x", ((kp.x * 1000f).roundToInt() / 1000.0))
                .put("y", ((kp.y * 1000f).roundToInt() / 1000.0)))
        }
        return root.toString()
    }

    fun getPoint(keys: Map<String, KeyPoint>, id: String): KeyPoint =
        keys[id] ?: DEFAULT_KEYS.firstOrNull { it.id == id } ?: KeyPoint(id, id, id, 0.5f, 0.5f)

    /**
     * Generates a compact summary of the user's mapped HUD coordinates so the Gemini Vision model knows
     * the exact button locations on this specific phone.
     */
    fun promptSummary(keys: Map<String, KeyPoint>): String {
        fun fmt(id: String): String {
            val p = getPoint(keys, id)
            return "${p.id}=(${String.format(java.util.Locale.US, "%.2f", p.x)},${String.format(java.util.Locale.US, "%.2f", p.y)})"
        }
        return listOf(
            fmt("event_close"), fmt("mode_btn"), fmt("start_btn"), fmt("joystick"),
            fmt("sprint"), fmt("fire"), fmt("aim"), fmt("jump"), fmt("crouch"),
            fmt("reload"), fmt("gloo"), fmt("heal"), fmt("loot1"),
            fmt("buy_gun1"), fmt("buy_gun2"), fmt("buy_vest"), fmt("buy_close"), fmt("back_cont")
        ).joinToString(", ")
    }

    /**
     * Resolves a symbolic key name (if the AI returned `{"key":"start_btn"}` or `{"key":"fire"}`) OR raw `x,y`
     * into fractional coordinates `0..1`.
     */
    fun resolveFingerJson(t: JSONObject, keys: Map<String, KeyPoint>, shotW: Double, shotH: Double): FingerSpec? {
        val keyId = t.optString("key", "").trim().lowercase()
        val kp = if (keyId.isNotEmpty()) keys[keyId] else null
        fun normX(v: Double): Float = (if (v > 1.5) v / shotW.coerceAtLeast(1.0) else v).coerceIn(0.01, 0.99).toFloat()
        fun normY(v: Double): Float = (if (v > 1.5) v / shotH.coerceAtLeast(1.0) else v).coerceIn(0.01, 0.99).toFloat()

        val x1 = when {
            t.has("x") -> normX(t.optDouble("x"))
            kp != null -> kp.x
            else -> return null
        }
        val y1 = when {
            t.has("y") -> normY(t.optDouble("y"))
            kp != null -> kp.y
            else -> return null
        }
        val x2 = if (t.has("x2")) normX(t.optDouble("x2")) else x1
        val y2 = if (t.has("y2")) normY(t.optDouble("y2")) else y1
        val slide = abs(x2 - x1) > 0.005f || abs(y2 - y1) > 0.005f
        val start = t.optLong("start_ms", 0L).coerceIn(0L, 4000L)
        val dur = t.optLong("duration_ms", if (slide) 520L else 75L).coerceIn(35L, 2500L)
        return FingerSpec(x1, y1, x2, y2, start, dur)
    }

    /**
     * Generates responsive, continuous, intelligent multi-touch actions for any game scene:
     *  - Keeps the character constantly running/navigating (`joystick` + `sprint` + path-seeking camera pan)
     *  - Automatically pulls aim DOWN (`buildPitchCorrectionSwipe(lookingUpAtSky = true)`) whenever the aim drifts up
     *  - Locks onto detected enemies (`sense.enemyLocked`), centers crosshair on the target, aims (ADS), and fires bursts
     *  - Unsticks the player automatically when blocked by a wall (`sameFrames >= 2` or `sense.wallBlocked`)
     */
    fun buildFallbackFingers(
        scene: String,
        stepIndex: Int,
        sameFrames: Int,
        gameMode: String,
        fightStyle: String,
        autoLoot: Boolean,
        closePopups: Boolean,
        keys: Map<String, KeyPoint>,
        sense: FrameSense = FrameSense(),
        pitchTracker: PitchTracker? = null
    ): List<FingerSpec> {
        val s = scene.lowercase().trim()
        val joy = getPoint(keys, "joystick")
        val fire = getPoint(keys, "fire")
        val sprint = getPoint(keys, "sprint")
        val jump = getPoint(keys, "jump")
        val crouch = getPoint(keys, "crouch")
        val aim = getPoint(keys, "aim")
        val reload = getPoint(keys, "reload")
        val gloo = getPoint(keys, "gloo")
        val heal = getPoint(keys, "heal")
        val loot1 = getPoint(keys, "loot1")
        val loot2 = getPoint(keys, "loot2")
        val startBtn = getPoint(keys, "start_btn")
        val modeBtn = getPoint(keys, "mode_btn")
        val eventClose = getPoint(keys, "event_close")
        val backCont = getPoint(keys, "back_cont")

        return when (s) {
            "popup", "event", "ad" -> {
                if (!closePopups) emptyList()
                else if (stepIndex % (POPUP_CLOSE_SPOTS.size + 1) == 0) {
                    listOf(FingerSpec(eventClose.x, eventClose.y, durationMs = 75L))
                } else {
                    val sp = POPUP_CLOSE_SPOTS[(stepIndex - 1).mod(POPUP_CLOSE_SPOTS.size)]
                    listOf(FingerSpec(sp.first, sp.second, durationMs = 75L))
                }
            }
            "lobby" -> {
                when {
                    sameFrames >= 3 && sameFrames % 2 == 1 -> {
                        val sp = POPUP_CLOSE_SPOTS[(sameFrames / 2).mod(POPUP_CLOSE_SPOTS.size)]
                        listOf(FingerSpec(sp.first, sp.second, durationMs = 75L))
                    }
                    else -> listOf(FingerSpec(startBtn.x, startBtn.y, durationMs = 95L))
                }
            }
            "mode_select" -> {
                val modeSpot = when (gameMode) {
                    "br_rank" -> 0.28f to 0.42f
                    "classic", "br" -> 0.28f to 0.25f
                    "cs_rank" -> 0.65f to 0.42f
                    else -> 0.65f to 0.25f // CS Normal
                }
                when (stepIndex.mod(3)) {
                    0 -> listOf(FingerSpec(modeBtn.x, modeBtn.y, durationMs = 85L))
                    1 -> listOf(FingerSpec(modeSpot.first, modeSpot.second, durationMs = 95L))
                    else -> listOf(FingerSpec(startBtn.x, startBtn.y, durationMs = 95L))
                }
            }
            "buy" -> {
                val b1 = getPoint(keys, "buy_gun1")
                val b2 = getPoint(keys, "buy_gun2")
                val bv = getPoint(keys, "buy_vest")
                val bx = getPoint(keys, "buy_close")
                when (stepIndex.mod(3)) {
                    0 -> listOf(
                        FingerSpec(b1.x, b1.y, startMs = 0L, durationMs = 75L),
                        FingerSpec(bv.x, bv.y, startMs = 150L, durationMs = 75L)
                    )
                    1 -> listOf(
                        FingerSpec(b2.x, b2.y, startMs = 0L, durationMs = 75L),
                        FingerSpec(bx.x, bx.y, startMs = 160L, durationMs = 75L)
                    )
                    else -> listOf(FingerSpec(bx.x, bx.y, durationMs = 75L))
                }
            }
            "plane" -> {
                listOf(FingerSpec(jump.x, jump.y, durationMs = 95L))
            }
            "parachute" -> {
                val dx = when (stepIndex.mod(3)) { 0 -> 0f; 1 -> 0.05f; else -> -0.05f }
                listOf(
                    FingerSpec(
                        joy.x, joy.y,
                        (joy.x + dx).coerceIn(0.03f, 0.45f),
                        (joy.y - 0.22f).coerceIn(0.08f, 0.90f),
                        0L, 620L
                    ),
                    // Keep camera angled slightly downward to spot landing buildings
                    FingerSpec(0.65f, 0.42f, 0.65f + dx, 0.52f, startMs = 80L, durationMs = 240L)
                )
            }
            "ground", "combat", "in_game" -> {
                val list = ArrayList<FingerSpec>(4)
                val needPitchDown = sense.lookingAtSky || (pitchTracker?.needsPitchDown(sense) == true)
                val needPitchUp = !needPitchDown && (sense.lookingAtGround || (pitchTracker?.needsPitchUp(sense) == true))
                val isStuckOnObstacle = sameFrames >= 2 || sense.wallBlocked

                // 1) CONTINUOUS MOVEMENT & OBSTACLE NAVIGATION (Left Joystick + Sprint)
                // Never stop moving: if stuck on a wall/corner, strafe hard left/right + jump; otherwise push joystick full forward toward open path.
                val moveDx = when {
                    isStuckOnObstacle -> if (stepIndex % 2 == 0) 0.14f else -0.14f
                    sense.enemyLocked -> if (stepIndex % 2 == 0) 0.07f else -0.07f // tactical combat strafe while shooting
                    sense.openPathDir < 0 -> -0.06f
                    sense.openPathDir > 0 -> 0.06f
                    else -> when (stepIndex.mod(6)) {
                        0, 3 -> 0.0f
                        1 -> 0.05f
                        2 -> -0.05f
                        4 -> 0.07f
                        else -> -0.04f
                    }
                }
                val moveDy = if (isStuckOnObstacle && sameFrames >= 3) -0.12f else -0.23f
                list.add(
                    FingerSpec(
                        joy.x, joy.y,
                        (joy.x + moveDx).coerceIn(0.03f, 0.45f),
                        (joy.y + moveDy).coerceIn(0.08f, 0.88f),
                        startMs = 0L,
                        durationMs = 560L
                    )
                )

                // 2) SKY / PITCH RECOVERY (Highest priority if camera went up to the sky or down to feet!)
                if (needPitchDown || needPitchUp) {
                    val pitchSwipe = buildPitchCorrectionSwipe(
                        lookingUpAtSky = needPitchDown,
                        pitchAmount = if (needPitchDown) 0.30f else 0.22f,
                        horizontalSteer = if (sense.enemyLocked) sense.enemyOffsetX else (sense.openPathDir * 0.08f),
                        startMs = 20L
                    )
                    list.add(pitchSwipe)
                    pitchTracker?.resetAfterCorrection()
                    if (stepIndex % 2 == 0) {
                        list.add(FingerSpec(sprint.x, sprint.y, startMs = 40L, durationMs = 65L))
                    }
                    return list
                }

                // 3) ENEMY DETECTED OR COMBAT SCENE -> LOCK AIM, STEER CAMERA TO TARGET, AND SHOOT!
                val forceCombat = s == "combat" || sense.enemyLocked || sense.takingDamage
                if (forceCombat) {
                    // If enemy is off-center horizontally/vertically, steer camera toward enemy right before/during fire
                    if (abs(sense.enemyOffsetX) > 0.04f || abs(sense.enemyOffsetY) > 0.04f) {
                        val lookX2 = (0.64f + sense.enemyOffsetX.coerceIn(-0.18f, 0.18f)).coerceIn(0.45f, 0.84f)
                        val lookY2 = (0.48f + sense.enemyOffsetY.coerceIn(-0.08f, 0.12f)).coerceIn(0.36f, 0.62f)
                        list.add(FingerSpec(0.64f, 0.48f, lookX2, lookY2, startMs = 10L, durationMs = 160L))
                    }
                    // Tap ADS/Scope on alternating bursts for tight accuracy
                    if (stepIndex.mod(3) == 1 && fightStyle != "safe") {
                        list.add(FingerSpec(aim.x, aim.y, startMs = 20L, durationMs = 65L))
                    }
                    // Controlled fire burst: tiny micro-drag on burst 0, level/slightly-down recoil control on burst 1 so aim NEVER flies up!
                    val fireDy = if (stepIndex.mod(2) == 0) -0.025f else 0.015f
                    val fireFinger = FingerSpec(
                        fire.x, fire.y,
                        (fire.x + sense.enemyOffsetX.coerceIn(-0.04f, 0.04f)).coerceIn(0.10f, 0.96f),
                        (fire.y + fireDy).coerceIn(0.25f, 0.88f),
                        startMs = 55L,
                        durationMs = 460L
                    )
                    pitchTracker?.recordVerticalDrag(fireDy, isFireDrag = true)
                    list.add(fireFinger)

                    // Defensive crouch / Gloo Wall if taking heavy damage
                    if (sense.takingDamage && stepIndex.mod(3) == 0) {
                        val defKey = if (fightStyle == "safe") gloo else crouch
                        list.add(FingerSpec(defKey.x, defKey.y, startMs = 240L, durationMs = 70L))
                    }
                    return list
                }

                // 4) WALL / OBSTACLE UNSTICKING -> Jump over obstacle + 110° camera turn toward open space
                if (isStuckOnObstacle) {
                    val turnDir = if (sense.openPathDir != 0) sense.openPathDir else if (stepIndex % 2 == 0) 1 else -1
                    val swipeEndX = (0.62f + turnDir * 0.22f).coerceIn(0.38f, 0.88f)
                    list.add(FingerSpec(jump.x, jump.y, startMs = 20L, durationMs = 70L))
                    list.add(FingerSpec(0.62f, 0.46f, swipeEndX, 0.50f, startMs = 70L, durationMs = 280L))
                    return list
                }

                // 5) ACTIVE EXPLORATION, PATH NAVIGATION & COMBAT SCANNING (6-phase fast cycle, every ~420ms)
                when (stepIndex.mod(6)) {
                    0 -> {
                        // Sprint lock + smooth horizontal camera steer toward open path / enemy scan right
                        list.add(FingerSpec(sprint.x, sprint.y, startMs = 25L, durationMs = 70L))
                        val panDir = if (sense.openPathDir != 0) sense.openPathDir * 0.14f else 0.14f
                        list.add(FingerSpec(0.60f, 0.47f, (0.60f + panDir).coerceIn(0.42f, 0.82f), 0.49f, startMs = 90L, durationMs = 250L))
                        if (fightStyle == "aggressive") {
                            list.add(FingerSpec(fire.x, fire.y, fire.x, fire.y - 0.02f, startMs = 200L, durationMs = 340L))
                            pitchTracker?.recordVerticalDrag(-0.02f, isFireDrag = true)
                        }
                    }
                    1 -> {
                        // Proactive suppressive fire burst + level recoil control
                        if (fightStyle != "safe") {
                            val dy = -0.028f
                            list.add(
                                FingerSpec(
                                    fire.x, fire.y,
                                    fire.x, (fire.y + dy).coerceAtLeast(0.25f),
                                    startMs = 40L, durationMs = 440L
                                )
                            )
                            pitchTracker?.recordVerticalDrag(dy, isFireDrag = true)
                        } else if (autoLoot) {
                            list.add(FingerSpec(loot1.x, loot1.y, startMs = 60L, durationMs = 70L))
                        }
                        // Slight downward-left camera scan to keep horizon centered
                        list.add(FingerSpec(0.66f, 0.44f, 0.54f, 0.50f, startMs = 140L, durationMs = 240L))
                        pitchTracker?.resetAfterCorrection()
                    }
                    2 -> {
                        // Parkour jump + camera scan left + fast loot pickup
                        list.add(FingerSpec(jump.x, jump.y, startMs = 30L, durationMs = 75L))
                        list.add(FingerSpec(0.68f, 0.48f, 0.52f, 0.49f, startMs = 90L, durationMs = 240L))
                        if (autoLoot) {
                            list.add(FingerSpec(loot1.x, loot1.y, startMs = 180L, durationMs = 70L))
                        }
                    }
                    3 -> {
                        // Quick ADS / Scope check + Fire burst + Crouch evade
                        if (fightStyle != "safe") {
                            list.add(FingerSpec(aim.x, aim.y, startMs = 25L, durationMs = 70L))
                            list.add(
                                FingerSpec(
                                    fire.x, fire.y,
                                    fire.x, (fire.y + 0.015f).coerceIn(0.25f, 0.85f), // level/down recoil compensation
                                    startMs = 110L, durationMs = 420L
                                )
                            )
                            list.add(FingerSpec(crouch.x, crouch.y, startMs = 380L, durationMs = 70L))
                        } else {
                            list.add(FingerSpec(sprint.x, sprint.y, startMs = 30L, durationMs = 70L))
                            list.add(FingerSpec(0.56f, 0.47f, 0.70f, 0.49f, startMs = 100L, durationMs = 240L))
                        }
                    }
                    4 -> {
                        // Camera sweep right + weapon reload + secondary loot
                        list.add(FingerSpec(0.54f, 0.46f, 0.72f, 0.50f, startMs = 30L, durationMs = 250L))
                        list.add(FingerSpec(reload.x, reload.y, startMs = 80L, durationMs = 70L))
                        if (autoLoot) {
                            list.add(FingerSpec(loot2.x, loot2.y, startMs = 180L, durationMs = 70L))
                        }
                        pitchTracker?.resetAfterCorrection()
                    }
                    else -> {
                        // Agile jump-shot or tactical heal + horizon leveling scan
                        if (fightStyle == "safe") {
                            list.add(FingerSpec(heal.x, heal.y, startMs = 50L, durationMs = 75L))
                            list.add(FingerSpec(0.64f, 0.46f, 0.52f, 0.50f, startMs = 120L, durationMs = 230L))
                        } else {
                            list.add(FingerSpec(jump.x, jump.y, startMs = 25L, durationMs = 75L))
                            list.add(FingerSpec(fire.x, fire.y, startMs = 100L, durationMs = 380L))
                            list.add(FingerSpec(0.62f, 0.45f, 0.68f, 0.50f, startMs = 140L, durationMs = 220L))
                        }
                    }
                }
                list
            }
            "dead", "spectating", "result" -> {
                when (stepIndex.mod(4)) {
                    0 -> listOf(FingerSpec(backCont.x, backCont.y, durationMs = 85L))
                    1 -> listOf(FingerSpec(startBtn.x, startBtn.y, durationMs = 85L))
                    2 -> listOf(FingerSpec(0.50f, 0.88f, durationMs = 85L))
                    else -> listOf(FingerSpec(0.08f, 0.90f, durationMs = 85L))
                }
            }
            else -> {
                if (sameFrames >= 2) {
                    val sp = POPUP_CLOSE_SPOTS[(stepIndex + sameFrames).mod(POPUP_CLOSE_SPOTS.size)]
                    listOf(FingerSpec(sp.first, sp.second, durationMs = 80L))
                } else emptyList()
            }
        }
    }

    /**
     * Pure RGB pixel analyzer (callable on decoded Bitmap pixels or synthetic RGB grids in unit tests)
     * that detects in < 4 ms:
     *  - Red enemy crosshair / nametag / aim-dot in the center combat box (`x: 0.30..0.70, y: 0.22..0.66`)
     *  - Looking up at sky (`skyRatio > 0.46`: top half of screen is bright uniform sky/blue/white/cyan and bottom lacks horizon contrast)
     *  - Looking straight down at ground (`groundRatio`: uniform dark/earth texture across top & bottom)
     *  - Red edge damage indicator (`takingDamage`)
     *  - Left vs Right open corridor direction (`openPathDir`: -1 left, 0 center, +1 right)
     */
    fun analyzeRgbGrid(
        width: Int,
        height: Int,
        getPixel: (x: Int, y: Int) -> Int
    ): FrameSense {
        if (width < 16 || height < 16) return FrameSense()

        var redAimHits = 0
        var redSumX = 0f
        var redSumY = 0f

        // 1. Scan center combat zone for red enemy markers, red crosshair, or enemy health bar
        val xStart = (width * 0.30f).toInt()
        val xEnd = (width * 0.70f).toInt()
        val yStart = (height * 0.22f).toInt()
        val yEnd = (height * 0.66f).toInt()
        val stepX = ((xEnd - xStart) / 18).coerceAtLeast(1)
        val stepY = ((yEnd - yStart) / 14).coerceAtLeast(1)

        var y = yStart
        while (y <= yEnd) {
            var x = xStart
            while (x <= xEnd) {
                val px = getPixel(x, y)
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                // Vivid red crosshair / enemy marker / red nametag: high R, low G & B
                if (r >= 195 && g <= 68 && b <= 68 && (r - maxOf(g, b)) >= 125) {
                    redAimHits++
                    redSumX += x.toFloat() / width.toFloat()
                    redSumY += y.toFloat() / height.toFloat()
                }
                x += stepX
            }
            y += stepY
        }

        val enemyLocked = redAimHits >= 2
        val enemyOffsetX = if (enemyLocked) ((redSumX / redAimHits) - 0.50f).coerceIn(-0.30f, 0.30f) else 0f
        val enemyOffsetY = if (enemyLocked) ((redSumY / redAimHits) - 0.46f).coerceIn(-0.25f, 0.25f) else 0f

        // 2. Scan upper-middle viewport (y: 0.12 .. 0.56, x: 0.22 .. 0.78) to check if camera is pointing up at the sky
        var skyLikeCount = 0
        var upperSamples = 0
        var leftEdgeVariance = 0
        var rightEdgeVariance = 0
        var centerBlockedDark = 0
        var centerSamples = 0

        for (gy in 2..9) {
            val py = (height * (gy / 16f)).toInt().coerceIn(0, height - 1)
            var prevLumaLeft = -1
            var prevLumaRight = -1
            for (gx in 3..13) {
                val px = (width * (gx / 16f)).toInt().coerceIn(0, width - 1)
                val c = getPixel(px, py)
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val luma = (r * 3 + g * 4 + b) shr 3

                if (gy <= 8) {
                    upperSamples++
                    // Sky pixels in Free Fire / BR: bright blue/cyan/white/haze (high B & G, high brightness)
                    val isSkyColor = (b >= 165 && g >= 145 && r <= b + 20 && luma >= 145) || (r >= 210 && g >= 210 && b >= 210)
                    if (isSkyColor) skyLikeCount++
                }

                if (gy in 5..10) {
                    if (gx in 3..6) {
                        if (prevLumaLeft >= 0) leftEdgeVariance += abs(luma - prevLumaLeft)
                        prevLumaLeft = luma
                    } else if (gx in 10..13) {
                        if (prevLumaRight >= 0) rightEdgeVariance += abs(luma - prevLumaRight)
                        prevLumaRight = luma
                    } else if (gx in 7..9) {
                        centerSamples++
                        if (luma in 15..75 && abs(r - g) < 18 && abs(g - b) < 18) {
                            centerBlockedDark++
                        }
                    }
                }
            }
        }

        val skyRatio = if (upperSamples > 0) skyLikeCount.toFloat() / upperSamples.toFloat() else 0f
        val lookingAtSky = skyRatio >= 0.58f
        val wallBlocked = centerSamples > 0 && (centerBlockedDark.toFloat() / centerSamples.toFloat()) >= 0.78f

        // 3. Check screen borders for red hit/damage vignette
        var borderRedHits = 0
        for (i in 1..6) {
            val bxL = (width * 0.04f).toInt()
            val bxR = (width * 0.96f).toInt()
            val by = (height * (i / 7f)).toInt()
            for (px in intArrayOf(getPixel(bxL, by), getPixel(bxR, by))) {
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                if (r >= 180 && g <= 55 && b <= 55) borderRedHits++
            }
        }
        val takingDamage = borderRedHits >= 4

        val openPathDir = when {
            leftEdgeVariance > rightEdgeVariance + 90 -> -1
            rightEdgeVariance > leftEdgeVariance + 90 -> 1
            else -> 0
        }

        return FrameSense(
            enemyLocked = enemyLocked,
            enemyOffsetX = enemyOffsetX,
            enemyOffsetY = enemyOffsetY,
            lookingAtSky = lookingAtSky,
            lookingAtGround = false,
            takingDamage = takingDamage,
            openPathDir = openPathDir,
            wallBlocked = wallBlocked
        )
    }
}

/**
 * v3.177: High-Speed Real-Time Game Auto Play + Autonomous Navigation, Sky-Aim Reset & Fast Enemy Combat.
 *
 * Key upgrades in v3.177:
 *  1. Ultra-Fast Action Loop (~380ms Fast / ~520ms Normal): never blocks on Gemini HTTP calls!
 *     AI Vision runs asynchronously on a background worker while the continuous action loop keeps moving,
 *     steering, aiming, and shooting every tick without pauses.
 *  2. Gesture Timing Sync (`wait = true` with compact 420-560ms strokes): prevents Android `dispatchGesture`
 *     from cancelling in-flight movement/shooting gestures.
 *  3. Local Pixel Sense (`analyzeFrameSense`) + `PitchTracker`: detects enemies (red crosshair/markers) in < 5ms,
 *     steers aim onto enemies, and automatically pulls the camera DOWN if aim ever drifts toward the sky.
 */
object GameAutoPlay {
    private val http = Net.base.newBuilder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(16, TimeUnit.SECONDS)
        .build()

    @Volatile private var thread: Thread? = null
    @Volatile private var run = false
    @Volatile private var thinkMode = 0      // 0 = thinkingBudget 0, 1 = thinkingLevel low (Gemini 3), 2 = no thinking config
    @Volatile private var lastErr = ""
    @Volatile private var modelIdx = 0
    private var mutedBefore = false

    const val PKG_FF = "com.dts.freefireth"
    const val PKG_MAX = "com.dts.freefiremax"
    const val PKG_PUBG = "com.tencent.ig"
    const val PKG_BGMI = "com.pubg.imobile"
    const val PKG_CODM = "com.activision.callofduty.shooter"

    val KNOWN_GAME_PKGS = setOf(PKG_FF, PKG_MAX, PKG_PUBG, PKG_BGMI, PKG_CODM)

    /** Reactive state for the Keymapper editor overlay & key positions. */
    val keymapperShowing = MutableStateFlow(false)
    val hudBarShowing = MutableStateFlow(false)
    val keysState = MutableStateFlow<Map<String, GameKeyMap.KeyPoint>>(
        GameKeyMap.DEFAULT_KEYS.associateBy { it.id }
    )

    fun isRunning() = run

    const val MAINTENANCE = false

    fun loadKeys(ctx: Context): Map<String, GameKeyMap.KeyPoint> {
        val raw = Prefs.get(ctx, GameKeyMap.PREF_KEY, "")
        val parsed = GameKeyMap.parseKeys(raw)
        keysState.value = parsed
        return parsed
    }

    fun saveKeyPosition(ctx: Context, id: String, x: Float, y: Float) {
        val cur = LinkedHashMap(loadKeys(ctx))
        val old = cur[id] ?: GameKeyMap.DEFAULT_KEYS.firstOrNull { it.id == id } ?: return
        cur[id] = old.copy(x = x.coerceIn(0.01f, 0.99f), y = y.coerceIn(0.01f, 0.99f))
        Prefs.put(ctx, GameKeyMap.PREF_KEY, GameKeyMap.toJson(cur))
        keysState.value = cur
    }

    fun resetKeys(ctx: Context) {
        Prefs.put(ctx, GameKeyMap.PREF_KEY, "")
        val def = GameKeyMap.DEFAULT_KEYS.associateBy { it.id }
        keysState.value = def
        mainHandler.post { overlayView?.invalidate() }
    }

    fun keymapperEnabled(ctx: Context): Boolean = Prefs.getBool(ctx, GameKeyMap.PREF_ENABLED, true)
    fun setKeymapperEnabled(ctx: Context, on: Boolean) { Prefs.putBool(ctx, GameKeyMap.PREF_ENABLED, on) }

    fun keymapperFallback(ctx: Context): Boolean = Prefs.getBool(ctx, GameKeyMap.PREF_FALLBACK, true)
    fun setKeymapperFallback(ctx: Context, on: Boolean) { Prefs.putBool(ctx, GameKeyMap.PREF_FALLBACK, on) }

    fun start(ctx: Context) {
        if (MAINTENANCE || run) return
        val app = ctx.applicationContext
        loadKeys(app)
        run = true
        AppState.gameAuto.value = true
        AppState.gameMatches.value = 0
        AppState.gameStage.value = "starting"
        AppState.gameNote.value = "Opening game & starting high-speed Auto Play..."
        mutedBefore = AppState.muted.value
        AppState.muted.value = true            // the game's sound must never reach the voice session
        AppState.add("Game Auto Play ON (High-Speed v3.177)")
        val t = Thread({ loop(app) }, "nisu-game")
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop(reason: String? = null) {
        if (!run && thread == null) return
        run = false
        thread?.interrupt()
        if (reason != null) {
            AppState.gameAuto.value = false
            AppState.gameStage.value = ""
            AppState.gameNote.value = reason
        }
    }

    private fun finish(reason: String) {
        run = false
        thread = null
        AppState.gameAuto.value = false
        AppState.gameStage.value = ""
        AppState.gameNote.value = reason
        AppState.muted.value = mutedBefore
        AppState.add("Game Auto Play OFF: $reason")
    }

    // ---------------------------------------------------------------- helpers
    fun pkgs(ctx: Context): Pair<String, String>? {
        val pm = ctx.packageManager
        fun has(p: String) = try { pm.getLaunchIntentForPackage(p) != null } catch (_: Exception) { false }
        val customPkg = Prefs.get(ctx, GameKeyMap.PREF_CUSTOM_PKG, "").trim()
        val pick = when (val choice = Prefs.get(ctx, Prefs.GAME_PKG, "auto")) {
            "ff" -> listOf(PKG_FF, PKG_MAX)
            "max" -> listOf(PKG_MAX, PKG_FF)
            "pubg" -> listOf(PKG_BGMI, PKG_PUBG)
            "codm" -> listOf(PKG_CODM)
            "custom" -> if (customPkg.isNotEmpty()) listOf(customPkg) else listOf(PKG_MAX, PKG_FF)
            else -> {
                val base = mutableListOf(PKG_MAX, PKG_FF, PKG_BGMI, PKG_PUBG, PKG_CODM)
                if (customPkg.isNotEmpty()) base.add(0, customPkg)
                if (choice.contains(".")) base.add(0, choice)
                base
            }
        }
        val p = pick.firstOrNull { has(it) } ?: return null
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
        } catch (_: Exception) {
            when (p) {
                PKG_MAX -> "Free Fire MAX"
                PKG_FF -> "Free Fire"
                PKG_BGMI -> "BGMI"
                PKG_PUBG -> "PUBG Mobile"
                PKG_CODM -> "Call of Duty"
                else -> p
            }
        }
        return p to label
    }

    private fun batteryLow(ctx: Context): Boolean {
        if (!Prefs.getBool(ctx, Prefs.GAME_BATTERY, true)) return false
        val bm = ctx.getSystemService(BatteryManager::class.java) ?: return false
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return pct in 1..14 && !charging
    }

    /**
     * v3.177: Fast continuous loop cadence so there is practically zero pause between movement/combat strokes.
     */
    internal fun stepMs(ctx: Context): Long = when (Prefs.get(ctx, Prefs.GAME_SPEED, "fast")) {
        "fast" -> 220L
        "slow" -> 750L
        else -> 340L
    }

    private fun sleepMs(ms: Long): Boolean = try {
        Thread.sleep(ms.coerceAtLeast(1))
        run
    } catch (_: InterruptedException) {
        false
    }

    /**
     * Decodes a small 4x downsampled bitmap from the JPEG screenshot to detect red enemy markers,
     * sky-aim drift, damage flashes, and open corridor direction in < 4ms.
     */
    private fun analyzeFrameSense(jpg: ByteArray?): GameKeyMap.FrameSense {
        if (jpg == null || jpg.size < 2000) return GameKeyMap.FrameSense()
        return try {
            val opts = BitmapFactory.Options().apply {
                inSampleSize = 4
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bmp = BitmapFactory.decodeByteArray(jpg, 0, jpg.size, opts) ?: return GameKeyMap.FrameSense()
            try {
                GameKeyMap.analyzeRgbGrid(bmp.width, bmp.height) { x, y -> bmp.getPixel(x, y) }
            } finally {
                bmp.recycle()
            }
        } catch (_: Throwable) {
            GameKeyMap.FrameSense()
        }
    }

    /**
     * Accessibility UI node fast-path: if a native or WebView dialog / permission prompt / update notice / event close button
     * is visible in the accessibility tree, click its dismiss/start button directly.
     */
    private fun tryAccessibilityFastAction(acc: NisuAccessibilityService, closePopups: Boolean): String? {
        return try {
            val nodes = acc.scan(160)
            if (nodes.isEmpty()) return null
            if (closePopups) {
                val closeWords = setOf("close", "skip", "cancel", "later", "not now", "dismiss", "no thanks", "×", "✕", "✖", "বন্ধ", "বাতিল")
                val hit = nodes.firstOrNull { s ->
                    s.clickable && (s.label.lowercase().trim() in closeWords || s.id.lowercase().let { it.contains("close") || it.contains("dismiss") || it.contains("btn_cancel") })
                }
                if (hit != null && acc.clickNode(hit.node)) {
                    return "closed popup (${hit.label.ifBlank { hit.id }})"
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private data class AiDecision(
        val scene: String,
        val note: String,
        val fingers: JSONArray?,
        val waitMs: Long,
        val atMs: Long = System.currentTimeMillis(),
        val consumed: AtomicBoolean = AtomicBoolean(false)
    )

    // ---------------------------------------------------------------- main loop
    private fun loop(ctx: Context) {
        var why = "stopped"
        try {
            // Revive accessibility automatically if Android disconnected it
            if (NisuAccessibilityService.inst == null) {
                PhoneControl.reviveAccessibility(ctx, force = true)
            }
            PhoneControl.accProblem(ctx)?.let { finish(it); return }

            val game = pkgs(ctx)
            val hasApiKey = Prefs.get(ctx, Prefs.KEY, "").isNotBlank()
            val useFallback = keymapperFallback(ctx)
            if (!hasApiKey && !useFallback) {
                finish("Save your Gemini API key first, or enable Keymapper Manual/Fallback mode")
                return
            }

            val targetPkg = game?.first ?: Prefs.get(ctx, GameKeyMap.PREF_CUSTOM_PKG, "").trim()
            val label = game?.second ?: "Game"
            AppState.add("Game: phone control OK, opening $label")

            var matches = 0
            var inMatch = false
            var lastScene = "ground"
            var sceneSince = System.currentTimeMillis()
            var lastLaunch = 0L
            var bad = 0
            var frames = 0
            var blackStreak = 0
            var sameFrames = 0
            var stepCount = 0
            var modeCheckedInLobby = false
            var lastFrame: ByteArray? = null
            val memory = ArrayDeque<String>()
            val pitchTracker = GameKeyMap.PitchTracker()

            // Asynchronous AI Vision state so network latency NEVER pauses character movement or combat!
            val aiBusy = AtomicBoolean(false)
            val latestAi = AtomicReference<AiDecision?>(null)
            var lastAiAskAt = 0L

            fun launchGame() {
                if (game == null) return
                if (System.currentTimeMillis() - lastLaunch < 12_000L) return
                lastLaunch = System.currentTimeMillis()
                AppState.gameStage.value = "opening $label"
                try {
                    val pm = ctx.packageManager
                    val launchIntent = pm.getLaunchIntentForPackage(game.first)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    }
                    if (launchIntent != null) {
                        val acc = NisuAccessibilityService.inst
                        if (acc != null) {
                            try { acc.startActivity(launchIntent) } catch (_: Exception) { ctx.startActivity(launchIntent) }
                        } else {
                            ctx.startActivity(launchIntent)
                        }
                    } else {
                        PhoneControl.openApp(ctx, label)
                    }
                } catch (_: Exception) {
                    try { PhoneControl.openApp(ctx, label) } catch (_: Exception) {}
                }
            }

            val gamePkgs = (KNOWN_GAME_PKGS + setOfNotNull(targetPkg.takeIf { it.isNotBlank() })).toSet()
            val ignorePkgs = setOf("com.android.systemui", "android", ctx.packageName, "com.miui.securitycenter", "com.samsung.android.game.gametools", "com.oplus.games", "com.coloros.gamespaceui")
            val startedAt = System.currentTimeMillis()
            var seenInGame = false
            var awaySince = 0L

            fun checkLeft(a: NisuAccessibilityService): String? {
                val live = try { a.rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
                val cur = live?.takeIf { it !in ignorePkgs && it.isNotBlank() } ?: a.fgPkg
                val now = System.currentTimeMillis()
                if (cur in gamePkgs || game == null) {
                    seenInGame = true
                    awaySince = 0L
                    return null
                }
                if (cur.isBlank() || cur in ignorePkgs) return null
                if (!seenInGame) {
                    if (now - startedAt > 10_000L && now - lastLaunch > 10_000L) launchGame()
                    return if (now - startedAt > 60_000L) "the game did not open" else null
                }
                if (awaySince == 0L) awaySince = now
                return if (now - awaySince >= 8000L) "you left the game" else null
            }

            launchGame()
            if (!sleepMs(2400)) { finish("switched off"); return }

            while (run) {
                stepCount++
                val acc = NisuAccessibilityService.inst ?: run {
                    PhoneControl.reviveAccessibility(ctx)
                    NisuAccessibilityService.inst
                }
                if (acc == null) { why = "Phone control (accessibility) is not connected"; break }

                val left = checkLeft(acc)
                if (left != null) { why = left; break }
                if (batteryLow(ctx)) { why = "battery is low"; break }
                if (!Prefs.getBool(ctx, Prefs.GAME_UNLIMITED, true) && matches >= (Prefs.get(ctx, Prefs.GAME_MAX, "5").toIntOrNull() ?: 5)) {
                    why = "finished $matches matches"; break
                }

                val keys = loadKeys(ctx)
                val closePopups = Prefs.getBool(ctx, Prefs.GAME_POPUPS, true)
                val autoLoot = Prefs.getBool(ctx, Prefs.GAME_LOOT, true)
                val gmode = Prefs.get(ctx, Prefs.GAME_MODE, "clash")
                val fstyle = Prefs.get(ctx, Prefs.GAME_STYLE, "balanced")

                // 1. Check if accessibility tree has an obvious popup Close button (every 3rd step to save time)
                if (stepCount % 3 == 1) {
                    tryAccessibilityFastAction(acc, closePopups)?.let { fastNote ->
                        AppState.add("Game: $fastNote")
                    }
                }

                val t0 = System.currentTimeMillis()
                val jpg = try { ScreenCapture.grabJpeg() } catch (_: Exception) { null }

                // If screenshot capture is unavailable or black, still execute high-speed Keymapper actions without stopping
                if (jpg == null || jpg.size < 4500) {
                    if (jpg == null) {
                        bad++
                        AppState.gameStage.value = "fast keymapper (no screenshot)"
                        AppState.gameNote.value = "Screen capture unavailable (${ScreenCapture.lastError.ifBlank { "enable Screen Share" }}). Running continuous Keymapper."
                    } else {
                        blackStreak++
                        ScreenCapture.preferProjection = blackStreak >= 2
                        AppState.gameStage.value = "fast keymapper (black frame)"
                        AppState.gameNote.value = "Screen frame is black. Tap 'ALLOW' on Game page for MediaProjection, or using Keymapper."
                    }
                    if (useFallback) {
                        val fallbackScene = when {
                            stepCount <= 3 && closePopups -> "popup"
                            stepCount in 4..5 -> "lobby"
                            stepCount == 6 && (gmode == "clash" || gmode == "cs_rank") -> "buy"
                            else -> "ground"
                        }
                        val fbFingers = GameKeyMap.buildFallbackFingers(
                            scene = fallbackScene,
                            stepIndex = stepCount,
                            sameFrames = blackStreak,
                            gameMode = gmode,
                            fightStyle = fstyle,
                            autoLoot = autoLoot,
                            closePopups = closePopups,
                            keys = keys,
                            pitchTracker = pitchTracker
                        )
                        val leveled = GameKeyMap.sanitizeAndLevelFingers(fbFingers, keys, pitchTracker)
                        if (leveled.isNotEmpty()) {
                            val arr = JSONArray().apply { leveled.forEach { put(it.toJson()) } }
                            // Always wait = true so gestures complete cleanly before next tick dispatches
                            val ok = play(ctx, acc, arr, null, wait = true, keys = keys)
                            if (ok) { touchOk++; badStreak = 0 } else { touchBad++; badStreak++ }
                            AppState.gameTouch.value = "touches ok $touchOk, failed $touchBad (fast keymapper)"
                        }
                        if (!sleepMs(180L)) break
                        continue
                    } else {
                        if (bad >= 15 || blackStreak >= 60) {
                            why = "the screen could not be captured (tap ALLOW screen capture on the Game page)"
                            break
                        }
                        if (!sleepMs(800)) break
                        continue
                    }
                }

                bad = 0
                blackStreak = 0
                if (lastFrame != null && framesAreSimilar(lastFrame!!, jpg)) sameFrames++ else sameFrames = 0
                if (frames++ < 3) AppState.add("Game: screen picture OK (${jpg.size / 1024} KB)")
                lastFrame = jpg

                // 2. Fast local pixel sense (< 4ms): detects red enemy crosshair/nametag, sky-aim drift, damage, and open corridor
                val sense = analyzeFrameSense(jpg)
                if (sense.lookingAtSky) pitchTracker.forceSkyDetected()
                if (sense.lookingAtGround) pitchTracker.forceGroundDetected()

                // 3. Dispatch Gemini Vision asynchronously in background so it NEVER blocks movement/shooting
                val nowMs = System.currentTimeMillis()
                if (hasApiKey && !aiBusy.get() && (nowMs - lastAiAskAt >= 750L || latestAi.get() == null)) {
                    if (aiBusy.compareAndSet(false, true)) {
                        lastAiAskAt = nowMs
                        val snapScene = lastScene
                        val snapSecs = ((nowMs - sceneSince) / 1000).toInt()
                        val snapSame = sameFrames
                        val snapMem = synchronized(memory) { memory.toList() }
                        val snapKeys = keys
                        val snapMatches = matches
                        Thread({
                            try {
                                val r = ask(ctx, label, jpg, snapMatches, snapScene, snapSecs, snapSame, snapMem, snapKeys, sense, pitchTracker.pitch)
                                if (r != null) {
                                    val sc = r.optString("scene", "ground").lowercase().trim()
                                    val nt = r.optString("note", "").take(120)
                                    val fArr = r.optJSONArray("fingers")
                                    val wMs = r.optLong("wait_ms", 220L).coerceIn(120L, 1200L)
                                    latestAi.set(AiDecision(sc, nt, fArr, wMs))
                                }
                            } catch (_: Throwable) {
                            } finally {
                                aiBusy.set(false)
                            }
                        }, "nisu-game-ai").apply { isDaemon = true; start() }
                    }
                }

                // 4. Read the freshest AI decision (or immediately continue with fast local sense + Keymapper while AI is thinking!)
                val aiDec = latestAi.get()
                val freshAi = aiDec != null && (System.currentTimeMillis() - aiDec.atMs) <= 4500L
                val firstUseOfAi = freshAi && aiDec!!.consumed.compareAndSet(false, true)

                var scene: String
                var note: String
                var fp: JSONArray? = null
                var waitMs: Long

                if (freshAi && aiDec != null) {
                    scene = aiDec.scene
                    note = when {
                        sense.enemyLocked -> "ENEMY LOCKED! Aiming & firing (${aiDec.note})"
                        sense.lookingAtSky -> "Aim recovery: pulling camera down to horizon"
                        else -> aiDec.note
                    }
                    if (firstUseOfAi) {
                        fp = aiDec.fingers
                    }
                    waitMs = aiDec.waitMs
                } else {
                    if (!useFallback && !hasApiKey) {
                        why = "Save your API key or enable Keymapper Fallback"
                        break
                    }
                    if (!useFallback && lastHttp in listOf(401, 403)) {
                        why = "the API key was rejected"
                        break
                    }
                    scene = when {
                        sense.enemyLocked -> "combat"
                        sameFrames >= 3 && lastScene == "lobby" -> "popup"
                        lastScene.isNotBlank() && lastScene != "other" -> lastScene
                        else -> "ground"
                    }
                    note = when {
                        sense.enemyLocked -> "Enemy spotted! Auto-aiming & firing burst"
                        sense.lookingAtSky -> "Camera too high -> pulling aim down to ground level"
                        else -> "Fast continuous navigation & combat scan"
                    }
                    waitMs = 200L
                }

                // Override scene to immediate combat if local pixel detector sees an enemy crosshair/marker during gameplay
                if (sense.enemyLocked && scene in setOf("ground", "in_game")) {
                    scene = "combat"
                }

                AppState.gameStage.value = scene
                AppState.gameNote.value = note
                if (scene != lastScene) {
                    lastScene = scene
                    sceneSince = System.currentTimeMillis()
                }
                if (firstUseOfAi) {
                    synchronized(memory) {
                        memory.addLast("$scene: $note")
                        while (memory.size > 6) memory.removeFirst()
                    }
                }

                when (scene) {
                    "blocked" -> { why = "the game needs you (login / ban / payment / maintenance): $note"; break }
                    "not_game" -> {
                        if (!seenInGame || System.currentTimeMillis() - lastLaunch > 12_000L) launchGame()
                        if (!sleepMs(1200)) break
                        continue
                    }
                }

                // Track match state transitions
                if (scene in setOf("plane", "parachute", "ground", "buy", "combat", "in_game")) {
                    inMatch = true
                    modeCheckedInLobby = false
                } else if (inMatch && scene in setOf("lobby", "result", "matchmaking", "mode_select")) {
                    inMatch = false
                    matches++
                    AppState.gameMatches.value = matches
                    AppState.add("Game: Match $matches finished! Starting next match...")
                }

                if (checkLeft(acc) != null) {
                    if (!sleepMs(500)) break
                    continue
                }

                // 5. Build or augment multi-touch fingers so the player NEVER stands still, ALWAYS shoots enemies, and NEVER aims at the sky
                val dm = realMetrics(ctx)
                var sw = dm.widthPixels.toDouble().coerceAtLeast(1.0)
                var sh = dm.heightPixels.toDouble().coerceAtLeast(1.0)
                if (jpg.isNotEmpty()) {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(jpg, 0, jpg.size, o)
                    if (o.outWidth > 0 && o.outHeight > 0) {
                        sw = o.outWidth.toDouble()
                        sh = o.outHeight.toDouble()
                    }
                }

                val parsedAiSpecs = ArrayList<GameKeyMap.FingerSpec>()
                if (fp != null) {
                    for (i in 0 until fp.length()) {
                        val t = fp.optJSONObject(i) ?: continue
                        GameKeyMap.resolveFingerJson(t, keys, sw, sh)?.let { parsedAiSpecs.add(it) }
                    }
                }

                val isGameplayScene = scene in setOf("ground", "combat", "in_game", "parachute")
                val needFallbackOrAugment = parsedAiSpecs.isEmpty() ||
                    sense.enemyLocked ||
                    sense.lookingAtSky ||
                    pitchTracker.needsPitchDown(sense) ||
                    (sameFrames >= 2 && scene in setOf("popup", "event", "lobby", "mode_select", "buy", "result", "dead", "spectating", "other", "ground", "combat", "in_game"))

                val rawSpecs: List<GameKeyMap.FingerSpec> = if (needFallbackOrAugment) {
                    val effectiveScene = when {
                        scene == "lobby" && !modeCheckedInLobby && stepCount <= 3 -> {
                            modeCheckedInLobby = true
                            "lobby"
                        }
                        sameFrames >= 3 && scene in setOf("lobby", "other") && closePopups -> "popup"
                        else -> scene
                    }
                    val fb = GameKeyMap.buildFallbackFingers(
                        scene = effectiveScene,
                        stepIndex = stepCount,
                        sameFrames = sameFrames,
                        gameMode = gmode,
                        fightStyle = fstyle,
                        autoLoot = autoLoot,
                        closePopups = closePopups,
                        keys = keys,
                        sense = sense,
                        pitchTracker = pitchTracker
                    )
                    // If AI provided fingers on gameplay scene, make sure a joystick movement finger is ALWAYS present alongside AI's action
                    if (parsedAiSpecs.isNotEmpty() && isGameplayScene && !sense.lookingAtSky && !sense.enemyLocked) {
                        val joyKp = GameKeyMap.getPoint(keys, "joystick")
                        val aiHasMove = parsedAiSpecs.any {
                            hypot((it.x1 - joyKp.x).toDouble(), (it.y1 - joyKp.y).toDouble()) < 0.14
                        }
                        if (aiHasMove) parsedAiSpecs else listOf(fb.first()) + parsedAiSpecs.take(2)
                    } else {
                        fb
                    }
                } else {
                    parsedAiSpecs
                }

                // Sanitize vertical drags & inject pitch-down camera swipe if aim drifted up
                val finalSpecs = if (isGameplayScene) {
                    GameKeyMap.sanitizeAndLevelFingers(rawSpecs, keys, pitchTracker, sense)
                } else {
                    rawSpecs
                }

                if (finalSpecs.isNotEmpty()) {
                    val finalArr = JSONArray().apply { finalSpecs.forEach { put(it.toJson()) } }
                    if (stepCount % 4 == 1 || firstUseOfAi || sense.enemyLocked) {
                        AppState.add("Game: $scene - $note (${finalSpecs.size} fingers)")
                    }
                    // CRITICAL FIX: wait = true ensures the gesture stroke finishes before the next loop iteration dispatches a new gesture,
                    // eliminating Android's "cancelled by Android (another gesture started)" bug!
                    if (play(ctx, acc, finalArr, jpg, wait = true, keys = keys)) {
                        touchOk++
                        badStreak = 0
                    } else {
                        touchBad++
                        badStreak++
                    }
                    AppState.gameTouch.value = "touches ok $touchOk, failed $touchBad"
                    if (badStreak > 0) AppState.add("Game: touch FAILED (${NisuAccessibilityService.lastGestureError})")
                    if (badStreak >= 8) {
                        if (!PhoneControl.reviveAccessibility(ctx, force = true)) {
                            why = "Android blocked the touches (check that NISU AI accessibility is ON and allowed)"
                            break
                        }
                        badStreak = 0
                    }
                }

                // Short breathing gap between completed gestures (60..180ms in gameplay so movement is virtually continuous!)
                val spent = System.currentTimeMillis() - t0
                val pauseMs = if (isGameplayScene) {
                    (stepMs(ctx) - spent).coerceIn(55L, 220L)
                } else {
                    maxOf(waitMs, stepMs(ctx) - spent).coerceIn(120L, 900L)
                }
                if (!sleepMs(pauseMs)) break
            }
        } catch (e: Exception) {
            why = "error: " + (e.message ?: e.javaClass.simpleName).take(80)
        }
        finish(if (!run && why == "stopped") "switched off" else why)
    }

    /** Fast similarity check so minor JPEG compression noise on a static lobby/popup/wall screen still counts as the same stuck frame. */
    private fun framesAreSimilar(a: ByteArray, b: ByteArray): Boolean {
        if (a.contentEquals(b)) return true
        val diffSize = abs(a.size - b.size).toFloat() / a.size.coerceAtLeast(1).toFloat()
        return diffSize < 0.015f
    }

    /** Real size of the screen in pixels (what gesture coordinates use), whatever the rotation. */
    @Suppress("DEPRECATION")
    internal fun realMetrics(ctx: Context): DisplayMetrics {
        val dm = DisplayMetrics()
        try {
            ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        } catch (_: Exception) {}
        if (dm.widthPixels <= 0 || dm.heightPixels <= 0) return ctx.resources.displayMetrics
        return dm
    }

    /**
     * Plays the fingers (fractions 0..1 of the screenshot, or symbolic Keymapper ids like `"key":"start_btn"`)
     * as ONE synchronized multi-touch gesture. Falls back to root shell input if accessibility dispatch is rejected.
     */
    internal fun play(
        ctx: Context,
        acc: NisuAccessibilityService,
        arr: JSONArray,
        shot: ByteArray?,
        wait: Boolean,
        keys: Map<String, GameKeyMap.KeyPoint> = loadKeys(ctx)
    ): Boolean {
        val dm = realMetrics(ctx)
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        var sw = w.toDouble()
        var sh = h.toDouble()
        if (shot != null && shot.isNotEmpty()) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(shot, 0, shot.size, o)
            if (o.outWidth > 0 && o.outHeight > 0) {
                sw = o.outWidth.toDouble()
                sh = o.outHeight.toDouble()
            }
        }

        val list = ArrayList<NisuAccessibilityService.Finger>()
        val maxF = if (Prefs.getBool(ctx, Prefs.GAME_MULTI, true)) acc.maxFingers else 1
        for (i in 0 until minOf(arr.length(), maxF)) {
            val t = arr.optJSONObject(i) ?: continue
            val spec = GameKeyMap.resolveFingerJson(t, keys, sw, sh) ?: continue
            list.add(
                NisuAccessibilityService.Finger(
                    spec.x1 * w,
                    spec.y1 * h,
                    spec.x2 * w,
                    spec.y2 * h,
                    spec.startMs,
                    spec.durationMs
                )
            )
        }
        if (list.isEmpty()) return true
        val ok = try { acc.multiTouch(list, 1, 0L, wait = wait) } catch (_: Exception) { false }
        if (ok) return true
        if (rootOk) {
            for (f in list.take(2)) {
                val cmd = if (abs(f.x1 - f.x2) < 2f && abs(f.y1 - f.y2) < 2f) {
                    "input tap ${f.x1.toInt()} ${f.y1.toInt()}"
                } else {
                    "input swipe ${f.x1.toInt()} ${f.y1.toInt()} ${f.x2.toInt()} ${f.y2.toInt()} ${f.durMs}"
                }
                val r = try { Root.exec(cmd, f.durMs + 2500L) } catch (_: Exception) { null }
                if (r != null && r.first == 0) return true
            }
        }
        return false
    }

    /** Trigger a single mapped key or fallback step immediately (for the user's "TEST STEP" button). */
    fun triggerManualKey(ctx: Context, keyId: String): Boolean {
        val acc = NisuAccessibilityService.inst ?: return false
        val keys = loadKeys(ctx)
        val kp = GameKeyMap.getPoint(keys, keyId)
        val spec = if (kp.isJoystick) {
            GameKeyMap.FingerSpec(kp.x, kp.y, kp.x, (kp.y - 0.20f).coerceAtLeast(0.1f), 0L, 650L)
        } else {
            GameKeyMap.FingerSpec(kp.x, kp.y, kp.x, kp.y, 0L, 85L)
        }
        return play(ctx, acc, JSONArray().put(spec.toJson()), null, wait = false, keys = keys)
    }

    private val rootOk: Boolean by lazy { try { Root.available() } catch (_: Exception) { false } }
    private var touchOk = 0
    private var touchBad = 0
    private var badStreak = 0

    // ---------------------------------------------------------------- the AI
    @Volatile private var lastHttp = 0

    internal fun prompt(
        ctx: Context,
        label: String,
        matches: Int,
        scene: String,
        secs: Int,
        same: Int,
        mem: List<String>,
        keys: Map<String, GameKeyMap.KeyPoint> = loadKeys(ctx),
        sense: GameKeyMap.FrameSense = GameKeyMap.FrameSense(),
        currentPitch: Float = 0f
    ): String {
        val zone = Prefs.getBool(ctx, Prefs.GAME_ZONE, true)
        val loot = Prefs.getBool(ctx, Prefs.GAME_LOOT, true)
        val pop = Prefs.getBool(ctx, Prefs.GAME_POPUPS, true)
        val style = Prefs.get(ctx, Prefs.GAME_STYLE, "balanced")
        val gm = Prefs.get(ctx, Prefs.GAME_MODE, "clash")
        val clash = gm == "clash" || gm == "cs_rank"
        val ranked = gm == "cs_rank" || gm == "br_rank"
        val modeName = when (gm) {
            "cs_rank" -> "CLASH SQUAD RANKED (CS-Ranked)"
            "br_rank" -> "BATTLE ROYALE RANKED (BR-Ranked)"
            "classic", "br" -> "BATTLE ROYALE (Classic / Casual)"
            else -> "CLASH SQUAD (Casual / Normal)"
        }
        val styleText = when (style) {
            "safe" -> "SAFE: move from cover to cover inside the safe zone, keep camera level at horizon (y=0.48), and shoot enemies when spotted."
            "aggressive" -> "AGGRESSIVE: constantly sprint forward toward open paths/enemies, scan left/right keeping camera level at horizon (y=0.48), lock aim and fire bursts whenever an enemy is visible, and strafe/jump in fights."
            else -> "BALANCED: run continuously along roads/open paths, pick up weapons/loot, keep camera level at horizon (y=0.48), and fire bursts whenever an enemy appears."
        }
        val keyCoords = GameKeyMap.promptSummary(keys)
        val senseHint = buildString {
            if (sense.enemyLocked) append("ALERT: Red enemy crosshair/marker detected at offset=(${String.format(java.util.Locale.US, "%.2f", sense.enemyOffsetX)}, ${String.format(java.util.Locale.US, "%.2f", sense.enemyOffsetY)})! Shoot immediately! ")
            if (sense.lookingAtSky || currentPitch >= 0.16f) append("WARNING: Camera aim is pointing UP at the sky! You MUST include a right-side downward camera swipe (x=0.64, y=0.26 -> x2=0.64, y2=0.60, duration_ms=260) to bring aim back down to ground level! ")
            if (sense.wallBlocked || same >= 2) append("WARNING: Character is blocked by a wall/obstacle! Strafe sideways + tap jump + swipe camera left/right (x=0.62, y=0.48 -> x2=0.82, y2=0.50) to turn around it! ")
        }

        return """
You are an autonomous pro mobile gamer playing $label in landscape mode. You see ONE live screenshot and MUST return the exact multi-touch fingers to execute right now.
GOAL: Play match after match non-stop with fast, continuous movement, level camera aim, and aggressive enemy targeting:
1. Close any startup "Tap to Begin", event banners, daily login popups, or ads.
2. In the lobby, verify the selected mode is $modeName (if not, tap the mode selector above START and pick $modeName), then tap the yellow START button.
3. During the match: ${if (clash) "in Clash Squad buy a gun + vest/gloo in the buy menu, then run out of spawn along open corridors, keep camera level at eye height, spot enemies, aim, and shoot to win rounds." else "in Battle Royale eject/jump from the plane, glide to buildings, pick up weapons/loot, navigate roads/doors toward the safe zone, and fight enemies."}
4. When the match ends (Booyah / Defeat / Match Result / Scoreboard), tap Continue / Next / Back / Play Again to return to the lobby and start the next match immediately.

Matches finished: $matches. Previous scene: ${scene.ifBlank { "none" }} (for $secs s). Identical frames in a row: $same.
$senseHint
Recent history: ${if (mem.isEmpty()) "none" else mem.joinToString(" -> ")}

USER'S MAPPED HUD KEY COORDINATES (fractions 0..1 of screen width x, height y):
$keyCoords
You can pass exact `"x":0.xx,"y":0.yy` coordinates OR reference any mapped key by `"key":"start_btn"`.

OUTPUT FORMAT: Return ONLY valid JSON, no markdown:
{"scene":"...","note":"short reason max 10 words","fingers":[{"x":0.88,"y":0.90,"duration_ms":90}],"wait_ms":220}
Valid `scene` values: popup, lobby, mode_select, matchmaking, loading, buy, plane, parachute, ground, combat, dead, spectating, result, not_game, blocked.

CRITICAL RULES FOR EVERY SCENE (NEVER RETURN EMPTY `fingers` EXCEPT IN `loading`/`matchmaking`/`blocked`):
- `popup`: Any event poster, ad banner, daily reward, or "Tap to Begin" screen. ${if (pop) "Tap the visible X / Close button (`event_close` or top-right x=0.90..0.96, y=0.06..0.15)." else "Return fingers []."}
- `lobby`: Tap `start_btn` (bottom-right yellow button) or `mode_btn` if mode is not $modeName.
- `mode_select`: Tap the card for $modeName${if (ranked) " (Ranked)" else " (Casual)"}.
- `buy`: Clash Squad shop. Tap `buy_gun1` or `buy_gun2`, tap `buy_vest`, then tap `buy_close`.
- `plane`: Tap `jump` to eject.
- `parachute`: Slide `joystick` forward (`x` to `x`, `y` to `y-0.22`, `duration_ms`: 560) and angle camera slightly down (`x`:0.65, `y`:0.42 -> `x2`:0.65, `y2`:0.52, `duration_ms`:240).
- `ground` / `combat`: Active gameplay! Keep stroke `duration_ms` between 220 and 560ms for ultra-fast reaction:
  1) ALWAYS include Finger 1 (Continuous Move): Slide `joystick` upward/diagonally (`y2 = y - 0.22`, `x2 = x - 0.08..+0.08`, `duration_ms`: 540) or tap `sprint` so the player constantly navigates forward along open roads/doors/stairs.
  2) CAMERA PITCH & AIM LEVELING (CRITICAL): If the camera is looking up at the sky/roof/trees, swipe DOWN on the right side (`x`:0.64, `y`:0.26 -> `x2`:0.64, `y2`:0.60, `duration_ms`:260) to pull the crosshair DOWN to the horizon (`y=0.48`)! NEVER drag the fire button high upward (`y2` must stay within `y - 0.03` of `fire.y`).
  3) PATH NAVIGATION & OBSTACLES: Look at where paths, doors, stairs, or open spaces are. Swipe the right look area horizontally (`x`:0.62 -> `x2`:0.46 to turn left, or `x`:0.62 -> `x2`:0.78 to turn right, `y`:0.48, `duration_ms`:240) to steer toward open paths and around walls!
  4) ENEMY COMBAT (`combat`): Whenever an enemy silhouette, red nametag, or red crosshair is visible, set `scene`:`"combat"`, steer the camera toward the enemy, tap `aim` (or hip-fire at close range), and hold `fire` (`duration_ms`: 460) with level/slight-down recoil control!
  FIGHT STYLE: $styleText
  ${if (loot) "LOOT: Tap `loot1`/`loot2` when weapons, ammo, or medkits appear." else ""}
  ${if (zone) "SAFE ZONE: Check the minimap (top-left) and steer toward the white safe circle." else ""}
- `dead` / `spectating` / `result`: Tap `back_cont` or `start_btn` to return to lobby and start next match.
- `blocked`: Only for login/password, ban, forced update, or real-money payment screen.
""".trimIndent()
    }

    /** One request. Returns the parsed JSON object or null when the call failed. */
    private fun ask(
        ctx: Context,
        label: String,
        jpg: ByteArray,
        matches: Int,
        scene: String,
        secs: Int,
        same: Int,
        mem: List<String>,
        keys: Map<String, GameKeyMap.KeyPoint>,
        sense: GameKeyMap.FrameSense = GameKeyMap.FrameSense(),
        currentPitch: Float = 0f
    ): JSONObject? {
        val key = Prefs.get(ctx, Prefs.KEY, "").trim()
        val chosen = Prefs.get(ctx, Prefs.CHAT_MODEL, Prefs.DEFAULT_CHAT_MODEL).trim().removePrefix("models/")
        val models = listOf(
            "gemini-2.5-flash",
            "gemini-2.0-flash",
            "gemini-3.1-flash-lite",
            "gemini-2.5-flash-lite",
            chosen
        ).filter { it.isNotBlank() && !it.contains("live") }.distinct()
        if (modelIdx >= models.size) modelIdx = 0
        val model = models[modelIdx]
        val b64 = Base64.encodeToString(jpg, Base64.NO_WRAP)

        fun call(mode: Int): JSONObject? {
            val gen = JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", 320)
                .put("responseMimeType", "application/json")
            if (mode == 0 && model.startsWith("gemini-2.5")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            } else if (mode == 1 && model.startsWith("gemini-3")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            }
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user").put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("text", prompt(ctx, label, matches, scene, secs, same, mem, keys, sense, currentPitch)))
                                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                        )
                    )
                )
                .put("generationConfig", gen)
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            return try {
                http.newCall(req).execute().use { resp ->
                    lastHttp = if (resp.isSuccessful) 0 else resp.code
                    val txt = resp.body?.string() ?: return null
                    if (!resp.isSuccessful) {
                        lastErr = "HTTP ${resp.code}: " + (try {
                            JSONObject(txt).optJSONObject("error")?.optString("message", "") ?: ""
                        } catch (_: Exception) { "" }).take(110)
                        return null
                    }
                    val parts = JSONObject(txt).optJSONArray("candidates")
                        ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts == null) { lastErr = "empty answer from the AI"; return null }
                    val sb = StringBuilder()
                    for (k in 0 until parts.length()) {
                        val p = parts.optJSONObject(k) ?: continue
                        if (p.optBoolean("thought", false)) continue
                        sb.append(p.optString("text", ""))
                    }
                    val j = parseJson(sb.toString())
                    if (j == null) lastErr = "the AI answer was not JSON: " + sb.toString().take(60)
                    j
                }
            } catch (e: Exception) {
                lastHttp = -1
                lastErr = "network: " + (e.message ?: e.javaClass.simpleName).take(80)
                null
            }
        }

        var r = call(thinkMode)
        if (r == null && (lastHttp == 404 || lastHttp == 429 || lastHttp == 400) && modelIdx + 1 < models.size) {
            modelIdx++
            AppState.add("Game: switching vision model to ${models[modelIdx]}")
            return ask(ctx, label, jpg, matches, scene, secs, same, mem, keys, sense, currentPitch)
        }
        while (r == null && lastHttp == 400 && thinkMode < 2) {
            thinkMode++
            r = call(thinkMode)
        }
        return r
    }

    internal fun parseJson(raw: String): JSONObject? {
        var s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        s = s.substring(a, b + 1)
        return try { JSONObject(s) } catch (_: Exception) { null }
    }

    // ================================================================================================
    // VISUAL KEYMAPPER OVERLAY & FLOATING GAME CONTROL BAR (SYSTEM_ALERT_WINDOW)
    // ================================================================================================
    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlayView: KeymapperOverlayView? = null
    private var hudBarView: FloatingGameBarView? = null

    fun canDrawOverlays(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    /** Opens or closes the full-screen draggable Keymapper editor overlay on top of any app/game. */
    fun setKeymapperOverlay(ctx: Context, show: Boolean) {
        val app = ctx.applicationContext
        mainHandler.post {
            if (show) {
                if (!canDrawOverlays(app)) return@post
                loadKeys(app)
                if (overlayView == null) {
                    try {
                        val wm = app.getSystemService(WindowManager::class.java)
                        val v = KeymapperOverlayView(app)
                        val lp = WindowManager.LayoutParams(
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                            PixelFormat.TRANSLUCENT
                        ).apply {
                            gravity = Gravity.TOP or Gravity.START
                        }
                        wm.addView(v, lp)
                        overlayView = v
                        keymapperShowing.value = true
                    } catch (_: Throwable) {}
                }
            } else {
                val v = overlayView
                overlayView = null
                keymapperShowing.value = false
                if (v != null) {
                    try { app.getSystemService(WindowManager::class.java).removeViewImmediate(v) } catch (_: Throwable) {}
                }
            }
        }
    }

    /** Shows or hides a compact floating controller pill (`AUTO PLAY`, `EDIT KEYS`, `STEP`) on top of the game. */
    fun setFloatingHudBar(ctx: Context, show: Boolean) {
        val app = ctx.applicationContext
        mainHandler.post {
            if (show) {
                if (!canDrawOverlays(app)) return@post
                if (hudBarView == null) {
                    try {
                        val wm = app.getSystemService(WindowManager::class.java)
                        val lp = WindowManager.LayoutParams(
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                            PixelFormat.TRANSLUCENT
                        ).apply {
                            gravity = Gravity.TOP or Gravity.START
                            x = 60
                            y = 80
                        }
                        val v = FloatingGameBarView(app, wm, lp)
                        wm.addView(v, lp)
                        hudBarView = v
                        hudBarShowing.value = true
                    } catch (_: Throwable) {}
                }
            } else {
                val v = hudBarView
                hudBarView = null
                hudBarShowing.value = false
                if (v != null) {
                    try { app.getSystemService(WindowManager::class.java).removeViewImmediate(v) } catch (_: Throwable) {}
                }
            }
        }
    }

    /**
     * Full-screen translucent interactive Keymapper Canvas:
     * - Draws every mapped game button (START, Mode, Event X, Joystick, Fire, Aim, Jump, Crouch, Reload, Gloo, Heal, Loot, CS Buy).
     * - Drag any circle with 1 finger to place it directly over the game's real button!
     * - Top control bar has `SAVE & LOCK`, `RESET DEFAULTS`, and `TEST TAP` buttons.
     */
    private class KeymapperOverlayView(context: Context) : View(context) {
        private val density = context.resources.displayMetrics.density
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * density
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 10.5f * density
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFD0E4FF.toInt()
            textSize = 9.5f * density
            textAlign = Paint.Align.CENTER
        }
        private val headerRect = RectF()
        private val btnSaveRect = RectF()
        private val btnResetRect = RectF()
        private val btnAutoRect = RectF()

        private var draggingId: String? = null
        private var selectedId: String = "fire"

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)

            // Subtle translucent dim so the game HUD underneath is clearly visible
            canvas.drawColor(0x55020816)

            // Draw crosshair grid lines
            strokePaint.color = 0x3338B6FF
            strokePaint.strokeWidth = 1f * density
            canvas.drawLine(w * 0.5f, 0f, w * 0.5f, h, strokePaint)
            canvas.drawLine(0f, h * 0.5f, w, h * 0.5f, strokePaint)

            val keys = keysState.value
            for ((id, kp) in keys) {
                val cx = kp.x * w
                val cy = kp.y * h
                val r = kp.radiusDp * density
                val isSel = id == draggingId || id == selectedId

                // Outer glow ring for joystick or selected key
                if (kp.isJoystick) {
                    fillPaint.color = 0x3338B6FF
                    canvas.drawCircle(cx, cy, r * 1.55f, fillPaint)
                    strokePaint.color = 0xAA38B6FF.toInt()
                    strokePaint.strokeWidth = 1.6f * density
                    canvas.drawCircle(cx, cy, r * 1.55f, strokePaint)
                }

                fillPaint.color = (kp.colorHex and 0x00FFFFFF) or (if (isSel) 0xCC000000.toInt() else 0x88000000.toInt())
                canvas.drawCircle(cx, cy, r, fillPaint)

                strokePaint.color = if (isSel) Color.WHITE else kp.colorHex
                strokePaint.strokeWidth = (if (isSel) 3f else 2f) * density
                canvas.drawCircle(cx, cy, r, strokePaint)

                // Crosshair center dot
                fillPaint.color = Color.WHITE
                canvas.drawCircle(cx, cy, 2.5f * density, fillPaint)

                // Key short label
                val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
                canvas.drawText(kp.shortLabel, cx, ty, textPaint)
            }

            // Top floating control bar inside Keymapper editor
            val barW = minOf(w * 0.92f, 460f * density)
            val barH = 54f * density
            val barLeft = (w - barW) / 2f
            val barTop = 14f * density
            headerRect.set(barLeft, barTop, barLeft + barW, barTop + barH)

            fillPaint.color = 0xEE071228.toInt()
            canvas.drawRoundRect(headerRect, 14f * density, 14f * density, fillPaint)
            strokePaint.color = 0xFF38B6FF.toInt()
            strokePaint.strokeWidth = 1.5f * density
            canvas.drawRoundRect(headerRect, 14f * density, 14f * density, strokePaint)

            val selKp = keys[selectedId]
            val title = if (selKp != null) {
                "Drag keys onto game buttons | Selected: ${selKp.label} (${(selKp.x * 100).roundToInt()}%, ${(selKp.y * 100).roundToInt()}%)"
            } else {
                "Drag any circle over your game buttons, then tap SAVE & CLOSE"
            }
            canvas.drawText(title, headerRect.centerX(), headerRect.top + 17f * density, subTextPaint)

            val pad = 8f * density
            val btnY1 = headerRect.top + 23f * density
            val btnY2 = headerRect.bottom - 6f * density
            val btnW = (barW - pad * 4f) / 3f

            btnAutoRect.set(barLeft + pad, btnY1, barLeft + pad + btnW, btnY2)
            btnResetRect.set(btnAutoRect.right + pad, btnY1, btnAutoRect.right + pad + btnW, btnY2)
            btnSaveRect.set(btnResetRect.right + pad, btnY1, btnResetRect.right + pad + btnW, btnY2)

            // Button 1: Auto Play ON/OFF
            val isAuto = AppState.gameAuto.value
            fillPaint.color = if (isAuto) 0xFF63D6A0.toInt() else 0xFF2F6BFF.toInt()
            canvas.drawRoundRect(btnAutoRect, 8f * density, 8f * density, fillPaint)
            textPaint.color = Color.BLACK
            canvas.drawText(
                if (isAuto) "AUTO: ON (STOP)" else "START AUTO PLAY",
                btnAutoRect.centerX(),
                btnAutoRect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f,
                textPaint
            )

            // Button 2: Reset defaults
            fillPaint.color = 0xFFF0BE6A.toInt()
            canvas.drawRoundRect(btnResetRect, 8f * density, 8f * density, fillPaint)
            canvas.drawText(
                "RESET KEYS",
                btnResetRect.centerX(),
                btnResetRect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f,
                textPaint
            )

            // Button 3: Save & Close
            fillPaint.color = 0xFF38B6FF.toInt()
            canvas.drawRoundRect(btnSaveRect, 8f * density, 8f * density, fillPaint)
            canvas.drawText(
                "SAVE & CLOSE",
                btnSaveRect.centerX(),
                btnSaveRect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f,
                textPaint
            )
            textPaint.color = Color.WHITE
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val x = event.x
            val y = event.y

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (btnSaveRect.contains(x, y)) {
                        setKeymapperOverlay(context, false)
                        return true
                    }
                    if (btnResetRect.contains(x, y)) {
                        resetKeys(context)
                        invalidate()
                        return true
                    }
                    if (btnAutoRect.contains(x, y)) {
                        if (AppState.gameAuto.value) stop("switched off from Keymapper")
                        else start(context)
                        invalidate()
                        return true
                    }
                    // Find nearest key circle
                    val keys = keysState.value
                    var bestId: String? = null
                    var bestDist = Float.MAX_VALUE
                    for ((id, kp) in keys) {
                        val cx = kp.x * w
                        val cy = kp.y * h
                        val dist = hypot((x - cx).toDouble(), (y - cy).toDouble()).toFloat()
                        val hitRadius = (kp.radiusDp * density) * 1.45f
                        if (dist <= hitRadius && dist < bestDist) {
                            bestDist = dist
                            bestId = id
                        }
                    }
                    if (bestId != null) {
                        draggingId = bestId
                        selectedId = bestId
                        invalidate()
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val id = draggingId ?: return true
                    val nx = (x / w).coerceIn(0.02f, 0.98f)
                    val ny = (y / h).coerceIn(0.02f, 0.98f)
                    saveKeyPosition(context, id, nx, ny)
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    draggingId = null
                    invalidate()
                }
            }
            return true
        }
    }

    /**
     * Compact draggable floating pill (`[AUTO: ON/OFF] [KEYS] [X]`) that stays on top of the game
     * without blocking touches on the rest of the screen (`WRAP_CONTENT` + `FLAG_NOT_FOCUSABLE`).
     */
    private class FloatingGameBarView(
        context: Context,
        private val wm: WindowManager,
        private val lp: WindowManager.LayoutParams
    ) : View(context) {
        private val density = context.resources.displayMetrics.density
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xDD071228.toInt() }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * density
            color = 0xFF38B6FF.toInt()
        }
        private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 11f * density
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val rectAuto = RectF()
        private val rectKeys = RectF()
        private val rectClose = RectF()

        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false

        private val refreshTick = object : Runnable {
            override fun run() {
                if (hudBarView === this@FloatingGameBarView) {
                    invalidate()
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }

        init {
            mainHandler.postDelayed(refreshTick, 1000L)
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            setMeasuredDimension((224f * density).roundToInt(), (38f * density).roundToInt())
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            val outer = RectF(1f * density, 1f * density, w - 1f * density, h - 1f * density)
            canvas.drawRoundRect(outer, 19f * density, 19f * density, bgPaint)
            canvas.drawRoundRect(outer, 19f * density, 19f * density, borderPaint)

            val pad = 5f * density
            rectAuto.set(pad, pad, 106f * density, h - pad)
            rectKeys.set(110f * density, pad, 184f * density, h - pad)
            rectClose.set(188f * density, pad, w - pad, h - pad)

            val autoOn = AppState.gameAuto.value
            chipPaint.color = if (autoOn) 0xFF63D6A0.toInt() else 0xFF38B6FF.toInt()
            canvas.drawRoundRect(rectAuto, 14f * density, 14f * density, chipPaint)
            txtPaint.color = Color.BLACK
            val ty = h / 2f - (txtPaint.descent() + txtPaint.ascent()) / 2f
            canvas.drawText(if (autoOn) "AUTO: ON" else "AUTO: OFF", rectAuto.centerX(), ty, txtPaint)

            val keysOn = keymapperShowing.value
            chipPaint.color = if (keysOn) 0xFFF0BE6A.toInt() else 0xFF16336E.toInt()
            canvas.drawRoundRect(rectKeys, 14f * density, 14f * density, chipPaint)
            txtPaint.color = if (keysOn) Color.BLACK else Color.WHITE
            canvas.drawText("KEYMAP", rectKeys.centerX(), ty, txtPaint)

            chipPaint.color = 0xFFEA6F66.toInt()
            canvas.drawRoundRect(rectClose, 14f * density, 14f * density, chipPaint)
            txtPaint.color = Color.BLACK
            canvas.drawText("X", rectClose.centerX(), ty, txtPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragging || hypot(dx.toDouble(), dy.toDouble()) > 10.0) {
                        dragging = true
                        lp.x = startX + dx.roundToInt()
                        lp.y = startY + dy.roundToInt()
                        try { wm.updateViewLayout(this, lp) } catch (_: Throwable) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val x = event.x
                        val y = event.y
                        when {
                            rectAuto.contains(x, y) -> {
                                if (AppState.gameAuto.value) stop("paused from floating bar")
                                else start(context)
                                invalidate()
                            }
                            rectKeys.contains(x, y) -> {
                                setKeymapperOverlay(context, !keymapperShowing.value)
                                invalidate()
                            }
                            rectClose.contains(x, y) -> {
                                setKeymapperOverlay(context, false)
                                setFloatingHudBar(context, false)
                            }
                        }
                    }
                }
            }
            return true
        }
    }
}
