package ai.nisu.assistant

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/*
 * v3.164: PROFESSIONAL LIVE CODE VIEWER, LIVE WEBSITE BUILDER RUNNER & APK GENERATOR STUDIO.
 * - Real-time streaming code display (shows every file while the AI is writing it, plus saved projects at all times).
 * - Built-in "Run Website" in-app live WebView runner + "Open in Chrome" + "Open in Browser" fallback when Chrome fails or blocks.
 * - 1-click "Save Website ZIP" and "Save APK ZIP" (saves to /sdcard/Download/ with standalone HTML and self-building build-termux.sh).
 * - 1-click "Build APK in Termux" + "Copy Termux Command" + "Install APK".
 * - Direct Quick Builder bar so the user can also start a Website or APK build right from the Live Code Studio!
 */

private val Kw = setOf(
    "fun", "val", "var", "class", "object", "interface", "return", "if", "else", "when", "for", "while", "import", "package", "private",
    "public", "override", "null", "true", "false", "function", "const", "let", "new", "this", "def", "async", "await", "export", "try", "catch",
    "in", "is", "as", "static", "final", "void", "int", "String", "from", "None", "True", "False", "self"
)
private val CKw = Color(0xFF8A6CFF)
private val CStr = Color(0xFF63D6A0)
private val CCom = Color(0xFF6F82A8)
private val CNum = Color(0xFFF0BE6A)
private val CTag = Color(0xFF38B6FF)

/** One line, lightly coloured (comments, strings, numbers, keywords, HTML/XML tags). Per line, so a long file stays cheap. */
internal fun highlightLine(line: String, diff: Boolean): AnnotatedString = buildAnnotatedString {
    if (diff && (line.startsWith("- ") || line.startsWith("+ "))) {
        withStyle(SpanStyle(color = if (line[0] == '+') NisuUi.Green else NisuUi.Red)) { append(line) }
        return@buildAnnotatedString
    }
    val t = line.trimStart()
    if (t.startsWith("//") || t.startsWith("#") || t.startsWith("*") || t.startsWith("/*") || t.startsWith("<!--")) {
        withStyle(SpanStyle(color = CCom)) { append(line) }
        return@buildAnnotatedString
    }
    var i = 0
    val n = line.length
    while (i < n) {
        val ch = line[i]
        when {
            ch == '"' || ch == '\'' || ch == '`' -> {
                var j = i + 1
                while (j < n && line[j] != ch) { if (line[j] == '\\') j++; j++ }
                val e = minOf(j + 1, n)
                withStyle(SpanStyle(color = CStr)) { append(line.substring(i, e)) }
                i = e
            }
            ch == '<' && i + 1 < n && (line[i + 1].isLetter() || line[i + 1] == '/' || line[i + 1] == '!') -> {
                var j = i + 1
                while (j < n && (line[j].isLetterOrDigit() || line[j] in "/-:._!")) j++
                withStyle(SpanStyle(color = CTag)) { append(line.substring(i, j)) }
                i = j
            }
            ch.isDigit() -> {
                var j = i
                while (j < n && (line[j].isLetterOrDigit() || line[j] == '.')) j++
                withStyle(SpanStyle(color = CNum)) { append(line.substring(i, j)) }
                i = j
            }
            ch.isLetter() || ch == '_' -> {
                var j = i
                while (j < n && (line[j].isLetterOrDigit() || line[j] == '_')) j++
                val w = line.substring(i, j)
                if (w in Kw) withStyle(SpanStyle(color = CKw)) { append(w) } else append(w)
                i = j
            }
            else -> { append(ch); i++ }
        }
    }
}

@Composable
internal fun LiveCodePage() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snap by LiveCode.state.collectAsState()
    val runnerUrl by WebBuilder.inAppRunnerUrl.collectAsState()
    val runnerSlug by WebBuilder.inAppRunnerSlug.collectAsState()

    var sel by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf(0) }       // lines typed out so far for the file that just arrived
    var follow by remember { mutableStateOf("") }     // "path#rev" that is being typed out
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var viewMode by remember { mutableStateOf("code") } // "code" | "preview" | "projects" | "builder"
    var statusBanner by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current

    // Always ensure existing code from disk is loaded if memory is empty so Live Code Viewer shows code at all times!
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { LiveCode.ensureLoadedFromDisk(ctx) }
    }

    LaunchedEffect(snap.busy) {
        while (snap.busy) {
            now = System.currentTimeMillis()
            delay(400)
        }
    }

    val newest = snap.files.lastOrNull()
    // When a new file arrives or streams: jump to it and display live
    LaunchedEffect(snap.tick, newest?.path, newest?.content?.length) {
        val f = newest ?: return@LaunchedEffect
        if (sel.isEmpty() || snap.busy || f.kind == "live") {
            sel = f.path
        }
        if (f.kind == "live" || snap.busy) {
            follow = ""
            return@LaunchedEffect
        }
        val key = f.path + "#" + f.rev
        if (follow != key) {
            follow = key
            val total = f.content.count { it == '\n' } + 1
            val perStep = maxOf(2, total / 60)
            shown = 0
            while (shown < total) {
                shown = minOf(total, shown + perStep)
                delay(14)
            }
            follow = ""
        }
    }

    val file = snap.files.firstOrNull { it.path == sel } ?: newest
    val hasHtml = snap.files.any { it.path.endsWith(".html") || it.path.endsWith(".htm") }
    val isWebsite = snap.activeType == "website" || hasHtml
    val isApp = snap.activeType == "app" || snap.files.any { it.path.endsWith("AndroidManifest.xml") || it.path.endsWith("build.gradle.kts") }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        // Top Header Bar
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Live Code Studio", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = NisuUi.Text)
                    if (snap.busy) {
                        Spacer(Modifier.width(8.dp))
                        Box(
                            Modifier.clip(RoundedCornerShape(50))
                                .background(NisuUi.Amber.copy(alpha = 0.2f))
                                .border(1.dp, NisuUi.Amber, RoundedCornerShape(50))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("LIVE STREAMING", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NisuUi.Amber)
                        }
                    }
                }
                if (snap.activeProject.isNotBlank()) {
                    Text(
                        "Active: ${snap.activeProject} (${snap.activeType.ifBlank { "project" }})" +
                            (if (snap.files.isNotEmpty()) " • ${snap.files.size} files" else ""),
                        fontSize = 11.sp, color = NisuUi.Cyan
                    )
                }
            }
            Pill("Projects", active = viewMode == "projects") { viewMode = if (viewMode == "projects") "code" else "projects" }
            Spacer(Modifier.width(6.dp))
            Pill("+ Build", active = viewMode == "builder", accent = NisuUi.Green) { viewMode = if (viewMode == "builder") "code" else "builder" }
        }

        // Real-time Status Bar
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(NisuUi.Card.copy(alpha = 0.75f))
                .border(1.dp, if (snap.busy) NisuUi.Amber.copy(alpha = 0.6f) else NisuUi.Line, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val col = when {
                snap.error.isNotEmpty() -> NisuUi.Red
                snap.busy -> NisuUi.Amber
                snap.files.isNotEmpty() -> NisuUi.Green
                else -> NisuUi.Muted
            }
            Box(Modifier.size(9.dp).clip(CircleShape).background(col))
            Spacer(Modifier.width(8.dp))
            val statusText = when {
                snap.error.isNotEmpty() -> "Stopped: ${snap.error}"
                snap.busy -> (if (snap.note.isNotBlank()) "${snap.note} • " else "") +
                    "${snap.who.ifBlank { "Main Brain" }} is writing" +
                    (if (snap.step.isNotBlank()) " (${snap.step})" else "") +
                    " • ${maxOf(0L, (now - snap.startedAt) / 1000)}s"
                snap.files.isNotEmpty() -> "Ready • ${snap.who.ifBlank { "Main Brain" }}" +
                    (if (snap.step.isNotBlank()) " • ${snap.step}" else "")
                else -> "Ready. Build a Website or APK, or open Projects to load saved code."
            }
            Text(statusText, fontSize = 11.sp, color = NisuUi.Text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (snap.files.isNotEmpty()) {
                Spacer(Modifier.width(6.dp))
                Pill("Copy") {
                    file?.let {
                        clip.setText(AnnotatedString(it.content))
                        Toast.makeText(ctx, "Copied ${it.path}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        if (statusBanner.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(NisuUi.Cyan.copy(alpha = 0.14f))
                    .border(1.dp, NisuUi.Cyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(statusBanner, fontSize = 11.sp, color = NisuUi.Cyan, modifier = Modifier.weight(1f))
                Text("✕", fontSize = 12.sp, color = NisuUi.Muted, modifier = Modifier.clickable { statusBanner = "" }.padding(start = 8.dp))
            }
        }

        Spacer(Modifier.height(6.dp))

        // Action Toolbar: Run Website (In-App + Chrome + Browser) | Save Website ZIP | Save APK ZIP | Build APK in Termux | Install APK
        if (snap.files.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Pill("Code View", active = viewMode == "code") { viewMode = "code" }

                if (isWebsite) {
                    // Run Website right inside the app (100% works even if Chrome fails or isn't installed!)
                    Pill("▶ Run Website (In-App)", active = viewMode == "preview", accent = NisuUi.Green) {
                        viewMode = if (viewMode == "preview") "code" else "preview"
                    }
                    // Open in Chrome / External Browser
                    Pill("🌐 Open in Chrome", accent = NisuUi.Cyan) {
                        scope.launch {
                            val slug = snap.activeProject.takeIf { it.isNotBlank() && WebBuilder.dirOf(ctx, it).isDirectory }
                                ?: WebBuilder.sites(ctx).firstOrNull()?.name.orEmpty()
                            if (slug.isNotEmpty()) {
                                val r = withContext(Dispatchers.IO) { WebBuilder.openWebsiteSmart(ctx, slug) }
                                if (!r.optBoolean("ok", false)) {
                                    viewMode = "preview"
                                    Toast.makeText(ctx, "Chrome did not open — running website inside Live Code!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                viewMode = "preview"
                            }
                        }
                    }
                    // Save Website as ZIP
                    Pill("📦 Save Website ZIP", accent = NisuUi.Amber) {
                        scope.launch {
                            val f = withContext(Dispatchers.IO) {
                                val slug = snap.activeProject.takeIf { it.isNotBlank() && WebBuilder.dirOf(ctx, it).isDirectory }
                                    ?: WebBuilder.sites(ctx).firstOrNull()?.name
                                if (slug != null) WebBuilder.exportZip(ctx, slug)
                                else exportCurrentSnapFilesAsZip(ctx, snap.activeProject.ifBlank { "website" }, snap.files)
                            }
                            statusBanner = if (f != null) "Saved Website ZIP: ${f.absolutePath}" else "Could not save ZIP."
                            Toast.makeText(ctx, statusBanner, Toast.LENGTH_LONG).show()
                        }
                    }
                }

                if (isApp) {
                    // Save APK Source as self-building ZIP
                    Pill("📦 Save APK Source ZIP", accent = NisuUi.Amber) {
                        scope.launch {
                            val f = withContext(Dispatchers.IO) {
                                val slug = snap.activeProject.ifBlank { AppBuilder.resolveSlug(ctx, "") }
                                if (slug.isNotEmpty()) AppBuilder.exportZip(ctx, slug)
                                else exportCurrentSnapFilesAsZip(ctx, "apk-source", snap.files)
                            }
                            statusBanner = if (f != null) "Saved Self-Building APK ZIP: ${f.absolutePath}" else "Could not save APK ZIP."
                            Toast.makeText(ctx, statusBanner, Toast.LENGTH_LONG).show()
                        }
                    }
                    // Self-Build APK in Termux
                    Pill("⚡ Build APK in Termux", accent = NisuUi.Green) {
                        scope.launch {
                            val slug = snap.activeProject.ifBlank { AppBuilder.resolveSlug(ctx, "") }
                            val (_, msg) = withContext(Dispatchers.IO) { AppBuilder.triggerTermuxBuildFromUi(ctx, slug) }
                            statusBanner = msg
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                    // Copy 1-Click Termux Self-Build Command
                    Pill("📋 Copy Termux Cmd", accent = NisuUi.Violet) {
                        scope.launch {
                            val slug = snap.activeProject.ifBlank { AppBuilder.resolveSlug(ctx, "") }.ifBlank { "myapp" }
                            withContext(Dispatchers.IO) { AppBuilder.exportZip(ctx, slug) }
                            val cmd = AppBuilder.termuxSelfBuildCommand(slug)
                            clip.setText(AnnotatedString(cmd))
                            statusBanner = "Termux self-build command copied! Paste in Termux to build APK."
                            Toast.makeText(ctx, statusBanner, Toast.LENGTH_LONG).show()
                        }
                    }
                    // Install Built APK
                    Pill("📲 Install APK", accent = NisuUi.Cyan) {
                        scope.launch {
                            val slug = snap.activeProject.ifBlank { AppBuilder.resolveSlug(ctx, "") }
                            val r = withContext(Dispatchers.IO) { AppBuilder.install(ctx, slug) }
                            val msg = if (r.optBoolean("ok")) "Opening APK installer: ${r.optString("apk")}" else r.optString("error", "APK not built yet — tap 'Build APK in Termux' first.")
                            statusBanner = msg
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                }

                if (!isWebsite && !isApp) {
                    Pill("📦 Save Code ZIP", accent = NisuUi.Amber) {
                        scope.launch {
                            val f = withContext(Dispatchers.IO) {
                                exportCurrentSnapFilesAsZip(ctx, snap.activeProject.ifBlank { "code-files" }, snap.files)
                            }
                            statusBanner = if (f != null) "Saved ZIP: ${f.absolutePath}" else "Could not save ZIP."
                            Toast.makeText(ctx, statusBanner, Toast.LENGTH_LONG).show()
                        }
                    }
                }

                Pill("Clear") { LiveCode.clear(); sel = ""; statusBanner = "" }
            }
        }

        // Main Body according to viewMode
        when (viewMode) {
            "projects" -> ProjectsBrowserPanel(
                onLoaded = { msg ->
                    statusBanner = msg
                    viewMode = "code"
                },
                onRunWebsite = { slug ->
                    LiveCode.loadWebsiteProject(ctx, slug)
                    viewMode = "preview"
                }
            )
            "builder" -> QuickBuilderPanel(
                onStarted = { msg ->
                    statusBanner = msg
                    viewMode = "code"
                }
            )
            "preview" -> InAppWebsiteRunner(
                snap = snap,
                runnerUrl = runnerUrl,
                runnerSlug = runnerSlug,
                onBackToCode = { viewMode = "code" }
            )
            else -> {
                // File Tabs Bar
                if (snap.files.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp)) {
                        snap.files.forEach { f ->
                            val on = f.path == file?.path
                            val isLive = f.kind == "live" && snap.busy
                            val shape = RoundedCornerShape(10.dp)
                            Box(
                                Modifier.padding(end = 6.dp)
                                    .clip(shape)
                                    .background(if (on) NisuUi.Cyan.copy(alpha = 0.20f) else NisuUi.Card)
                                    .border(1.dp, if (isLive) NisuUi.Amber else if (on) NisuUi.Cyan else NisuUi.Line, shape)
                                    .clickable(onClickLabel = f.path) { sel = f.path }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                val shortName = f.path.substringAfterLast('/')
                                val badge = if (isLive) " ●" else if (f.rev > 1) " v${f.rev}" else ""
                                Text(
                                    shortName + badge,
                                    fontSize = 12.sp,
                                    color = if (isLive) NisuUi.Amber else if (on) NisuUi.Cyan else NisuUi.Muted,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                if (file == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "No code loaded right now.\nTap '+ Build' to create a Website or Android APK with live streaming code,\nor tap 'Projects' to load your saved websites and apps.",
                                color = NisuUi.Muted, fontSize = 13.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Pill("+ Build Website / APK", accent = NisuUi.Green) { viewMode = "builder" }
                                Pill("Open Saved Projects", accent = NisuUi.Cyan) { viewMode = "projects" }
                            }
                        }
                    }
                } else {
                    val lines = remember(file.path, file.rev, file.content.length) { file.content.lines() }
                    val typing = follow == file.path + "#" + file.rev
                    val visible = if (typing) minOf(shown, lines.size) else lines.size
                    val list = rememberLazyListState()
                    val streaming = snap.busy && file.kind == "live"
                    LaunchedEffect(visible, typing, lines.size, streaming) {
                        if ((typing || streaming) && visible > 0) {
                            list.scrollToItem((visible - 1).coerceAtLeast(0))
                        }
                    }
                    val diff = file.kind == "fix"
                    Column(
                        Modifier.fillMaxWidth().weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF040B1B))
                            .border(1.dp, if (streaming) NisuUi.Amber.copy(alpha = 0.7f) else NisuUi.Line, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            Modifier.fillMaxWidth().background(NisuUi.Card).padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                (if (streaming) "⚡ WRITING LIVE: " else "") + file.path,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (streaming) NisuUi.Amber else NisuUi.Cyan,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                "${lines.size} lines • ${file.content.length} chars",
                                fontSize = 11.sp,
                                color = NisuUi.Muted
                            )
                        }
                        Box(Modifier.weight(1f).fillMaxWidth().horizontalScroll(rememberScrollState())) {
                            LazyColumn(state = list, modifier = Modifier.fillMaxSize().padding(vertical = 6.dp)) {
                                itemsIndexed(lines.take(visible)) { i, ln ->
                                    Row(Modifier.padding(horizontal = 8.dp)) {
                                        Text(
                                            (i + 1).toString().padStart(4),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = NisuUi.Dim,
                                            softWrap = false
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Text(
                                            highlightLine(ln, diff),
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = NisuUi.Text,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

/**
 * Built-in Live Website Runner (WebView) inside NISU AI!
 * Whenever Chrome does not open or the user wants to test/run the website directly inside the app,
 * this runs the website with full JavaScript, DOM storage, LocalWeb HTTP server, AND standalone inlined HTML fallback!
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InAppWebsiteRunner(
    snap: LiveSnap,
    runnerUrl: String,
    runnerSlug: String,
    onBackToCode: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var useStandaloneMode by remember { mutableStateOf(false) }

    // Determine URL or standalone HTML
    val activeSlug = snap.activeProject.takeIf { it.isNotBlank() && WebBuilder.dirOf(ctx, it).isDirectory }
        ?: runnerSlug.takeIf { it.isNotBlank() && WebBuilder.dirOf(ctx, it).isDirectory }
        ?: WebBuilder.sites(ctx).firstOrNull()?.name.orEmpty()

    val serverUrl = remember(activeSlug, snap.websiteUrl, runnerUrl) {
        when {
            activeSlug.isNotEmpty() -> LocalWeb.url(ctx, activeSlug)
            snap.websiteUrl.isNotBlank() -> snap.websiteUrl
            runnerUrl.isNotBlank() -> runnerUrl
            else -> ""
        }
    }

    val standaloneHtml = remember(snap.files, activeSlug) {
        val map = LinkedHashMap<String, String>()
        if (activeSlug.isNotEmpty()) {
            map.putAll(WebBuilder.readAllFiles(ctx, activeSlug))
        }
        snap.files.forEach { f -> map[f.path] = f.content }
        WebRules.buildStandaloneHtml(map)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .background(NisuUi.Card)
                .border(1.dp, NisuUi.Line, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(NisuUi.Green))
            Text(
                if (useStandaloneMode || serverUrl.isEmpty()) "In-App Runner (Standalone HTML)" else serverUrl,
                fontSize = 11.sp, color = NisuUi.Cyan, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Pill(if (useStandaloneMode) "Server Mode" else "Standalone Mode") {
                useStandaloneMode = !useStandaloneMode
            }
            Pill("↻ Reload") {
                webViewRef?.let { wv ->
                    if (useStandaloneMode || serverUrl.isEmpty()) {
                        wv.loadDataWithBaseURL("http://127.0.0.1/", standaloneHtml, "text/html", "UTF-8", null)
                    } else {
                        wv.loadUrl(serverUrl)
                    }
                }
            }
            Pill("Chrome") {
                scope.launch {
                    if (activeSlug.isNotEmpty()) {
                        val r = withContext(Dispatchers.IO) { WebBuilder.openWebsiteSmart(ctx, activeSlug) }
                        if (!r.optBoolean("ok", false)) {
                            Toast.makeText(ctx, "Chrome could not open — running right here in-app!", Toast.LENGTH_SHORT).show()
                        }
                    } else if (serverUrl.isNotEmpty()) {
                        PhoneControl.openUrl(ctx, serverUrl, "")
                    }
                }
            }
            Pill("← Code") { onBackToCode() }
        }

        Box(
            Modifier.fillMaxWidth().weight(1f)
                .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                .border(1.dp, NisuUi.Line, RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                .background(Color.White)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = true
                        settings.allowContentAccess = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        webViewClient = object : WebViewClient() {
                            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                                // Automatically fall back to standalone inlined HTML if local server url ever fails
                                if (!useStandaloneMode && standaloneHtml.isNotBlank()) {
                                    view?.loadDataWithBaseURL("http://127.0.0.1/", standaloneHtml, "text/html", "UTF-8", null)
                                }
                            }
                        }
                        webChromeClient = WebChromeClient()
                        webViewRef = this
                        if (!useStandaloneMode && serverUrl.isNotEmpty()) {
                            loadUrl(serverUrl)
                        } else if (standaloneHtml.isNotBlank()) {
                            loadDataWithBaseURL("http://127.0.0.1/", standaloneHtml, "text/html", "UTF-8", null)
                        }
                    }
                },
                update = { wv ->
                    webViewRef = wv
                }
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

/**
 * Panel to start building a new Website or Android APK directly from the Live Code Studio,
 * watching every line stream in real time.
 */
@Composable
private fun QuickBuilderPanel(onStarted: (String) -> Unit) {
    val ctx = LocalContext.current
    var kind by remember { mutableStateOf("ai_apk") } // "ai_apk" | "ai_website" | "website" | "app"
    var tpl by remember { mutableStateOf("webview") }  // "webview" | "native"
    var voice by remember { mutableStateOf("Aoede") }
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var existingProject by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize()
            .clip(RoundedCornerShape(14.dp))
            .background(NisuUi.Card)
            .border(1.dp, NisuUi.Line, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Create or Update AI APK / Website AI / App", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = NisuUi.Cyan)
        Text(
            "Build a 100% All-Unlocked AI APK or Website AI (with Gemini Live Voice & Vision, API Key + Get Key button, Screen Reader, Open/Close App Phone Control & Self-Coding), or any custom Website / APK!",
            fontSize = 11.sp, color = NisuUi.Muted
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Pill("🤖 Build AI APK (All Unlocked)", active = kind == "ai_apk", accent = NisuUi.Green) { kind = "ai_apk" }
            Pill("🌐 Build Website AI", active = kind == "ai_website", accent = NisuUi.Cyan) { kind = "ai_website" }
            Pill("✨ Update / Fix AI Project", active = kind == "update_ai", accent = NisuUi.Amber) { kind = "update_ai" }
            Pill("🌐 Standard Website", active = kind == "website", accent = NisuUi.Cyan) { kind = "website" }
            Pill("📱 Standard APK", active = kind == "app", accent = NisuUi.Green) { kind = "app" }
        }
        if (kind == "app") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("APK Type:", fontSize = 12.sp, color = NisuUi.Muted)
                Pill("WebView App (HTML/CSS/JS)", active = tpl == "webview") { tpl = "webview" }
                Pill("Native Kotlin App", active = tpl == "native") { tpl = "native" }
            }
        }
        if (kind == "ai_apk" || kind == "ai_website") {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Gemini Live Voice:", fontSize = 11.sp, color = NisuUi.Muted)
                listOf("Aoede", "Leda", "Charon", "Fenrir", "Kore").forEach { v ->
                    Pill(v, active = voice == v, accent = NisuUi.Violet) { voice = v }
                }
            }
        }
        if (kind == "update_ai") {
            OutlinedTextField(
                value = existingProject,
                onValueChange = { existingProject = it.take(36) },
                label = { Text("Project Name to Update/Fix (leave blank for latest project)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NisuUi.Amber, unfocusedBorderColor = NisuUi.Line,
                    focusedTextColor = NisuUi.Text, unfocusedTextColor = NisuUi.Text
                )
            )
        } else {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(36) },
                label = {
                    Text(
                        when (kind) {
                            "ai_apk" -> "AI APK Name (e.g. JarvisAI, MyNisuAI, SuperBot)"
                            "ai_website" -> "Website AI Name (e.g. OmniWebAI, NisuWebStudio)"
                            "website" -> "Website Name (e.g. Portfolio, CoffeeShop)"
                            else -> "App Name (e.g. Calculator, ProNotes)"
                        }
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NisuUi.Cyan, unfocusedBorderColor = NisuUi.Line,
                    focusedTextColor = NisuUi.Text, unfocusedTextColor = NisuUi.Text
                )
            )
        }
        OutlinedTextField(
            value = desc,
            onValueChange = { desc = it },
            label = {
                Text(
                    if (kind == "update_ai") "Describe what features to add, change, or what error/bug to fix..."
                    else "Describe AI personality, features, phone controls, theme, colors & language..."
                )
            },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NisuUi.Cyan, unfocusedBorderColor = NisuUi.Line,
                focusedTextColor = NisuUi.Text, unfocusedTextColor = NisuUi.Text
            )
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val canStart = desc.trim().length >= 5
            Box(
                Modifier.clip(RoundedCornerShape(50))
                    .background(if (canStart) Brush.horizontalGradient(listOf(NisuUi.Cyan, NisuUi.Blue)) else Brush.horizontalGradient(listOf(NisuUi.Dim, NisuUi.Dim)))
                    .clickable(enabled = canStart) {
                        val r = when (kind) {
                            "ai_apk" -> {
                                val args = JSONObject()
                                    .put("name", name.trim().ifBlank { "CustomAI" })
                                    .put("description", desc.trim())
                                    .put("voice", voice)
                                    .put("build", true)
                                    .put("user_confirmed", true)
                                AiAgentBuilder.run(ctx, "build_ai_apk", args)
                            }
                            "ai_website" -> {
                                val args = JSONObject()
                                    .put("name", name.trim().ifBlank { "WebAI" })
                                    .put("description", desc.trim())
                                    .put("voice", voice)
                                    .put("user_confirmed", true)
                                AiAgentBuilder.run(ctx, "build_ai_website", args)
                            }
                            "update_ai" -> {
                                val args = JSONObject()
                                    .put("project", existingProject.trim())
                                    .put("update_request", desc.trim())
                                AiAgentBuilder.run(ctx, "update_ai_project", args)
                            }
                            "website" -> {
                                val args = JSONObject()
                                    .put("name", name.trim().ifBlank { "MyWebsite" })
                                    .put("description", desc.trim())
                                    .put("user_confirmed", true)
                                WebBuilder.run(ctx, "build_website", args)
                            }
                            else -> {
                                val args = JSONObject()
                                    .put("name", name.trim().ifBlank { "MyApp" })
                                    .put("description", desc.trim())
                                    .put("template", tpl)
                                    .put("build", true)
                                    .put("user_confirmed", true)
                                AppBuilder.run(ctx, "build_app", args)
                            }
                        }
                        val err = r.optString("error")
                        if (err.isNotBlank()) {
                            Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                        } else {
                            onStarted("Started building/updating — watch the live code stream below!")
                        }
                    }
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(
                    when (kind) {
                        "ai_apk" -> "🚀 Build All-Unlocked AI APK"
                        "ai_website" -> "🚀 Build Live Website AI"
                        "update_ai" -> "✨ Apply AI Update / Auto-Fix"
                        "website" -> "🚀 Start Live Website Build"
                        else -> "🚀 Generate APK Code + Build"
                    },
                    fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White
                )
            }
        }
    }
}

/**
 * Panel listing all saved Websites and Android APK projects on the phone so the user can load their code into Live Code Viewer,
 * run websites in-app or in Chrome, export ZIP archives, or trigger Termux self-builds at any time.
 */
@Composable
private fun ProjectsBrowserPanel(
    onLoaded: (String) -> Unit,
    onRunWebsite: (String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var websites by remember { mutableStateOf(WebBuilder.sites(ctx)) }
    var apps by remember { mutableStateOf(AppBuilder.localProjects(ctx)) }

    Column(
        Modifier.fillMaxSize()
            .clip(RoundedCornerShape(14.dp))
            .background(NisuUi.Card)
            .border(1.dp, NisuUi.Line, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Saved Websites (${websites.size})", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = NisuUi.Cyan)
        if (websites.isEmpty()) {
            Text("No websites built yet.", fontSize = 12.sp, color = NisuUi.Muted)
        } else {
            websites.take(10).forEach { dir ->
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NisuUi.CardHi.copy(alpha = 0.6f))
                        .border(1.dp, NisuUi.Line, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(dir.name, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = NisuUi.Text)
                        Text("${dir.walkTopDown().count { it.isFile }} files", fontSize = 11.sp, color = NisuUi.Muted)
                    }
                    Pill("View Code") {
                        LiveCode.loadWebsiteProject(ctx, dir.name)
                        onLoaded("Loaded website '${dir.name}'")
                    }
                    Pill("▶ Run", accent = NisuUi.Green) {
                        onRunWebsite(dir.name)
                    }
                    Pill("ZIP", accent = NisuUi.Amber) {
                        scope.launch {
                            val z = withContext(Dispatchers.IO) { WebBuilder.exportZip(ctx, dir.name) }
                            Toast.makeText(ctx, if (z != null) "Saved: ${z.absolutePath}" else "ZIP failed", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Text("Saved Android APK Projects (${apps.size})", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = NisuUi.Green)
        if (apps.isEmpty()) {
            Text("No APK projects generated yet.", fontSize = 12.sp, color = NisuUi.Muted)
        } else {
            apps.take(10).forEach { dir ->
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NisuUi.CardHi.copy(alpha = 0.6f))
                        .border(1.dp, NisuUi.Line, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(dir.name, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = NisuUi.Text)
                        Text("${dir.walkTopDown().count { it.isFile }} files • Self-building Termux project", fontSize = 11.sp, color = NisuUi.Muted)
                    }
                    Pill("View Code") {
                        LiveCode.loadAppProject(ctx, dir.name)
                        onLoaded("Loaded APK project '${dir.name}'")
                    }
                    Pill("⚡ Build APK", accent = NisuUi.Green) {
                        scope.launch {
                            val (_, msg) = withContext(Dispatchers.IO) { AppBuilder.triggerTermuxBuildFromUi(ctx, dir.name) }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                    Pill("ZIP", accent = NisuUi.Amber) {
                        scope.launch {
                            val z = withContext(Dispatchers.IO) { AppBuilder.exportZip(ctx, dir.name) }
                            Toast.makeText(ctx, if (z != null) "Saved: ${z.absolutePath}" else "ZIP failed", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }
}

/** Exports any currently displayed files in `LiveCode` to `/sdcard/Download/NISU-Code-<name>.zip`. */
private fun exportCurrentSnapFilesAsZip(ctx: android.content.Context, name: String, files: List<CodeFile>): java.io.File? {
    if (files.isEmpty()) return null
    val slug = WebRules.slugOf(name)
    val dlDir = try {
        val d = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        if (d != null && (d.exists() || d.mkdirs()) && d.canWrite()) d else java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "exports").apply { mkdirs() }
    } catch (_: Exception) {
        java.io.File(ctx.filesDir, "exports").apply { mkdirs() }
    }
    val zipFile = java.io.File(dlDir, "NISU-Code-$slug.zip")
    java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(zipFile))).use { zos ->
        for (f in files) {
            val clean = f.path.trimStart('/').replace("..", "_")
            zos.putNextEntry(java.util.zip.ZipEntry("$slug/$clean"))
            zos.write(f.content.toByteArray(Charsets.UTF_8))
            zos.closeEntry()
        }
    }
    LiveCode.setLastZip(zipFile.absolutePath)
    return zipFile
}

@Composable
private fun Pill(label: String, active: Boolean = false, accent: Color = NisuUi.Cyan, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (active) accent.copy(alpha = 0.22f) else NisuUi.Card)
            .border(1.dp, if (active) accent else accent.copy(alpha = 0.45f), shape)
            .clickable(onClickLabel = label) { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, color = if (active) accent else NisuUi.Text, maxLines = 1)
    }
}
