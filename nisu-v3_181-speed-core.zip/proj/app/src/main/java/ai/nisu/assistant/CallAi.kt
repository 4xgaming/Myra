package ai.nisu.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

/**
 * Pure rules of [CallAi] (no Android classes, unit tested on the JVM).
 */
object CallAiRules {
    val VOIP_PKGS = setOf(
        "com.whatsapp", "com.whatsapp.w4b",
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram", "org.telegram.plus",
        "com.imo.android.imoim", "com.imo.android.imoimbeta",
        "com.instagram.android",
        "com.facebook.orca", "com.facebook.mlite"
    )
    val ANSWER_WORDS = listOf(
        "answer", "accept", "pick up", "receive", "join",
        "উত্তর", "রিসিভ", "গ্রহণ", "জবাব", "ধরুন", "ধরো",
        "उत्तर", "रिसीव", "स्वीकार", "उठाएं"
    )
    val DECLINE_WORDS = listOf(
        "decline", "reject", "dismiss", "hang", "end call", "end", "ignore", "leave", "drop",
        "বাতিল", "কেটে", "প্রত্যাখ্যান", "খারিজ", "বন্ধ",
        "अस्वीकार", "काट", "समाप्त"
    )
    val VIDEO_WORDS = listOf("video", "ভিডিও", "वीडियो")
    val ONGOING_CALL_HINTS = listOf(
        "ongoing", "in call", "voice call", "audio call", "connected", "tap to return",
        "চলমান", "কথা চলছে", "কল চলছে"
    )

    fun isAnswerLabel(label: String): Boolean {
        val t = label.lowercase().trim()
        if (t.isEmpty()) return false
        return ANSWER_WORDS.any { it in t } && DECLINE_WORDS.none { it in t }
    }

    fun isDeclineLabel(label: String): Boolean {
        val t = label.lowercase().trim()
        if (t.isEmpty()) return false
        return DECLINE_WORDS.any { it in t } && ANSWER_WORDS.none { it in t }
    }

    fun isVideoCallText(title: String, text: String): Boolean {
        val all = (title + " " + text).lowercase()
        return VIDEO_WORDS.any { it in all }
    }

    fun appLabelFor(cell: Boolean, packageName: String?): String = if (cell) "phone call" else when (packageName) {
        "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
        "com.facebook.orca", "com.facebook.mlite" -> "Messenger"
        "com.instagram.android" -> "Instagram"
        "com.imo.android.imoim", "com.imo.android.imoimbeta" -> "IMO"
        else -> if (packageName?.contains("telegram") == true || packageName?.contains("challegram") == true) "Telegram" else (packageName ?: "app")
    }
}

/**
 * v3.165 / v3.171: CALL AI. NISU AI answers an incoming AUDIO call by itself (normal phone call, WhatsApp, Telegram, IMO, Instagram, Messenger),
 * talks with the caller in the caller's language, and the owner can take the call over and hand it back at any moment.
 *
 * How it hears and speaks (Android gives no app the call audio itself):
 *  - the call is put on the loudspeaker; the caller's voice comes out of the speaker and is picked up by NISU AI's microphone;
 *  - NISU AI's voice is played on the same speaker, and the call app's microphone picks it up and sends it to the caller.
 *  - half duplex: while NISU AI speaks, the microphone audio is blanked (the phone would otherwise hear itself). The caller waits for the end of the sentence.
 *  - if Android silences the microphone for the call (digital silence), this is detected after about 2.5 s, NISU AI says nothing false, and the owner is alerted to take the call.
 *
 * Switch ON by default (Preferences > Call AI). Never answers video calls.
 */
object CallAi {
    const val K_ON = "call_ai_on"
    const val K_DELAY = "call_ai_delay_s"        // seconds to wait before answering (default 3)
    const val K_VOIP = "call_ai_voip"            // also answer WhatsApp / Telegram / IMO / Instagram / Messenger audio calls (default ON)
    const val K_CELL = "call_ai_cell"            // also answer normal phone calls (default ON)

    const val A_TAKE = "ai.nisu.assistant.CALL_TAKEOVER"
    const val A_GIVE = "ai.nisu.assistant.CALL_GIVE"
    const val A_END = "ai.nisu.assistant.CALL_END"

    private const val CH = "nisu_call_ai"
    private const val NID = 7101
    private const val NID_LOG = 7102
    private const val MAX_CALL_MS = 15 * 60_000L
    private const val QUIET_END_MS = 75_000L     // nobody speaks for this long = the caller is gone

    enum class Phase { IDLE, RINGING, AI, OWNER }
    @Volatile var phase: Phase = Phase.IDLE
        private set

    val VOIP_PKGS = CallAiRules.VOIP_PKGS
    private val ANSWER_WORDS = CallAiRules.ANSWER_WORDS
    private val DECLINE_WORDS = CallAiRules.DECLINE_WORDS
    private val VIDEO_WORDS = CallAiRules.VIDEO_WORDS

    private val main = Handler(Looper.getMainLooper())

    // ---- state of the call that is running (all changes happen under lock or on the main thread) ----
    @Volatile private var gen = 0
    private var cellular = false
    private var pkg: String? = null
    private var who: String = ""
    private var appLabel: String = ""
    private var answeredByUs = false
    private var token = ""
    private var startedAt = 0L
    private var live: GeminiLive? = null
    private var resume: String? = null
    private var readyOnce = false
    private var greeted = false
    private var retry = 0
    private var compat = 0
    private var prevNoInterrupt = false
    private val transcript = ArrayList<String>()
    private val inBuf = StringBuilder()
    private val outBuf = StringBuilder()
    @Volatile private var lastVoiceAt = 0L
    @Volatile private var speakingUntil = 0L        // SystemClock.uptimeMillis() when NISU AI's queued speech ends

    // ---- audio ----
    @Volatile private var micRun = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var trackMode: Int = AudioAttributes.USAGE_MEDIA
    private var playQ: LinkedBlockingQueue<ByteArray>? = null
    @Volatile private var playRun = false
    private var savedSpeaker: Boolean? = null
    private var savedVoiceVol: Int = -1
    private var savedMediaVol: Int = -1
    private var focusReq: AudioFocusRequest? = null

    /** True while Call AI is actively handling a call (ringing or AI talking), so AssistantService yields its own microphone cleanly. */
    fun active(): Boolean = phase == Phase.RINGING || phase == Phase.AI

    // =====================================================================================================
    // settings
    // =====================================================================================================
    /** v3.171: Default ON so Call AI works out of the box unless the owner switches it off in Preferences. */
    fun enabled(c: Context) = !Maintenance.CALL_AI && Prefs.getBool(c, K_ON, true)   // v3.174: under maintenance = never answers
    private fun delayMs(c: Context) = (Prefs.getInt(c, K_DELAY, 3).coerceIn(0, 20)) * 1000L

    private fun log(m: String) { try { AppState.add("Call AI: $m") } catch (_: Throwable) {} }

    // =====================================================================================================
    // entry 1: normal phone calls (CallAiReceiver gets PHONE_STATE)
    // =====================================================================================================
    fun onPhoneState(app: Context, state: String?, number: String?) {
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (phase == Phase.RINGING && cellular && who.isBlank() && !number.isNullOrBlank()) {
                    who = nameForNumber(app, number) ?: number
                    postNotification(app)
                    return
                }
                if (!enabled(app) || !Prefs.getBool(app, K_CELL, true) || phase != Phase.IDLE) return
                begin(app, cell = true, packageName = null, name = nameForNumber(app, number) ?: number?.takeIf { it.isNotBlank() } ?: "")
                val g = gen
                main.postDelayed({ if (g == gen && phase == Phase.RINGING && cellular) answerNow(app, null) }, delayMs(app))
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (!cellular) {
                    // Fallback: if CallAiReceiver missed EXTRA_STATE_RINGING (e.g. cold process start or rapid answer), do not crash
                    return
                }
                if (phase == Phase.RINGING && !answeredByUs) {
                    // Wait 600ms in case answerNow is right in the middle of completing on a worker thread
                    val g = gen
                    main.postDelayed({
                        if (g != gen || !cellular) return@postDelayed
                        if (phase == Phase.RINGING && !answeredByUs) { log("the owner picked up the call himself"); finish(app, false) }
                        else if (phase == Phase.RINGING && answeredByUs) startSession(app, null)
                    }, 600L)
                } else if (phase == Phase.RINGING && answeredByUs) {
                    startSession(app, null)
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE -> { if (cellular && phase != Phase.IDLE) finish(app, true) }
        }
    }

    // =====================================================================================================
    // entry 2: WhatsApp / Telegram / IMO / Instagram / Messenger calls (NisuNotificationService)
    // =====================================================================================================
    fun onNotification(app: Context, sbn: StatusBarNotification) {
        val p = sbn.packageName ?: return
        if (p !in VOIP_PKGS || !enabled(app) || !Prefs.getBool(app, K_VOIP, true)) return
        val n = sbn.notification ?: return
        val e = n.extras
        val title = (e?.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: e?.getCharSequence(Notification.EXTRA_TITLE))?.toString()?.trim().orEmpty()
        val text = (e?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e?.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        val isCallCat = n.category == Notification.CATEGORY_CALL || n.fullScreenIntent != null
        val ans = n.actions?.firstOrNull { a -> CallAiRules.isAnswerLabel(a.title?.toString().orEmpty()) }
        val dec = n.actions?.firstOrNull { a -> CallAiRules.isDeclineLabel(a.title?.toString().orEmpty()) }
        if (!isCallCat && ans == null) return

        if (phase == Phase.IDLE && (ans != null || (isCallCat && dec != null && CallAiRules.ONGOING_CALL_HINTS.none { it in text.lowercase() }))) {
            if (CallAiRules.isVideoCallText(title, text)) { log("video call from $p ignored (audio calls only)"); return }
            begin(app, cell = false, packageName = p, name = title)
            val g = gen
            val key = sbn.key
            main.postDelayed({ if (g == gen && phase == Phase.RINGING && !cellular) answerNow(app, key) }, delayMs(app))
        } else if (phase != Phase.IDLE && !cellular && p == pkg && ans == null) {
            // an "in call" notification of the same app (hang-up button only): the call is connected
            if (phase == Phase.RINGING && answeredByUs) startSession(app, null)
        }
    }

    fun onNotificationRemoved(app: Context, sbn: StatusBarNotification) {
        if (phase == Phase.IDLE || cellular || sbn.packageName != pkg) return
        val g = gen
        main.postDelayed({
            if (g != gen || phase == Phase.IDLE) return@postDelayed
            val alive = try {
                NisuNotificationService.inst?.activeNotifications?.any {
                    it.packageName == pkg && (it.notification.category == Notification.CATEGORY_CALL || it.notification.fullScreenIntent != null ||
                        it.notification.actions?.any { a -> CallAiRules.isDeclineLabel(a.title?.toString().orEmpty()) } == true)
                }
            } catch (_: Exception) { null }
            if (alive == false) finish(app, true)
        }, 2200L)
    }

    // =====================================================================================================
    // call start / answer / finish
    // =====================================================================================================
    private fun begin(app: Context, cell: Boolean, packageName: String?, name: String) {
        gen++
        cellular = cell; pkg = packageName; who = name
        appLabel = CallAiRules.appLabelFor(cell, packageName)
        answeredByUs = false; readyOnce = false; greeted = false; retry = 0; compat = 0; resume = null
        token = java.util.UUID.randomUUID().toString()
        startedAt = System.currentTimeMillis()
        synchronized(transcript) { transcript.clear(); inBuf.setLength(0); outBuf.setLength(0) }
        phase = Phase.RINGING
        // Ensure AssistantService yields its microphone immediately so the call app and CallAi have no contention
        try { AssistantService.notifyCallAiChanged() } catch (_: Throwable) {}
        log("incoming $appLabel call ${if (who.isNotBlank()) "from $who" else ""}; answering in ${delayMs(app) / 1000}s")
        postNotification(app)
    }

    private fun answerNow(app: Context, sbnKey: String?) {
        val g = gen
        answeredByUs = true   // set before answering so an immediate EXTRA_STATE_OFFHOOK knows we answered it
        thread(name = "call-ai-answer", isDaemon = true) {
            val ok = if (cellular) answerCellular(app) else answerVoip(app, sbnKey)
            main.post {
                if (g != gen || phase == Phase.IDLE) return@post
                if (!ok && phase == Phase.RINGING) {
                    answeredByUs = false
                    log("could not answer the call (no way to press Answer)")
                    alertOwner(app, "NISU AI could not answer the $appLabel call", "Android refused the answer. Turn on 'Answer phone calls' permission and the Accessibility service.")
                    finish(app, false)
                    return@post
                }
                // If OFFHOOK or "in call" notification already started the session, phase is already AI; otherwise start after 1.8 s
                main.postDelayed({ if (g == gen && phase == Phase.RINGING && answeredByUs) startSession(app, null) }, 1800L)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun answerCellular(app: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && app.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
            try { app.getSystemService(TelecomManager::class.java)?.acceptRingingCall(); return true } catch (_: Throwable) {}
        }
        // Fallback 1: click Answer button on the incoming call notification if one is posted
        val sbn = try {
            NisuNotificationService.inst?.activeNotifications?.firstOrNull {
                it.notification.category == Notification.CATEGORY_CALL &&
                    it.notification.actions?.any { a -> CallAiRules.isAnswerLabel(a.title?.toString().orEmpty()) } == true
            }
        } catch (_: Exception) { null }
        val act = sbn?.notification?.actions?.firstOrNull { a -> CallAiRules.isAnswerLabel(a.title?.toString().orEmpty()) }
        if (act != null) {
            try { act.actionIntent.send(); return true } catch (_: Exception) {}
        }
        // Fallback 2: Accessibility click or swipe on the incoming call screen
        if (clickAnswerWithAccessibility()) return true
        // Fallback 3: Root keyevent 5 (KEYCODE_CALL) or headset hook (KEYCODE_HEADSETHOOK = 79)
        if (Root.available()) {
            val (code, _) = Root.exec("input keyevent 5", 3000)
            if (code == 0) return true
        }
        return false
    }

    private fun answerVoip(app: Context, key: String?): Boolean {
        val active = try { NisuNotificationService.inst?.activeNotifications?.toList() } catch (_: Exception) { null }.orEmpty()
        val sbn = active.firstOrNull { key != null && it.key == key }
            ?: active.firstOrNull { it.packageName == pkg && (it.notification.category == Notification.CATEGORY_CALL || it.notification.fullScreenIntent != null) }
            ?: active.firstOrNull { it.packageName == pkg }
        val a = sbn?.notification?.actions?.firstOrNull { x -> CallAiRules.isAnswerLabel(x.title?.toString().orEmpty()) }
        if (a != null) {
            try { a.actionIntent.send(); return true } catch (_: Exception) {}
        }
        // If no direct Answer action (or PendingIntent failed), open the fullScreenIntent / contentIntent so the call screen is visible for Accessibility
        try { (sbn?.notification?.fullScreenIntent ?: sbn?.notification?.contentIntent)?.send() } catch (_: Exception) {}
        try { Thread.sleep(500) } catch (_: InterruptedException) {}
        return clickAnswerWithAccessibility()
    }

    private fun clickAnswerWithAccessibility(): Boolean {
        val acc = NisuAccessibilityService.inst ?: return false
        val labels = listOf(
            "Answer", "Accept", "Receive", "Pick up", "Join", "Audio", "Voice",
            "উত্তর দিন", "উত্তর", "রিসিভ", "গ্রহণ করুন", "গ্রহণ", "কল ধরুন",
            "उत्तर दें", "स्वीकार करें", "रिसीव"
        )
        for (attempt in 0 until 3) {
            if (acc.clickExact(labels) != null) return true
            for (w in labels) {
                if (acc.clickText(w, 250)) return true
            }
            // Some dialers / WhatsApp call screens use an upward or rightward swipe on the green answer button at the bottom
            if (attempt == 1) {
                val (w, h) = acc.screenPx()
                // Try swiping up from bottom-center / bottom-right where green answer buttons sit on WhatsApp & Google Dialer
                acc.swipe(w * 0.5f, h * 0.82f, w * 0.5f, h * 0.45f, 260)
            }
            try { Thread.sleep(300) } catch (_: InterruptedException) { break }
        }
        return false
    }

    /** Hangs up (owner pressed End, or the call is over by our rules). */
    fun endCall(app: Context) {
        if (phase == Phase.IDLE) return
        val wasCell = cellular
        val targetPkg = pkg
        finish(app, true)
        thread(name = "call-ai-hangup", isDaemon = true) {
            var done = false
            if (wasCell) {
                if (Build.VERSION.SDK_INT >= 28 && app.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                    try { done = app.getSystemService(TelecomManager::class.java)?.endCall() == true } catch (_: Throwable) {}
                }
            } else {
                val sbn = try {
                    NisuNotificationService.inst?.activeNotifications?.firstOrNull {
                        it.packageName == targetPkg && (it.notification.category == Notification.CATEGORY_CALL ||
                            it.notification.actions?.any { a -> CallAiRules.isDeclineLabel(a.title?.toString().orEmpty()) } == true)
                    }
                } catch (_: Exception) { null }
                val a = sbn?.notification?.actions?.firstOrNull { x -> CallAiRules.isDeclineLabel(x.title?.toString().orEmpty()) }
                if (a != null) try { a.actionIntent.send(); done = true } catch (_: Exception) {}
            }
            if (!done) {
                val acc = NisuAccessibilityService.inst
                if (acc != null) {
                    for (w in listOf("End call", "Hang up", "Decline", "End", "Leave", "কল শেষ", "কেটে দিন", "বাতিল")) {
                        if (acc.clickText(w, 300)) { done = true; break }
                    }
                }
            }
            if (!done && wasCell && Root.available()) {
                Root.exec("input keyevent 6", 3000) // KEYCODE_ENDCALL
            }
        }
    }

    private fun finish(app: Context, sendSummary: Boolean) {
        if (phase == Phase.IDLE) return
        val wasAi = phase == Phase.AI || phase == Phase.OWNER
        gen++
        stopSession()
        restoreAudio(app)
        flushLines()
        val lines = synchronized(transcript) { transcript.toList() }
        val who0 = who; val label = appLabel
        phase = Phase.IDLE
        main.removeCallbacksAndMessages(null)
        try { (app.getSystemService(NotificationManager::class.java)).cancel(NID) } catch (_: Exception) {}
        try { AssistantService.notifyCallAiChanged() } catch (_: Throwable) {}
        if (sendSummary && wasAi && lines.isNotEmpty()) {
            val body = lines.joinToString("\n").takeLast(900)
            AutoReplyLog.add("call", "$label ${who0}: " + body.replace('\n', ' ').take(300))
            postLog(app, "Call from ${who0.ifBlank { "unknown" }} ($label) ended", body)
        }
        log("call ended")
    }

    // =====================================================================================================
    // hand-over (notification buttons)
    // =====================================================================================================
    fun takeOver(app: Context) {
        if (phase != Phase.AI) return
        gen++                       // the old session's callbacks stop counting
        stopSession()               // releases the microphone and the speaker for the call app / the owner
        flushLines()
        phase = Phase.OWNER
        @Suppress("DEPRECATION")
        try { app.getSystemService(AudioManager::class.java)?.isSpeakerphoneOn = false } catch (_: Throwable) {}   // ear speaker: he can hold the phone to his ear
        if (Build.VERSION.SDK_INT >= 31) try { app.getSystemService(AudioManager::class.java)?.clearCommunicationDevice() } catch (_: Throwable) {}
        try { AssistantService.notifyCallAiChanged() } catch (_: Throwable) {}
        log("owner took over the call")
        postNotification(app)
    }

    fun giveToAi(app: Context) {
        if (phase != Phase.OWNER) return
        val said = synchronized(transcript) { transcript.takeLast(12).joinToString("\n") }
        log("call handed back to NISU AI")
        startSession(app, "The owner talked with the caller himself for a while and has now handed the call back to you. In one short sentence tell the caller you are back, then carry on helping. Earlier in this call:\n$said")
    }

    // =====================================================================================================
    // the conversation (Gemini Live) + audio
    // =====================================================================================================
    private fun startSession(app: Context, handoverNote: String?) {
        if (phase == Phase.AI) return
        val key = Prefs.get(app, Prefs.KEY, "").trim()
        if (key.isEmpty()) { alertOwner(app, "Call AI cannot talk", "No Gemini API key is saved in NISU AI."); finishToOwner(app); return }
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { alertOwner(app, "Call AI cannot hear", "The microphone permission is off."); finishToOwner(app); return }
        // Ensure AssistantService is started if not running (needed on Android 11+ for foreground microphone access) and yields its recorder
        try { AssistantService.ensureYieldedForCallAi(app) } catch (_: Throwable) {}
        phase = Phase.AI
        val g = ++gen
        readyOnce = false; retry = 0; compat = 0; greeted = false
        prevNoInterrupt = GeminiLive.noInterrupt
        GeminiLive.noInterrupt = true            // half duplex: her sentence is never cut by her own echo
        lastVoiceAt = SystemClock.uptimeMillis()
        prepareAudio(app)
        startPlayer(app)
        startMic(app, g)
        postNotification(app)
        // Re-assert speakerphone routing a few times during the first seconds of the call, because the dialer / WhatsApp
        // often resets audio routing to the earpiece right after the call connects!
        for (delay in listOf(450L, 1200L, 2500L, 4500L)) {
            main.postDelayed({ if (g == gen && phase == Phase.AI) enforceSpeakerphone(app) }, delay)
        }
        main.postDelayed({ if (g == gen && phase == Phase.AI) { log("call is long; asking the AI to wrap up"); live?.sendText("The call has been long. Politely finish the conversation now and say goodbye.") } }, MAX_CALL_MS - 3 * 60_000L)
        main.postDelayed({ if (g == gen && phase == Phase.AI) endCall(app) }, MAX_CALL_MS)
        main.postDelayed(object : Runnable {
            override fun run() {
                if (g != gen || phase != Phase.AI) return
                if (SystemClock.uptimeMillis() - lastVoiceAt > QUIET_END_MS && SystemClock.uptimeMillis() > speakingUntil + 2000L) { log("nobody has spoken for a long time; ending the call"); endCall(app); return }
                main.postDelayed(this, 5000L)
            }
        }, 5000L)
        thread(name = "call-ai-prompt", isDaemon = true) {
            val prompt = buildPrompt(app, handoverNote)
            main.post { if (g == gen && phase == Phase.AI) connect(app, key, prompt, g, handoverNote) }
        }
    }

    private fun finishToOwner(app: Context) {
        phase = Phase.OWNER
        try { AssistantService.notifyCallAiChanged() } catch (_: Throwable) {}
        postNotification(app)
    }

    private fun connect(app: Context, key: String, prompt: String, g: Int, handoverNote: String?) {
        val model = Prefs.liveModel(app)
        val rules = LiveModels.rules(model)
        val voice = Voice.saved(app)
        live?.close()
        live = GeminiLive(key, model, voice, prompt, JSONArray(), resume, rules.thinkingLevel, rules.apiVersion, compat, callback(app, key, prompt, g, handoverNote)).also {
            it.serverVad = false
            it.quickTurnMs = 0
            it.fastEnd = true
            it.thinkingBudget = rules.thinkingBudget
            it.connect()
        }
    }

    private fun callback(app: Context, key: String, prompt: String, g: Int, handoverNote: String?) = object : GeminiLive.Callback {
        override fun onReady() {
            if (g != gen) return
            readyOnce = true; retry = 0
            main.post {
                if (g != gen || phase != Phase.AI || greeted) return@post
                greeted = true
                enforceSpeakerphone(app)
                val owner = Personal.ownerName(app)
                val ai = Personal.aiName(app)
                live?.sendText(handoverNote
                    ?: "[SYSTEM NOTICE, not spoken by the caller] The phone call has just connected. The caller is waiting on the line and cannot hear you until you speak. Speak first right now: give a short, warm, natural hello (in Bengali if in Bangladesh/India or if the caller's name looks Bengali, otherwise English), say you are $ai, $owner's assistant, that $owner is a bit busy right now, and politely ask who is calling or what message to give $owner.")
            }
        }
        override fun onAudio(pcm: ByteArray) { if (g == gen) enqueue(pcm) }
        override fun onInterrupted() { if (g == gen) flushPlayer() }
        override fun onTurnComplete() { if (g == gen) flushLines() }
        override fun onInText(t: String) {
            if (g == gen) {
                lastVoiceAt = SystemClock.uptimeMillis()
                synchronized(transcript) { inBuf.append(t) }
            }
        }
        override fun onOutText(t: String) {
            if (g == gen) {
                lastVoiceAt = SystemClock.uptimeMillis()
                synchronized(transcript) { outBuf.append(t) }
            }
        }
        override fun onToolCall(id: String, name: String, args: JSONObject) {
            try { live?.sendToolResponse(id, name, JSONObject().put("error", "No tools are available during a call.")) } catch (_: Exception) {}
        }
        override fun onResumeHandle(handle: String) { if (g == gen) resume = handle }
        override fun onClosed(reason: String, fatal: Boolean, quick: Boolean) {
            main.post {
                if (g != gen || phase != Phase.AI) return@post
                log("connection closed: ${reason.take(80)}")
                if (fatal || retry >= 6) {
                    alertOwner(app, "Call AI lost its connection", "Please take over the $appLabel call. (${reason.take(80)})")
                    takeOver(app); return@post
                }
                retry++
                if (!readyOnce && compat < 2) compat++
                if (!readyOnce) resume = null
                main.postDelayed({ if (g == gen && phase == Phase.AI) connect(app, key, prompt, g, handoverNote) }, 450L * retry)
            }
        }
    }

    private fun buildPrompt(app: Context, handoverNote: String?): String {
        val owner = Personal.ownerName(app)
        val ai = Personal.aiName(app)
        val callerLine = if (who.isNotBlank()) "The caller shows up as \"$who\" on $appLabel." else "The caller's name is not known."
        return """
You are $ai, $owner's personal AI assistant. You have just answered a live AUDIO phone call ($appLabel) because $owner cannot take it right now. $callerLine

HOW TO TALK
- This is a phone call: speak naturally, warmly and briefly, one or two short sentences at a time, then stop and listen. Never read lists. Never use emojis or markdown.
- Speak the language the caller speaks (Bengali, Hindi, English or any other) and stay in it unless the caller asks to change.
- You hear the caller through a loudspeaker, so the sound can be noisy. If you did not catch something, politely ask the caller to say it again. Never guess names, numbers or addresses: repeat them back to be sure.
- Understand what the other person says and answer it properly, like a polite, smart human assistant. Answer general questions normally.
- Say clearly that you are $owner's AI assistant if asked; never pretend to be a human, and never pretend to be $owner.

WHAT YOU MUST NOT DO
- Never tell the caller private things: $owner's location, schedule details, phone numbers, passwords, messages, contacts, accounts or anything stored on the phone.
- Never agree to payments, transfers, OTP codes, passwords or any promise on $owner's behalf. Say $owner will contact them himself.
- You have no phone tools in this call. Do not claim to have done anything on the phone.

GOAL
- Find out who is calling and why, help if you can with ordinary questions, and otherwise take a clear message (name, reason, what they need, best way to reach them) and say $owner will get back to them.
- If it sounds urgent or like an emergency, tell the caller you will alert $owner immediately.
- When the caller says goodbye, say a short goodbye.
${Clock.note(app)}
${Phonebook.promptBlock(app)}${CallBook.promptBlock(app)}
(The saved-people notes above are only for knowing how to talk if the caller is that person. Never read them out.)
${LanguageLock.voiceBlock(app)}
""".trimIndent()
    }

    // ---- microphone: hears the caller through the loudspeaker ----
    private fun startMic(app: Context, g: Int) {
        micRun = true
        thread(name = "call-ai-mic", isDaemon = true) {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Throwable) {}
            val sources = ArrayList<Int>().apply {
                add(MediaRecorder.AudioSource.MIC)
                add(MediaRecorder.AudioSource.CAMCORDER)
                add(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                if (Build.VERSION.SDK_INT >= 24) add(MediaRecorder.AudioSource.UNPROCESSED)
                add(MediaRecorder.AudioSource.DEFAULT)
                add(MediaRecorder.AudioSource.VOICE_COMMUNICATION)   // last: its echo canceller can erase the caller's voice that comes out of our own speaker
            }
            var si = 0
            var r: AudioRecord? = null
            var sid = 0
            var sawSignal = false
            var zeroChunks = 0
            var totalSwitchCycles = 0
            var gain = 2.4
            val buf = ByteArray(1280)   // 40 ms at 16 kHz mono
            try {
                // Wait briefly for AssistantService to finish releasing its AudioRecord if it was active
                try { Thread.sleep(180) } catch (_: InterruptedException) {}
                while (micRun && g == gen) {
                    if (r == null) {
                        if (si >= sources.size) {
                            totalSwitchCycles++
                            if (totalSwitchCycles >= 2) {
                                main.post { if (g == gen) onMicBlocked(app) }
                                break
                            }
                            si = 0
                            try { Thread.sleep(400) } catch (_: InterruptedException) { break }
                        }
                        r = openRecorder(sources[si])
                        if (r == null) { si++; continue }
                        sid = r.audioSessionId; MicOwn.add(sid)
                        zeroChunks = 0; sawSignal = false
                        try { r.startRecording() } catch (_: Throwable) { MicOwn.remove(sid); try { r.release() } catch (_: Throwable) {}; r = null; si++; continue }
                        log("microphone source ${sources[si]} opened")
                    }
                    val n = try { r.read(buf, 0, buf.size) } catch (_: Throwable) { -1 }
                    if (n <= 0) {
                        MicOwn.remove(sid); try { r.release() } catch (_: Throwable) {}; r = null
                        si++; Thread.sleep(100); continue
                    }
                    // raw level (before anything is blanked): all zero for ~3.2 s = Android is silencing this microphone source
                    var peak = 0; var sum = 0.0; var i = 0
                    while (i + 1 < n) {
                        val v = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
                        val a = if (v < 0) -v else v
                        if (a > peak) peak = a
                        sum += v.toDouble() * v
                        i += 2
                    }
                    if (peak <= 1) { zeroChunks++ } else { zeroChunks = 0; sawSignal = true }
                    // Wait longer while the AI itself is greeting/speaking before condemning a mic source as silent
                    val maxZeros = if (SystemClock.uptimeMillis() < speakingUntil + 500L) 120 else 75
                    if (!sawSignal && zeroChunks >= maxZeros) {
                        log("microphone source ${sources[si]} is silent; trying the next one")
                        MicOwn.remove(sid); try { r.release() } catch (_: Throwable) {}; r = null
                        si++; continue
                    }
                    val rms = Math.sqrt(sum / (n / 2).coerceAtLeast(1))
                    val now = SystemClock.uptimeMillis()
                    val echo = now < speakingUntil + 380L
                    if (!echo && rms > 260.0) lastVoiceAt = now
                    val l = live
                    if (l != null && l.ready) {
                        if (echo) {
                            l.sendAudio(ByteArray(n))
                        } else {
                            // the caller is heard from a loudspeaker a few cm away: lift quiet speech, never noise
                            val target = if (rms > 30.0) (3600.0 / rms).coerceIn(1.2, 9.5) else 1.2
                            gain += (target - gain) * 0.14
                            val out = ByteArray(n)
                            var k = 0
                            while (k + 1 < n) {
                                val v = ((buf[k + 1].toInt() shl 8) or (buf[k].toInt() and 0xFF)).toShort().toInt()
                                val s = (v * gain).toInt().coerceIn(-32768, 32767)
                                out[k] = (s and 0xFF).toByte(); out[k + 1] = ((s shr 8) and 0xFF).toByte(); k += 2
                            }
                            l.sendAudio(out)
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally {
                if (r != null) { MicOwn.remove(sid); try { r.stop() } catch (_: Throwable) {}; try { r.release() } catch (_: Throwable) {} }
            }
        }
    }

    private fun openRecorder(src: Int): AudioRecord? {
        return try {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, (min * 4).coerceAtLeast(8192))
            if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
        } catch (_: Throwable) { null }
    }

    /** No microphone source gives real sound during this call: Android blocks it. Be honest, do not talk into the void. */
    private fun onMicBlocked(app: Context) {
        if (phase != Phase.AI) return
        log("MICROPHONE BLOCKED during the call (all sources are silent)")
        alertOwner(app, "Call AI cannot hear this call", "Android blocks the microphone during this $appLabel call. Please take the call yourself.")
        takeOver(app)
    }

    // ---- speaker: the AI voice (24 kHz) ----
    private fun buildCallTrack(app: Context, usage: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes((min * 4).coerceAtLeast(24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        // Explicitly route the AI's voice to the built-in loudspeaker so the call mic can hear it clearly
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val am = app.getSystemService(AudioManager::class.java)
                val spk = am?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)?.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (spk != null) t.setPreferredDevice(spk)
            } catch (_: Throwable) {}
        }
        return t
    }

    private fun startPlayer(app: Context) {
        stopPlayer()
        // For normal cellular calls, the modem owns USAGE_VOICE_COMMUNICATION, so USAGE_MEDIA plays out of the loudspeaker much more reliably.
        // For VoIP calls, try USAGE_MEDIA first (loudspeaker) and fall back to USAGE_VOICE_COMMUNICATION if needed.
        val initialUsage = AudioAttributes.USAGE_MEDIA
        trackMode = initialUsage
        var t = try { buildCallTrack(app, initialUsage) } catch (_: Throwable) { buildCallTrack(app, AudioAttributes.USAGE_VOICE_COMMUNICATION) }
        track = t
        try { t.play() } catch (_: Throwable) {}
        val q = LinkedBlockingQueue<ByteArray>()
        playQ = q
        playRun = true
        thread(name = "call-ai-play", isDaemon = true) {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Throwable) {}
            var carry = -1
            while (playRun) {
                val raw = try { q.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null } ?: continue
                var b = raw
                if (carry >= 0) {
                    val m = ByteArray(b.size + 1)
                    m[0] = carry.toByte()
                    System.arraycopy(b, 0, m, 1, b.size)
                    b = m; carry = -1
                }
                if (b.size % 2 == 1) { carry = b[b.size - 1].toInt() and 0xFF; b = b.copyOf(b.size - 1) }
                if (b.isEmpty()) continue

                var off = 0
                var stallSince = 0L
                while (off < b.size && playRun) {
                    var tr = track ?: break
                    try { if (tr.playState != AudioTrack.PLAYSTATE_PLAYING) tr.play() } catch (_: Throwable) {}
                    val w = try {
                        if (Build.VERSION.SDK_INT >= 23) tr.write(b, off, b.size - off, AudioTrack.WRITE_NON_BLOCKING)
                        else tr.write(b, off, b.size - off)
                    } catch (_: Throwable) { -1 }
                    if (w < 0) {
                        tr = rebuildPlayerTrack(app) ?: break
                        continue
                    }
                    if (w == 0) {
                        val now = SystemClock.uptimeMillis()
                        if (stallSince == 0L) stallSince = now
                        if (now - stallSince > 1200L) {
                            tr = rebuildPlayerTrack(app) ?: break
                            stallSince = 0L
                            continue
                        }
                        try { Thread.sleep(8) } catch (_: Throwable) {}
                        continue
                    }
                    stallSince = 0L
                    off += w
                    val now = SystemClock.uptimeMillis()
                    AppState.outAt = now
                }
            }
        }
    }

    private fun rebuildPlayerTrack(app: Context): AudioTrack? {
        return try {
            try { track?.stop() } catch (_: Throwable) {}
            try { track?.release() } catch (_: Throwable) {}
            val nextUsage = if (trackMode == AudioAttributes.USAGE_MEDIA) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA
            trackMode = nextUsage
            val nt = buildCallTrack(app, nextUsage)
            nt.play()
            track = nt
            nt
        } catch (_: Throwable) { null }
    }

    private fun enqueue(pcm: ByteArray) {
        val q = playQ ?: return
        val now = SystemClock.uptimeMillis()
        speakingUntil = maxOf(now, speakingUntil) + pcm.size / 48L     // 24 kHz x 2 bytes = 48 bytes per ms
        lastVoiceAt = speakingUntil
        q.offer(pcm)
    }

    private fun flushPlayer() {
        playQ?.clear()
        speakingUntil = SystemClock.uptimeMillis()
        try { track?.pause(); track?.flush(); track?.play() } catch (_: Throwable) {}
    }

    private fun stopPlayer() {
        playRun = false
        playQ?.clear(); playQ = null
        try { track?.stop() } catch (_: Throwable) {}
        try { track?.release() } catch (_: Throwable) {}
        track = null
        speakingUntil = 0L
    }

    private fun enforceSpeakerphone(app: Context) {
        val am = app.getSystemService(AudioManager::class.java) ?: return
        @Suppress("DEPRECATION")
        try {
            if (!cellular && am.mode == AudioManager.MODE_NORMAL) {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
            }
            if (!am.isSpeakerphoneOn) am.isSpeakerphoneOn = true
        } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 31) try {
            val spk = am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (spk != null && am.communicationDevice?.id != spk.id) am.setCommunicationDevice(spk)
        } catch (_: Throwable) {}
        // If cellular call is on screen and Android blocked setCommunicationDevice for non-default dialer, tap Speaker button via Accessibility if not checked
        if (cellular) {
            val acc = NisuAccessibilityService.inst
            if (acc != null && !am.isSpeakerphoneOn) {
                thread(name = "call-ai-spk", isDaemon = true) {
                    val nodes = acc.scan(120)
                    val spkNode = nodes.firstOrNull {
                        val l = it.all
                        ("speaker" in l || "স্পিকার" in l || "स्पीकर" in l || "audio route" in l) && !it.checked && !it.selected && it.clickable
                    }
                    if (spkNode != null) acc.clickNode(spkNode.node)
                }
            }
        }
    }

    private fun prepareAudio(app: Context) {
        val am = app.getSystemService(AudioManager::class.java) ?: return
        @Suppress("DEPRECATION")
        try { if (savedSpeaker == null) savedSpeaker = am.isSpeakerphoneOn } catch (_: Throwable) {}
        try {
            if (savedVoiceVol < 0) savedVoiceVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
        } catch (_: Throwable) {}
        try {
            if (savedMediaVol < 0) savedMediaVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val maxM = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val targetM = (maxM * 85 / 100).coerceAtLeast(1)
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) < targetM) am.setStreamVolume(AudioManager.STREAM_MUSIC, targetM, 0)
        } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .build()
                am.requestAudioFocus(req)
                focusReq = req
            } catch (_: Throwable) {}
        }
        enforceSpeakerphone(app)
    }

    private fun restoreAudio(app: Context) {
        val am = app.getSystemService(AudioManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            try { focusReq?.let { am.abandonAudioFocusRequest(it) } } catch (_: Throwable) {}
            focusReq = null
        }
        try { if (savedVoiceVol >= 0) am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, savedVoiceVol, 0) } catch (_: Throwable) {}
        try { if (savedMediaVol >= 0) am.setStreamVolume(AudioManager.STREAM_MUSIC, savedMediaVol, 0) } catch (_: Throwable) {}
        @Suppress("DEPRECATION") try { savedSpeaker?.let { am.isSpeakerphoneOn = it } } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 31) try { am.clearCommunicationDevice() } catch (_: Throwable) {}
        savedSpeaker = null; savedVoiceVol = -1; savedMediaVol = -1
    }

    private fun stopSession() {
        micRun = false
        stopPlayer()
        try { live?.close() } catch (_: Throwable) {}
        live = null
        GeminiLive.noInterrupt = prevNoInterrupt
    }

    private fun flushLines() {
        synchronized(transcript) {
            val i = inBuf.toString().trim(); val o = outBuf.toString().trim()
            if (i.isNotEmpty()) transcript.add("Caller: $i")
            if (o.isNotEmpty()) transcript.add("NISU AI: $o")
            inBuf.setLength(0); outBuf.setLength(0)
            while (transcript.size > 80) transcript.removeAt(0)
        }
    }

    // =====================================================================================================
    // notifications: the hand-over buttons and the call report
    // =====================================================================================================
    private fun channel(app: Context): NotificationManager {
        val nm = app.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) nm.createNotificationChannel(NotificationChannel(CH, "NISU AI call answering", NotificationManager.IMPORTANCE_HIGH))
        return nm
    }

    private fun pi(app: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(app, code, Intent(app, CallAiReceiver::class.java).setAction(action).putExtra("t", token), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    @Suppress("DEPRECATION")
    private fun postNotification(app: Context) {
        try {
            val nm = channel(app)
            val title = when (phase) {
                Phase.RINGING -> "Incoming $appLabel call ${who}".trim()
                Phase.AI -> "NISU AI is on the call ${if (who.isNotBlank()) "with $who" else ""}".trim()
                Phase.OWNER -> "You are on the call ${if (who.isNotBlank()) "with $who" else ""}".trim()
                Phase.IDLE -> return
            }
            val b = Notification.Builder(app, CH).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(title)
                .setContentText(when (phase) { Phase.AI -> "Tap TAKE OVER to talk yourself"; Phase.OWNER -> "Tap GIVE TO AI to let NISU AI continue"; else -> "NISU AI will answer for you" })
                .setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_CALL)
            if (phase == Phase.AI) b.addAction(android.R.drawable.ic_menu_call, "TAKE OVER", pi(app, A_TAKE, 1))
            if (phase == Phase.OWNER) b.addAction(android.R.drawable.ic_menu_revert, "GIVE TO AI", pi(app, A_GIVE, 2))
            if (phase != Phase.RINGING) b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "END CALL", pi(app, A_END, 3))
            nm.notify(NID, b.build())
        } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    private fun alertOwner(app: Context, title: String, text: String) {
        try { channel(app).notify(NID_LOG + 1, Notification.Builder(app, CH).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build()) } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    private fun postLog(app: Context, title: String, text: String) {
        try { channel(app).notify(NID_LOG, Notification.Builder(app, CH).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(title).setContentText(text.take(120)).setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build()) } catch (_: Throwable) {}
    }

    /** Called by the receiver for the three buttons; the per-call token stops other apps from pressing them. */
    fun onAction(app: Context, action: String?, t: String?) {
        if (t == null || t != token) return
        when (action) { A_TAKE -> takeOver(app); A_GIVE -> giveToAi(app); A_END -> endCall(app) }
    }

    private fun nameForNumber(app: Context, number: String?): String? {
        if (number.isNullOrBlank() || app.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            app.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (_: Throwable) { null }
    }
}

/** Gets the phone-state broadcast (normal calls) and the notification buttons (TAKE OVER / GIVE TO AI / END CALL). */
class CallAiReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        try {
            when (intent.action) {
                TelephonyManager.ACTION_PHONE_STATE_CHANGED ->
                    CallAi.onPhoneState(app, intent.getStringExtra(TelephonyManager.EXTRA_STATE), intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER))
                CallAi.A_TAKE, CallAi.A_GIVE, CallAi.A_END -> CallAi.onAction(app, intent.action, intent.getStringExtra("t"))
            }
        } catch (_: Throwable) {}
    }
}
