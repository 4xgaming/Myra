package ai.nisu.assistant

import java.security.MessageDigest

/**
 * The protected identity of this app.
 * [integrityOk] compares them with a fixed fingerprint. If somebody edits them (or this fingerprint) the About screen shows a
 * "modified build" warning, and the assistant keeps stating the original developer.
 */
object Brand {
    const val APP_NAME = "NISU AI"
    const val DEVELOPER = "Raju"
    private const val FINGERPRINT = "8edaf22bbd1c769227d82ed67a0d67a402f76bba18b393fec6221420910a396a"

    fun integrityOk(): Boolean = try {
        val d = MessageDigest.getInstance("SHA-256").digest((APP_NAME + "|" + DEVELOPER).toByteArray(Charsets.UTF_8))
        d.joinToString("") { "%02x".format(it) } == FINGERPRINT
    } catch (_: Exception) { false }

    /** Shown in the About screen when [integrityOk] is false. */
    const val TAMPER_WARNING = "WARNING: this build was modified. The brand name or the developer name was changed, which the original developer (Raju) does not allow. This is not the original NISU AI."
}
