package ai.nisu.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * v3.179: AI AGENT & AI APK / WEBSITE AI BUILDER SYSTEM.
 *
 * Lets NISU AI create complete, 100% unlocked AI Applications (Android APK or Website AI) on her own whenever the user asks:
 * - "Make an AI app / AI APK" or "Make a Website AI"
 * - Pre-equipped with:
 *   1. Real Gemini Live WebSocket API (`BidiGenerateContent` real-time voice-to-voice audio 16kHz PCM in / 24kHz PCM out + live screen/camera video frames + real-time function calling) AND Gemini Text/Code Chat API (`streamGenerateContent`).
 *   2. Built-in API Key Manager + 1-Click "Get API Key" system (`https://aistudio.google.com/app/apikey`) + Model & Voice selector (`gemini-2.5-flash-native-audio-preview-12-2025` Aoede, `gemini-3.1-flash-live-preview` Leda, `gemini-2.5-flash`).
 *   3. 100% ALL-UNLOCKED Phone Control in APK (No license lock, no free-tier timer!):
 *      - Accessibility Service (`AiControlService`) that reads the live screen UI tree (`get_screen`), taps (`tap`, `click_text`), types (`type_text` with `submit=true`), swipes (`swipe`, `scroll`), and presses global keys (`back`, `home`, `recents`, `notifications`, `lock_screen`).
 *      - Screen Capture / Live Vision (`takeScreenshot` on Android 11+ & camera preview frames sent to Gemini Live).
 *      - App Launcher & Controller (`open_app` by app name in English/Bangla/Hindi, `close_app` to close/kill foreground or background apps, `list_apps`, `open_url`).
 *      - Phone Hardware & System Controls (`set_volume`, `set_brightness`, `set_flashlight`, `call_number`, `send_sms`, `device_info`).
 *      - Built-in Self-Coding & Self-Update System (`self_update_ui`, `write_code`) inside the generated AI so the generated AI itself can also write code, modify its own interface, or add features dynamically!
 *   4. Unlimited Iterative Updates & Auto-Repair:
 *      - The user can ask NISU AI to add any feature, change the persona/theme/voice/tools, or fix any bug in the generated AI APK or Website AI as many times as wanted (`update_ai_project` / `build_app` / `build_website` / `website_fix`), and NISU AI updates the code and auto-repairs any compiler or runtime error!
 */
object AiAgentBuilder {

    val TOOL_NAMES = setOf("build_ai_apk", "build_ai_website", "update_ai_project")

    /** Detects when a user's app or website description is asking to build an AI assistant / AI APK / Website AI. */
    fun isAiProjectRequest(name: String, description: String, template: String = ""): Boolean {
        if (template.lowercase() in setOf("ai", "ai_apk", "ai_app", "ai_website", "nisu_clone", "jarvis")) return true
        val combined = "$name $description".lowercase()
        val hasAiWord = Regex("""\b(ai|assistant|chatbot|voice\s*ai|live\s*ai|gemini|jarvis|nisu|nishu|agent|companion|bot)\b|এআই|অ্যাসিস্ট্যান্ট|রোবট|বট|জারভিস|নিশু""").containsMatchIn(combined)
        val hasAiFeature = Regex("""\b(gemini\s*live|api\s*key|get\s*key|screen\s*read|phone\s*control|voice\s*call|open\s*app|close\s*app|all\s*unlocked|coding\s*system|like\s*nisu|nisu\s*moto|nijer\s*ai|own\s*ai|ai\s*make|make\s*ai|ai\s*app|ai\s*apk|website\s*ai|ai\s*website)\b|স্ক্রিন\s*রিড|ফোন\s*কন্ট্রোল|ভয়েস|এপিআই""").containsMatchIn(combined)
        return hasAiWord && (hasAiFeature || combined.contains("ai app") || combined.contains("ai apk") || combined.contains("website ai") || combined.contains("ai website") || combined.contains("ai boro") || combined.contains("ai banao") || combined.contains("ai make"))
    }

    fun declarations(): List<JSONObject> = listOf(
        Tools.fn(
            "build_ai_apk",
            "Create a COMPLETE, 100% ALL-UNLOCKED custom AI Android APK (like NISU AI / Jarvis / custom AI companion) with Gemini Live real-time voice & vision model, API Key + 'Get Free API Key' button system, live Screen Reading & Accessibility Phone Control (open apps, close apps, tap, type, swipe, scroll, volume, brightness, flashlight, calls, SMS), and a built-in Coding & Self-Update system. All features in the generated APK are 100% unlocked with no license gate. Also updates an existing AI APK when project is given.",
            mapOf(
                "name" to ("STRING" to "Name of the custom AI app in Latin letters, e.g. JarvisAI, MyNisuAI, NovaAI"),
                "description" to ("STRING" to "Everything the user wants in this AI APK: personality/persona, voice (Aoede, Leda, Puck, Charon, Kore, Fenrir), theme/colors, custom tools, phone control rules, or what to update/fix if changing an existing project."),
                "voice" to ("STRING" to "Default Gemini Live voice for the AI: Aoede (natural female), Leda (cute female), Charon (Jarvis male), Fenrir (deep male), Puck, Kore. Default Aoede."),
                "persona" to ("STRING" to "Default personality instructions for the created AI (e.g. helpful assistant, girlfriend, Jarvis butler, coding expert, etc.)."),
                "project" to ("STRING" to "Existing project slug from app_list if updating or fixing an existing AI APK; leave empty for a new AI APK."),
                "build" to ("BOOLEAN" to "true (default) to also compile the APK in Termux and save the self-building ZIP in Downloads."),
                "user_confirmed" to ("BOOLEAN" to "true after the user asked for or confirmed building/updating this AI APK")
            ),
            listOf("description", "user_confirmed")
        ),
        Tools.fn(
            "build_ai_website",
            "Create a COMPLETE, 100% ALL-UNLOCKED Website AI (web-based AI assistant with Gemini Live real-time WebSocket voice-to-voice audio, live Screen Share & Camera vision reading, API Key input + 1-click 'Get Free API Key' system, Live Code Generator & preview studio, and self-updating custom tools). Opens in Chrome / In-App Website Runner and saves a standalone ZIP in Downloads. Also updates or fixes an existing Website AI when project is given.",
            mapOf(
                "name" to ("STRING" to "Name of the Website AI, e.g. OmniWebAI, NisuWebStudio"),
                "description" to ("STRING" to "Complete description of the Website AI: persona, voice, features, UI theme, custom tools, or what to update/fix."),
                "voice" to ("STRING" to "Default Gemini Live voice: Aoede, Leda, Charon, Fenrir, Kore. Default Aoede."),
                "project" to ("STRING" to "Existing website slug from website_list when updating or fixing an existing Website AI"),
                "user_confirmed" to ("BOOLEAN" to "true after the user asked for or confirmed building/updating this Website AI")
            ),
            listOf("description", "user_confirmed")
        ),
        Tools.fn(
            "update_ai_project",
            "Add new features, apply user-requested updates, change UI/persona/tools, or fix any bug/error in an existing AI APK or Website AI project created by NISU AI.",
            mapOf(
                "project" to ("STRING" to "Project name/slug from app_list or website_list (leave empty for the most recent AI project)"),
                "kind" to ("STRING" to "apk | website | auto (default auto)"),
                "update_request" to ("STRING" to "Detailed description of what to add, change, customize, or fix according to the user's wishes")
            ),
            listOf("update_request")
        )
    )

    fun run(ctx: Context, name: String, a: JSONObject): JSONObject {
        val app = ctx.applicationContext
        return when (name) {
            "build_ai_apk" -> {
                val desc = enrichAiApkDescription(
                    a.optString("name", "CustomAI"),
                    a.optString("description", ""),
                    a.optString("voice", "Aoede"),
                    a.optString("persona", "")
                )
                val forwarded = JSONObject()
                    .put("name", a.optString("name", "CustomAI"))
                    .put("description", desc)
                    .put("template", "ai_apk")
                    .put("project", a.optString("project", ""))
                    .put("build", a.optBoolean("build", true))
                    .put("user_confirmed", a.optBoolean("user_confirmed", true))
                AppBuilder.run(app, "build_app", forwarded)
            }
            "build_ai_website" -> {
                val desc = enrichAiWebsiteDescription(
                    a.optString("name", "WebAI"),
                    a.optString("description", ""),
                    a.optString("voice", "Aoede")
                )
                val forwarded = JSONObject()
                    .put("name", a.optString("name", "WebAI"))
                    .put("description", desc)
                    .put("template", "ai_website")
                    .put("project", a.optString("project", ""))
                    .put("user_confirmed", a.optBoolean("user_confirmed", true))
                WebBuilder.run(app, "build_website", forwarded)
            }
            "update_ai_project" -> updateAiProject(app, a)
            else -> JSONObject().put("error", "Unknown tool $name")
        }
    }

    private fun updateAiProject(ctx: Context, a: JSONObject): JSONObject {
        val req = a.optString("update_request", "").trim()
        if (req.length < 3) return JSONObject().put("error", "Please describe what to update or fix in the AI project.")
        val rawProj = a.optString("project", "").trim()
        val kind = a.optString("kind", "auto").lowercase().trim()

        val resolvedApp = AppBuilder.resolveSlug(ctx, rawProj)
        val isApp = when (kind) {
            "apk", "app" -> true
            "website", "web" -> false
            else -> {
                if (rawProj.isNotEmpty() && AppBuilder.localDirOf(ctx, AppBuilder.sanitize(rawProj)).isDirectory) true
                else if (rawProj.isNotEmpty() && WebBuilder.dirOf(ctx, WebRules.cleanSlug(rawProj)).isDirectory) false
                else {
                    val lastAppTime = if (resolvedApp.isNotEmpty()) AppBuilder.localDirOf(ctx, resolvedApp).lastModified() else 0L
                    val lastWeb = WebBuilder.sites(ctx).firstOrNull()
                    val lastWebTime = lastWeb?.lastModified() ?: 0L
                    lastAppTime >= lastWebTime && lastAppTime > 0L
                }
            }
        }

        return if (isApp) {
            val slug = resolvedApp.ifEmpty { return JSONObject().put("error", "No AI APK project found to update. Build one first with build_ai_apk.") }
            val forwarded = JSONObject()
                .put("project", slug)
                .put("name", slug)
                .put("template", "ai_apk")
                .put("description", "UPDATE / FIX EXISTING AI APK ('$slug'): $req\nKeep all existing Gemini Live WebSocket audio/vision, API Key + Get Key system, Screen Reader Accessibility Service, all-unlocked Phone Control tools (open_app, close_app, tap, click_text, type_text, swipe, scroll, press_key, set_volume, set_brightness, flashlight, call, sms), and self-coding system intact while applying this update or fix!")
                .put("build", true)
                .put("user_confirmed", true)
            AppBuilder.run(ctx, "build_app", forwarded)
        } else {
            val slug = try { WebBuilder.resolve(ctx, rawProj) } catch (_: Exception) { "" }
            if (slug.isEmpty()) return JSONObject().put("error", "No Website AI project found to update. Build one first with build_ai_website.")
            val forwarded = JSONObject()
                .put("project", slug)
                .put("name", slug)
                .put("template", "ai_website")
                .put("description", "UPDATE / FIX EXISTING WEBSITE AI ('$slug'): $req\nKeep all existing Gemini Live WebSocket voice/vision, API Key + Get Key system, Screen/Camera reader, and Live Code Studio intact while applying this update or fix!")
                .put("user_confirmed", true)
            WebBuilder.run(ctx, "build_website", forwarded)
        }
    }

    fun enrichAiApkDescription(name: String, userDesc: String, voice: String = "Aoede", persona: String = ""): String {
        val v = voice.ifBlank { "Aoede" }
        val p = persona.ifBlank { "You are $name, an advanced, warm, ultra-fast AI assistant and companion with full unlocked Android phone control, live screen reading, and live coding power." }
        return """
BUILD A COMPLETE, 100% ALL-UNLOCKED ANDROID AI ASSISTANT APK NAMED "$name":
User Request & Custom Features: $userDesc
Default Voice: $v (supports switching between Aoede, Leda, Charon, Fenrir, Kore, Puck)
Default Persona: $p

MANDATORY ARCHITECTURE FOR THIS AI APK (ALL UNLOCKED — NO LICENSE KEY OR FREE TIER RESTRICTIONS):
1. GEMINI LIVE REAL-TIME VOICE + VISION + FUNCTION CALLING:
   - Connects via WebSocket to `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=API_KEY`
   - Supports models: `gemini-2.5-flash-native-audio-preview-12-2025` (Aoede voice, thinkingBudget=0 for instant replies) and `gemini-3.1-flash-live-preview` (Leda voice).
   - Streams 16kHz PCM microphone audio in real time and plays 24kHz PCM AI voice audio with barge-in interruption support.
   - Also includes a full Text & Code Chat tab powered by `gemini-2.5-flash` (`generateContent`) so the user can both talk live AND chat/code by text.
2. API KEY & "GET FREE API KEY" SYSTEM:
   - Built-in API Key Manager drawer/modal where the user can paste & save their Gemini API key in `SharedPreferences` / `localStorage`.
   - Includes a 1-click "Get Free Gemini API Key" button that opens `https://aistudio.google.com/app/apikey` directly in the browser, plus a "Test Key" verifier.
3. LIVE SCREEN READER & VISION:
   - Includes `AiControlService` (Android `AccessibilityService`) that reads the entire on-screen UI hierarchy (`get_screen`) with element labels and `[x,y]` coordinates in any app.
   - Supports live screen capture (`takeScreenshot` on Android 11+ or camera feed) and sends JPEG frames to the Gemini Live WebSocket so the AI can literally see what is on the phone screen or camera!
4. 100% ALL-UNLOCKED PHONE CONTROL TOOLS (wired to Gemini Live `functionDeclarations` AND callable from the UI & AndroidBridge):
   - `open_app(name)`: Opens any installed app on the phone by its name (supports English, Bangla, Hindi aliases like WhatsApp, YouTube, Chrome, Facebook, Settings, Camera, etc.).
   - `close_app(name)`: Closes/stops the specified app (or current foreground app) by navigating home/back and killing background processes (`killBackgroundProcesses`).
   - `get_screen()`: Reads all visible text, buttons, and coordinates currently on the phone screen.
   - `click_text(text)`: Finds and taps any button or element matching the text on screen.
   - `tap(x, y)`: Taps exact pixel or fractional coordinates on screen.
   - `type_text(text, submit)`: Focuses the input/search box on screen, types the text, and optionally presses Enter/Search.
   - `scroll(direction)` & `swipe(x1, y1, x2, y2)`: Scrolls up/down/left/right or swipes anywhere on screen.
   - `press_key(key)`: Triggers `back`, `home`, `recents`, `notifications`, `quick_settings`, or `lock_screen`.
   - `set_volume(stream, percent)` & `set_brightness(percent)` & `set_flashlight(on)`: Controls phone hardware immediately.
   - `call_number(number)` & `send_sms(number, text)` & `open_url(url)`: Places calls, sends SMS, or opens websites.
5. BUILT-IN CODING & SELF-UPDATE SYSTEM INSIDE THE APK:
   - Includes a "Live Code & Self-Update" tab where the user can ask this AI to write websites/apps or modify its own UI/tools/persona on the fly (`self_update_ui`, `generate_code`), with live preview and persistent state!
""".trimIndent()
    }

    fun enrichAiWebsiteDescription(name: String, userDesc: String, voice: String = "Aoede"): String {
        val v = voice.ifBlank { "Aoede" }
        return """
BUILD A COMPLETE, PROFESSIONAL ALL-UNLOCKED WEBSITE AI & LIVE AGENT STUDIO NAMED "$name":
User Request & Custom Features: $userDesc
Default Gemini Live Voice: $v

MANDATORY FEATURES FOR THIS WEBSITE AI:
1. REAL GEMINI LIVE WEBSOCKET (VOICE + SCREEN/CAMERA VISION + TOOLS):
   - Connects directly from browser JavaScript to `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=API_KEY`.
   - Captures microphone audio via Web Audio API (`AudioContext` downsampled to 16kHz 16-bit PCM base64) and plays 24kHz PCM audio chunks seamlessly from Gemini Live (`gemini-2.5-flash-native-audio-preview-12-2025` or `gemini-3.1-flash-live-preview`).
   - Also includes a full Text, Vision & Code Chat engine using `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`.
2. API KEY + 1-CLICK "GET API KEY" SYSTEM:
   - Prominent API Key setup bar & modal saved in `localStorage`, with a 1-click "Get Free API Key" button (`https://aistudio.google.com/app/apikey`), model selector, voice selector (Aoede, Leda, Charon, Fenrir, Kore, Puck), and custom Persona editor.
3. SCREEN READ & CAMERA VISION SYSTEM:
   - "Share Screen / Read Screen" button (`navigator.mediaDevices.getDisplayMedia` + fallback DOM/Canvas capture) and "Camera Eye" button (`navigator.mediaDevices.getUserMedia`) that stream JPEG frames at 1 FPS to Gemini Live AND allow instant visual Q&A so the AI can read and analyze anything on the user's screen or camera.
4. ALL-UNLOCKED AI AGENT ACTIONS & SELF-UPDATING CODING STUDIO:
   - Built-in function tools for Gemini Live: `read_screen_context`, `open_website_url`, `generate_live_code`, `self_update_ai_app`, `run_js_tool`, `save_memory`.
   - Includes a Live Code Studio tab where the AI writes HTML/CSS/JS apps, previews them in a live sandbox, and can self-update its own UI, theme, and tools whenever the user asks!
""".trimIndent()
    }

    // ====================================================================================================
    // COMPLETE, COMPILABLE, ALL-UNLOCKED ANDROID AI APK SCAFFOLD (Kotlin Native Bridge + Accessibility + WebView AI Studio)
    // ====================================================================================================

    /**
     * Generates the complete Android project files for an all-unlocked AI Assistant APK.
     * It combines:
     * 1. `MainActivity.kt` — Full native Android `JavascriptInterface` (`AndroidBridge`) exposing App Open/Close (`openApp`, `closeApp`, `listApps`),
     *    Volume, Brightness, Flashlight, Phone Call, SMS, Device Info, Clipboard, Permission shortcuts, and Accessibility Screen Control.
     * 2. `AiControlService.kt` — Real Android `AccessibilityService` with `canPerformGestures="true"` and `canTakeScreenshot="true"` that dumps the live
     *    screen tree (`dumpScreen`), clicks text (`clickText`), taps (`tap`), swipes (`swipe`), scrolls (`scroll`), types (`typeText`), presses global keys (`pressKey`),
     *    closes apps (`closeCurrentApp`), and captures live screenshots (`takeScreenshotBase64`)!
     * 3. `app/src/main/assets/index.html` — Complete, sleek, ultra-fast AI Assistant UI with:
     *    - Real Gemini Live WebSocket (`BidiGenerateContent`) for continuous real-time voice-to-voice conversation + tool calling + screen/camera vision!
     *    - API Key Setup + 1-click "Get Free API Key" (`https://aistudio.google.com/app/apikey`)!
     *    - All-Unlocked Phone Control Dashboard & Voice Tool Executor (`open_app`, `close_app`, `get_screen`, `click_text`, `tap`, `type_text`, `scroll`, `press_key`, `set_volume`, `set_brightness`, `set_flashlight`, `call_number`, `send_sms`, `self_update_ui`, `write_code`)!
     *    - Built-in Self-Coding & Self-Update system so the user or the AI itself can customize and upgrade the APK anytime!
     */
    fun aiApkScaffold(
        ctx: Context,
        slug: String,
        appName: String,
        pkg: String,
        voice: String = "Aoede",
        persona: String = "",
        customBuildSh: String = ""
    ): List<Pair<String, String>> {
        val pkgPath = pkg.replace('.', '/')
        val defaultPersona = persona.ifBlank {
            "You are $appName, a smart, warm, ultra-fast AI assistant and companion living inside the user's Android phone. You have 100% unlocked phone control, live screen reading, app opening/closing, and live coding capabilities. Speak naturally in the language the user speaks (Bangla, Hindi, English, etc.)."
        }.replace("\"", "\\\"").replace("\n", " ")

        fun fill(s: String): String = s
            .replace("__PKG__", pkg)
            .replace("__NAME__", appName)
            .replace("__SLUG__", slug)
            .replace("__VOICE__", voice.ifBlank { "Aoede" })
            .replace("__PERSONA__", defaultPersona)
            .replace("__COLOR__", "#38B6FF")

        return listOf(
            "settings.gradle.kts" to fill(T_AI_SETTINGS),
            "build.gradle.kts" to fill(T_AI_ROOT_GRADLE),
            "gradle.properties" to fill(T_AI_PROPS),
            "app/build.gradle.kts" to fill(T_AI_APP_GRADLE),
            "app/src/main/AndroidManifest.xml" to fill(T_AI_MANIFEST),
            "app/src/main/res/values/strings.xml" to fill(T_AI_STRINGS),
            "app/src/main/res/values/themes.xml" to fill(T_AI_THEMES),
            "app/src/main/res/values-v35/themes.xml" to fill(T_AI_THEMES35),
            "app/src/main/res/xml/accessibility_config.xml" to fill(T_AI_ACC_XML),
            "app/src/main/res/drawable/ic_launcher.xml" to fill(T_AI_ICON),
            "app/src/main/java/$pkgPath/AiControlService.kt" to fill(T_AI_CONTROL_SERVICE_KT),
            "app/src/main/java/$pkgPath/MainActivity.kt" to fill(T_AI_MAIN_ACTIVITY_KT),
            "app/src/main/assets/index.html" to fill(T_AI_APK_INDEX_HTML),
            "build-termux.sh" to customBuildSh
        )
    }

    /**
     * Generates a complete, studio-grade Website AI (`index.html`, `style.css`, `script.js`) with:
     * - Gemini Live WebSocket (`BidiGenerateContent`) real-time voice-to-voice + tool calling
     * - Gemini `streamGenerateContent` text/vision/code chat
     * - API Key manager + 1-click "Get API Key" button (`https://aistudio.google.com/app/apikey`)
     * - Live Screen Share reader (`getDisplayMedia`) + Camera Eye (`getUserMedia`) streaming frames to Gemini
     * - Live Code Generator & Self-Update system so the Website AI can build apps or modify its own UI/tools on user request!
     */
    fun aiWebsiteScaffold(
        slug: String,
        siteName: String,
        voice: String = "Aoede",
        persona: String = ""
    ): List<Pair<String, String>> {
        val defaultPersona = persona.ifBlank {
            "You are $siteName, an advanced, warm, ultra-fast AI assistant with Gemini Live voice, screen/camera vision, and live coding power. Speak the user's language naturally."
        }.replace("\"", "\\\"").replace("\n", " ")

        fun fill(s: String): String = s
            .replace("__NAME__", siteName)
            .replace("__SLUG__", slug)
            .replace("__VOICE__", voice.ifBlank { "Aoede" })
            .replace("__PERSONA__", defaultPersona)

        return listOf(
            "index.html" to fill(T_WEB_AI_INDEX_HTML),
            "style.css" to fill(T_WEB_AI_STYLE_CSS),
            "script.js" to fill(T_WEB_AI_SCRIPT_JS)
        )
    }

    private const val T_AI_SETTINGS = """
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "__SLUG__"
include(":app")
"""

    private const val T_AI_ROOT_GRADLE = """
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
"""

    private const val T_AI_PROPS = """
org.gradle.jvmargs=-Xmx1g -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
"""

    private const val T_AI_APP_GRADLE = """
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "__PKG__"
    compileSdk = 35
    defaultConfig {
        applicationId = "__PKG__"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-ALL-UNLOCKED"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
}
"""

    private const val T_AI_MANIFEST = """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.SEND_SMS" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
    <uses-permission android:name="android.permission.KILL_BACKGROUND_PROCESSES" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.WRITE_SETTINGS" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:usesCleartextTraffic="true"
        android:theme="@style/AppTheme">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".AiControlService"
            android:exported="true"
            android:label="@string/app_name"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_config" />
        </service>
    </application>
</manifest>
"""

    private const val T_AI_STRINGS = """
<resources>
    <string name="app_name">__NAME__</string>
    <string name="acc_desc">Allows __NAME__ to read the screen and control apps (open, close, tap, type, scroll) on your command.</string>
</resources>
"""

    private const val T_AI_THEMES = """
<resources>
    <style name="AppTheme" parent="@android:style/Theme.Material.NoActionBar">
        <item name="android:statusBarColor">#050B18</item>
        <item name="android:navigationBarColor">#050B18</item>
    </style>
</resources>
"""

    private const val T_AI_THEMES35 = """
<resources>
    <style name="AppTheme" parent="@android:style/Theme.Material.NoActionBar">
        <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>
        <item name="android:statusBarColor">#050B18</item>
        <item name="android:navigationBarColor">#050B18</item>
    </style>
</resources>
"""

    private const val T_AI_ACC_XML = """
<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagReportViewIds|flagIncludeNotImportantViews"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="true"
    android:canTakeScreenshot="true"
    android:description="@string/acc_desc"
    android:notificationTimeout="50" />
"""

    private const val T_AI_ICON = """
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path android:fillColor="#050B18" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#38B6FF" android:pathData="M54,54m-34,0a34,34 0,1 1,68 0a34,34 0,1 1,-68 0"/>
    <path android:fillColor="#050B18" android:pathData="M54,54m-24,0a24,24 0,1 1,48 0a24,24 0,1 1,-48 0"/>
    <path android:fillColor="#63D6A0" android:pathData="M54,54m-11,0a11,11 0,1 1,22 0a11,11 0,1 1,-22 0"/>
</vector>
"""

    private const val T_AI_CONTROL_SERVICE_KT = """
package __PKG__

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * All-Unlocked Accessibility Service for __NAME__:
 * - Reads live screen hierarchy (`dumpScreen`) with labels and [x,y] coordinates
 * - Performs physical taps (`tap`), element clicks (`clickText`), typing (`typeText`), scrolling (`scroll`), and swipes (`swipe`)
 * - Presses system keys (`back`, `home`, `recents`, `notifications`, `quick_settings`, `lock_screen`)
 * - Captures live screen JPEGs (`takeScreenshotBase64`) on Android 11+ so Gemini Live can see the screen!
 */
class AiControlService : AccessibilityService() {
    companion object {
        @Volatile var inst: AiControlService? = null
        @Volatile var fgPkg: String = ""
        private val shotExec = Executors.newSingleThreadExecutor()
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { if (inst === this) inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val p = event?.packageName?.toString() ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && p != "com.android.systemui" && p != packageName) {
            fgPkg = p
        }
    }

    fun dumpScreen(maxNodes: Int = 90): String {
        val root = try { rootInActiveWindow } catch (_: Throwable) { null }
            ?: return "No active screen window (enable Accessibility Service or unlock phone)."
        val dm = resources.displayMetrics
        val sb = StringBuilder("screen=${'$'}{dm.widthPixels}x${'$'}{dm.heightPixels} app=${'$'}{root.packageName}\n")
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, parentClick: Boolean) {
            if (n == null || count >= maxNodes) return
            if (!n.isVisibleToUser) return
            val click = (n.isClickable && n.isEnabled) || parentClick
            val label = (n.text ?: n.contentDescription ?: if (Build.VERSION.SDK_INT >= 26) n.hintText else null)
                ?.toString()?.replace("\n", " ")?.trim()?.take(80).orEmpty()
            val idName = try { n.viewIdResourceName?.substringAfter(":id/").orEmpty() } catch (_: Throwable) { "" }
            val text = label.ifEmpty { if (click) idName else "" }
            if (text.isNotEmpty() || n.isEditable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) {
                    sb.append("[${'$'}{r.centerX()},${'$'}{r.centerY()}] ")
                    if (text.isNotEmpty()) sb.append("\"${'$'}text\"")
                    if (click) sb.append(" click")
                    if (n.isEditable) sb.append(" edit")
                    if (n.isScrollable) sb.append(" scroll")
                    sb.append("\n")
                    count++
                }
            }
            for (i in 0 until n.childCount) {
                walk(try { n.getChild(i) } catch (_: Throwable) { null }, click)
            }
        }
        walk(root, false)
        return sb.toString()
    }

    fun tap(x: Float, y: Float, durationMs: Long = 45L): Boolean {
        val dm = resources.displayMetrics
        val px = (if (x in 0.001f..1.0f && y in 0.001f..1.0f) x * dm.widthPixels else x).coerceIn(1f, (dm.widthPixels - 1).toFloat())
        val py = (if (x in 0.001f..1.0f && y in 0.001f..1.0f) y * dm.heightPixels else y).coerceIn(1f, (dm.heightPixels - 1).toFloat())
        val path = Path().apply { moveTo(px, py) }
        return runGesture(path, durationMs)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 260L): Boolean {
        val dm = resources.displayMetrics
        val frac = x1 in 0f..1f && y1 in 0f..1f && x2 in 0f..1f && y2 in 0f..1f
        val sx = if (frac) dm.widthPixels.toFloat() else 1f
        val sy = if (frac) dm.heightPixels.toFloat() else 1f
        val path = Path().apply {
            moveTo((x1 * sx).coerceIn(1f, dm.widthPixels - 1f), (y1 * sy).coerceIn(1f, dm.heightPixels - 1f))
            lineTo((x2 * sx).coerceIn(1f, dm.widthPixels - 1f), (y2 * sy).coerceIn(1f, dm.heightPixels - 1f))
        }
        return runGesture(path, durationMs.coerceIn(40L, 4000L))
    }

    fun scroll(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction.lowercase().trim()) {
            "up" -> swipe(w * 0.5f, h * 0.25f, w * 0.5f, h * 0.75f, 260L)
            "left" -> swipe(w * 0.82f, h * 0.5f, w * 0.18f, h * 0.5f, 260L)
            "right" -> swipe(w * 0.18f, h * 0.5f, w * 0.82f, h * 0.5f, 260L)
            else -> swipe(w * 0.5f, h * 0.75f, w * 0.5f, h * 0.25f, 260L)
        }
    }

    private fun runGesture(path: Path, dur: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur.coerceAtLeast(10L)))
            .build()
        val posted = try {
            dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
            }, null)
        } catch (_: Throwable) { false }
        if (posted) latch.await(dur + 2000L, TimeUnit.MILLISECONDS)
        return ok
    }

    fun clickText(query: String): Boolean {
        val q = query.trim()
        if (q.isEmpty()) return false
        val root = try { rootInActiveWindow } catch (_: Throwable) { null } ?: return false
        val hits = try { root.findAccessibilityNodeInfosByText(q) } catch (_: Throwable) { emptyList() }
        var target: AccessibilityNodeInfo? = hits.firstOrNull { it.isVisibleToUser }
        if (target == null) {
            fun scan(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (n == null || !n.isVisibleToUser) return null
                val lbl = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
                if (lbl.contains(q, ignoreCase = true)) return n
                for (i in 0 until n.childCount) {
                    scan(try { n.getChild(i) } catch (_: Throwable) { null })?.let { return it }
                }
                return null
            }
            target = scan(root)
        }
        val node = target ?: return false
        var c: AccessibilityNodeInfo? = node
        var depth = 0
        while (c != null && !c.isClickable && depth < 5) {
            c = try { c.parent } catch (_: Throwable) { null }
            depth++
        }
        if (c != null && c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.isEmpty) return tap(r.exactCenterX(), r.exactCenterY())
        return false
    }

    fun typeText(text: String, submit: Boolean): Boolean {
        val root = try { rootInActiveWindow } catch (_: Throwable) { null } ?: return false
        var edit = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
        if (edit == null) {
            fun findEdit(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (n == null) return null
                if (n.isEditable && n.isVisibleToUser) return n
                for (i in 0 until n.childCount) {
                    findEdit(try { n.getChild(i) } catch (_: Throwable) { null })?.let { return it }
                }
                return null
            }
            edit = findEdit(root)
        }
        if (edit == null) {
            // Try clicking search bar trigger first
            clickText("Search") || clickText("সার্চ") || clickText("Message")
            try { Thread.sleep(150) } catch (_: Throwable) {}
            val r2 = try { rootInActiveWindow } catch (_: Throwable) { null }
            edit = r2?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        }
        val node = edit ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            try { Thread.sleep(60) } catch (_: Throwable) {}
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun pressKey(key: String): Boolean = when (key.lowercase().trim()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock_screen", "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
        else -> false
    }

    fun takeScreenshotBase64(): String {
        if (Build.VERSION.SDK_INT < 30) return ""
        val latch = CountDownLatch(1)
        var b64 = ""
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        val sw = bmp?.copy(Bitmap.Config.ARGB_8888, false)
                        bmp?.recycle()
                        hb.close()
                        if (sw != null) {
                            val scale = 720f / maxOf(sw.width, sw.height, 1)
                            val scaled = if (scale < 1f) Bitmap.createScaledBitmap(sw, (sw.width * scale).toInt(), (sw.height * scale).toInt(), true) else sw
                            val out = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 65, out)
                            if (scaled !== sw) scaled.recycle()
                            sw.recycle()
                            b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                        }
                    } catch (_: Throwable) {}
                    latch.countDown()
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
            latch.await(1500, TimeUnit.MILLISECONDS)
        } catch (_: Throwable) {}
        return b64
    }
}
"""

    private const val T_AI_MAIN_ACTIVITY_KT = """
package __PKG__

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * MainActivity for __NAME__ (100% All-Unlocked AI Assistant APK).
 * Exposes `window.AndroidBridge` to the AI WebView so Gemini Live and the user can:
 * - Open any app (`openApp`) or close any app (`closeApp`)
 * - Read the live screen (`getScreen`) and capture screen vision (`captureScreenJpeg`)
 * - Tap, click text, type text, swipe, scroll, press system keys
 * - Control volume, brightness, flashlight, phone calls, SMS, and clipboard
 * - Save and load self-updated AI code so the user can upgrade the APK anytime!
 */
class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePerms()
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }
        setContentView(web)

        val customHtml = getSharedPreferences("ai_self_update", Context.MODE_PRIVATE).getString("custom_index_html", null)
        if (!customHtml.isNullOrBlank()) {
            web.loadDataWithBaseURL("file:///android_asset/", customHtml, "text/html", "UTF-8", null)
        } else {
            web.loadUrl("file:///android_asset/index.html")
        }
    }

    private fun requestRuntimePerms() {
        val perms = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            try { requestPermissions(missing.toTypedArray(), 101) } catch (_: Throwable) {}
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class AndroidBridge(private val ctx: Context) {
        private val aliases = mapOf(
            "হোয়াটসঅ্যাপ" to "whatsapp", "ফেসবুক" to "facebook", "মেসেঞ্জার" to "messenger",
            "ইউটিউব" to "youtube", "ক্রোম" to "chrome", "ব্রাউজার" to "chrome",
            "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "সেটিংস" to "settings",
            "টেলিগ্রাম" to "telegram", "ইনস্টাগ্রাম" to "instagram", "জিমেইল" to "gmail",
            "ফোন" to "phone", "ক্যালকুলেটর" to "calculator", "টার্মাক্স" to "termux",
            "প্লে স্টোর" to "play store", "বিকাশ" to "bkash", "নগদ" to "nagad",
            "yt" to "youtube", "fb" to "facebook", "wa" to "whatsapp", "ig" to "instagram"
        )

        @JavascriptInterface
        fun isAccessibilityConnected(): Boolean = AiControlService.inst != null

        @JavascriptInterface
        fun openAccessibilitySettings() {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {}
        }

        @JavascriptInterface
        fun openUrl(url: String): String {
            return try {
                val u = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://${'$'}url"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                JSONObject().put("ok", true).put("url", u).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Could not open URL").toString()
            }
        }

        @JavascriptInterface
        fun openApiKeyPage(): String = openUrl("https://aistudio.google.com/app/apikey")

        @JavascriptInterface
        fun openApp(rawName: String): String {
            val q0 = rawName.trim().lowercase()
            if (q0.isEmpty()) return JSONObject().put("ok", false).put("error", "App name is empty").toString()
            val q = aliases[q0] ?: q0
            val pm = ctx.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
            val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().startsWith(q) }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(q.replace(" ", "")) }
                ?: return JSONObject().put("ok", false).put("error", "No installed app matches '${'$'}rawName'").toString()

            return try {
                val label = match.loadLabel(pm).toString()
                val pkg = match.activityInfo.packageName
                val comp = ComponentName(pkg, match.activityInfo.name)
                val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(comp)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                (AiControlService.inst ?: ctx).startActivity(launch)
                JSONObject().put("ok", true).put("opened", label).put("package", pkg).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Failed to launch app").toString()
            }
        }

        @JavascriptInterface
        fun closeApp(rawName: String): String {
            val q0 = rawName.trim().lowercase()
            val q = aliases[q0] ?: q0
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val pm = ctx.packageManager
            var targetPkg = AiControlService.fgPkg
            if (q.isNotEmpty() && q != "current" && q != "this") {
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
                val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) || it.activityInfo.packageName.lowercase().contains(q) }
                if (hit != null) targetPkg = hit.activityInfo.packageName
            }
            val acc = AiControlService.inst
            val wentHome = acc?.pressKey("home") ?: false
            if (targetPkg.isNotEmpty() && targetPkg != ctx.packageName) {
                try { am?.killBackgroundProcesses(targetPkg) } catch (_: Throwable) {}
            }
            return JSONObject()
                .put("ok", true)
                .put("closed_package", targetPkg.ifEmpty { "foreground_app" })
                .put("went_home", wentHome)
                .put("note", "Navigated Home and stopped background processes for ${'$'}{targetPkg.ifEmpty { rawName }}.")
                .toString()
        }

        @JavascriptInterface
        fun listApps(): String {
            val pm = ctx.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            val arr = JSONArray()
            apps.map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
                .take(80)
                .forEach { (label, pkg) ->
                    arr.put(JSONObject().put("name", label).put("package", pkg))
                }
            return JSONObject().put("ok", true).put("apps", arr).toString()
        }

        @JavascriptInterface
        fun getScreen(): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF. Tap 'Enable Screen Control' first.").toString()
            return JSONObject().put("ok", true).put("screen", acc.dumpScreen(95)).put("foreground_package", AiControlService.fgPkg).toString()
        }

        @JavascriptInterface
        fun captureScreenJpeg(): String {
            val acc = AiControlService.inst ?: return ""
            return acc.takeScreenshotBase64()
        }

        @JavascriptInterface
        fun clickText(text: String): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.clickText(text)
            try { Thread.sleep(160) } catch (_: Throwable) {}
            return JSONObject().put("ok", ok).put("clicked", text).put("screen", acc.dumpScreen(60)).toString()
        }

        @JavascriptInterface
        fun tap(x: Float, y: Float): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.tap(x, y)
            try { Thread.sleep(160) } catch (_: Throwable) {}
            return JSONObject().put("ok", ok).put("x", x).put("y", y).put("screen", acc.dumpScreen(60)).toString()
        }

        @JavascriptInterface
        fun typeText(text: String, submit: Boolean): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.typeText(text, submit)
            try { Thread.sleep(160) } catch (_: Throwable) {}
            return JSONObject().put("ok", ok).put("typed", text).put("submitted", submit).put("screen", acc.dumpScreen(60)).toString()
        }

        @JavascriptInterface
        fun scroll(direction: String): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.scroll(direction)
            try { Thread.sleep(200) } catch (_: Throwable) {}
            return JSONObject().put("ok", ok).put("direction", direction).put("screen", acc.dumpScreen(60)).toString()
        }

        @JavascriptInterface
        fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Int): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.swipe(x1, y1, x2, y2, durationMs.toLong())
            try { Thread.sleep(180) } catch (_: Throwable) {}
            return JSONObject().put("ok", ok).put("screen", acc.dumpScreen(60)).toString()
        }

        @JavascriptInterface
        fun pressKey(key: String): String {
            val acc = AiControlService.inst
                ?: return JSONObject().put("ok", false).put("error", "Accessibility Service is OFF.").toString()
            val ok = acc.pressKey(key)
            return JSONObject().put("ok", ok).put("key", key).toString()
        }

        @JavascriptInterface
        fun setVolume(streamName: String, percent: Int): String {
            return try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val stream = when (streamName.lowercase().trim()) {
                    "ring", "ringtone" -> AudioManager.STREAM_RING
                    "alarm" -> AudioManager.STREAM_ALARM
                    "notification" -> AudioManager.STREAM_NOTIFICATION
                    "call", "voice" -> AudioManager.STREAM_VOICE_CALL
                    else -> AudioManager.STREAM_MUSIC
                }
                val max = am.getStreamMaxVolume(stream)
                val target = ((percent.coerceIn(0, 100) / 100.0) * max).roundToInt().coerceIn(0, max)
                am.setStreamVolume(stream, target, AudioManager.FLAG_SHOW_UI)
                JSONObject().put("ok", true).put("stream", streamName).put("percent", percent).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Volume error").toString()
            }
        }

        @JavascriptInterface
        fun setBrightness(percent: Int): String {
            return try {
                if (!Settings.System.canWrite(ctx)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${'$'}packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return JSONObject().put("ok", false).put("error", "Allow 'Modify system settings' permission first (opened settings).").toString()
                }
                val v = ((percent.coerceIn(1, 100) / 100.0) * 255).roundToInt().coerceIn(1, 255)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                JSONObject().put("ok", true).put("percent", percent).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Brightness error").toString()
            }
        }

        @JavascriptInterface
        fun setFlashlight(on: Boolean): String {
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull() ?: return JSONObject().put("ok", false).put("error", "No camera flash").toString()
                cm.setTorchMode(id, on)
                JSONObject().put("ok", true).put("flashlight", on).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Flashlight error").toString()
            }
        }

        @JavascriptInterface
        fun callNumber(number: String): String {
            return try {
                val clean = number.trim()
                val canCall = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", clean, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                JSONObject().put("ok", true).put("number", clean).put("direct_call", canCall).toString()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("error", e.message ?: "Call failed").toString()
            }
        }

        @JavascriptInterface
        fun deviceInfo(): String {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val battery = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            return JSONObject()
                .put("ok", true)
                .put("model", "${'$'}{Build.MANUFACTURER} ${'$'}{Build.MODEL}")
                .put("android", Build.VERSION.RELEASE)
                .put("battery_percent", battery)
                .put("accessibility_on", AiControlService.inst != null)
                .put("foreground_app", AiControlService.fgPkg)
                .toString()
        }

        @JavascriptInterface
        fun copyToClipboard(text: String): String {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            cm?.setPrimaryClip(ClipData.newPlainText("AI", text))
            return JSONObject().put("ok", true).toString()
        }

        @JavascriptInterface
        fun saveSelfUpdateHtml(html: String): String {
            if (html.length < 100 || !html.contains("<html", ignoreCase = true)) {
                return JSONObject().put("ok", false).put("error", "Invalid HTML content").toString()
            }
            ctx.getSharedPreferences("ai_self_update", Context.MODE_PRIVATE).edit().putString("custom_index_html", html).apply()
            runOnUiThread {
                web.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
            }
            return JSONObject().put("ok", true).put("note", "Self-update applied and reloaded live!").toString()
        }

        @JavascriptInterface
        fun resetSelfUpdate(): String {
            ctx.getSharedPreferences("ai_self_update", Context.MODE_PRIVATE).edit().remove("custom_index_html").apply()
            runOnUiThread { web.loadUrl("file:///android_asset/index.html") }
            return JSONObject().put("ok", true).toString()
        }
    }
}
"""

    // ====================================================================================================
    // COMPLETE HTML/CSS/JS FOR THE GENERATED AI APK (app/src/main/assets/index.html)
    // ====================================================================================================
    private const val T_AI_APK_INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>__NAME__ — All-Unlocked AI Assistant</title>
<style>
:root {
  --bg: #030914;
  --card: #09152B;
  --card-hi: #0E2042;
  --line: #1B3B75;
  --cyan: #38B6FF;
  --blue: #2F6BFF;
  --violet: #8A6CFF;
  --green: #63D6A0;
  --amber: #F0BE6A;
  --red: #EA6F66;
  --text: #EAF2FF;
  --muted: #8DA2C8;
}
* { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: radial-gradient(circle at 50% 12%, #0E254C 0%, var(--bg) 65%);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  overflow-x: hidden;
}
header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 14px; background: rgba(9, 21, 43, 0.88);
  border-bottom: 1px solid var(--line); backdrop-filter: blur(10px);
  position: sticky; top: 0; z-index: 20;
}
.brand { display: flex; align-items: center; gap: 10px; }
.brand-dot {
  width: 12px; height: 12px; border-radius: 50%;
  background: var(--green); box-shadow: 0 0 12px var(--green);
}
.brand-title { font-size: 17px; font-weight: 800; letter-spacing: 0.4px; }
.badge-unlocked {
  font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 99px;
  background: rgba(99, 214, 160, 0.16); color: var(--green); border: 1px solid rgba(99, 214, 160, 0.45);
}
.top-actions { display: flex; gap: 6px; }
.pill {
  padding: 6px 12px; border-radius: 99px; font-size: 11px; font-weight: 600;
  background: var(--card); color: var(--text); border: 1px solid var(--line);
  cursor: pointer; transition: 0.18s;
}
.pill.active, .pill.primary {
  background: rgba(56, 182, 255, 0.2); border-color: var(--cyan); color: var(--cyan);
}
.pill.green {
  background: rgba(99, 214, 160, 0.18); border-color: var(--green); color: var(--green);
}
.pill.amber {
  background: rgba(240, 190, 106, 0.18); border-color: var(--amber); color: var(--amber);
}
.tabs {
  display: flex; gap: 6px; padding: 8px 12px; overflow-x: auto;
  background: rgba(5, 12, 26, 0.75); border-bottom: 1px solid rgba(27, 59, 117, 0.5);
}
main { flex: 1; padding: 14px; display: flex; flex-direction: column; gap: 12px; max-width: 760px; width: 100%; margin: 0 auto; }
.panel { display: none; flex-direction: column; gap: 12px; flex: 1; }
.panel.active { display: flex; }
.card {
  background: rgba(9, 21, 43, 0.85); border: 1px solid var(--line);
  border-radius: 16px; padding: 14px; display: flex; flex-direction: column; gap: 10px;
}
.orb-wrap {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 22px 10px; gap: 14px;
}
.orb {
  width: 132px; height: 132px; border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #7FD6FF, var(--cyan) 45%, var(--blue) 78%, #07132B 100%);
  box-shadow: 0 0 38px rgba(56, 182, 255, 0.45), inset 0 0 22px rgba(255,255,255,0.35);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; transition: transform 0.25s ease, box-shadow 0.25s ease;
  position: relative;
}
.orb.live {
  animation: pulseOrb 1.6s infinite ease-in-out;
  background: radial-gradient(circle at 35% 30%, #99FFE0, var(--green) 45%, var(--cyan) 80%, #07132B 100%);
  box-shadow: 0 0 52px rgba(99, 214, 160, 0.65), inset 0 0 25px rgba(255,255,255,0.45);
}
@keyframes pulseOrb {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.08); }
}
.orb-label { font-size: 13px; font-weight: 700; color: var(--cyan); text-align: center; }
.status-line { font-size: 12px; color: var(--muted); text-align: center; min-height: 18px; }
.controls-row { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; }
.btn {
  padding: 10px 16px; border-radius: 99px; font-size: 13px; font-weight: 700;
  border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;
  background: linear-gradient(90deg, var(--cyan), var(--blue)); color: #020916;
}
.btn.stop { background: linear-gradient(90deg, var(--red), #C83E37); color: #fff; }
.btn.secondary { background: var(--card-hi); color: var(--text); border: 1px solid var(--line); }
.chat-box {
  flex: 1; min-height: 250px; max-height: 52vh; overflow-y: auto;
  display: flex; flex-direction: column; gap: 8px; padding: 8px;
  background: rgba(3, 9, 20, 0.65); border-radius: 12px; border: 1px solid rgba(27, 59, 117, 0.6);
}
.msg { padding: 9px 12px; border-radius: 12px; font-size: 13px; line-height: 1.45; max-width: 88%; word-wrap: break-word; }
.msg.user { align-self: flex-end; background: rgba(47, 107, 255, 0.28); border: 1px solid var(--blue); }
.msg.ai { align-self: flex-start; background: var(--card-hi); border: 1px solid var(--line); }
.msg.sys { align-self: center; font-size: 11px; color: var(--amber); background: rgba(240, 190, 106, 0.1); border: 1px solid rgba(240, 190, 106, 0.35); }
.input-row { display: flex; gap: 8px; }
input, textarea, select {
  width: 100%; padding: 10px 12px; border-radius: 12px; border: 1px solid var(--line);
  background: #040C1C; color: var(--text); font-size: 13px; outline: none;
}
input:focus, textarea:focus, select:focus { border-color: var(--cyan); }
.grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.code-area {
  font-family: monospace; font-size: 12px; background: #02060F; color: #63D6A0;
  padding: 10px; border-radius: 10px; border: 1px solid var(--line); min-height: 180px; white-space: pre-wrap; overflow-x: auto;
}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="brand-dot" id="connDot"></div>
    <div>
      <div class="brand-title" id="appTitle">__NAME__</div>
      <div style="font-size:10px;color:var(--muted)" id="subStatus">Gemini Live • Phone Control • All Unlocked</div>
    </div>
  </div>
  <div class="top-actions">
    <span class="badge-unlocked">ALL UNLOCKED</span>
    <button class="pill amber" onclick="switchTab('key')">🔑 API Key</button>
  </div>
</header>

<div class="tabs">
  <button class="pill active" id="tabBtn-live" onclick="switchTab('live')">🎙️ Live Voice & Vision</button>
  <button class="pill" id="tabBtn-chat" onclick="switchTab('chat')">💬 AI Chat</button>
  <button class="pill" id="tabBtn-phone" onclick="switchTab('phone')">📱 Phone Control</button>
  <button class="pill" id="tabBtn-code" onclick="switchTab('code')">⚡ Coding & Self-Update</button>
  <button class="pill" id="tabBtn-key" onclick="switchTab('key')">🔑 Get Key / Setup</button>
</div>

<main>
  <!-- TAB 1: GEMINI LIVE VOICE + SCREEN VISION -->
  <section class="panel active" id="panel-live">
    <div class="card orb-wrap">
      <div class="orb" id="liveOrb" onclick="toggleGeminiLive()">
        <span style="font-size:32px" id="orbIcon">🎙️</span>
      </div>
      <div class="orb-label" id="liveTitle">Tap Orb to Start Gemini Live Voice</div>
      <div class="status-line" id="liveStatus">Ready • Real-Time Voice + Screen Reader + Phone Control</div>
      <div class="controls-row">
        <button class="btn" id="startLiveBtn" onclick="toggleGeminiLive()">▶ Start Live Session</button>
        <button class="pill green" id="screenShareBtn" onclick="toggleScreenReadStream()">👁️ Screen Read: OFF</button>
        <button class="pill" id="camShareBtn" onclick="toggleCameraStream()">📷 Camera Eye: OFF</button>
      </div>
      <video id="camPreview" autoplay playsinline muted style="display:none;width:180px;border-radius:12px;border:1px solid var(--cyan)"></video>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <strong style="font-size:13px;color:var(--cyan)">Live Conversation & Tool Log</strong>
        <button class="pill" onclick="readScreenNowAndExplain()">🔍 Read Current Screen</button>
      </div>
      <div class="chat-box" id="liveLog">
        <div class="msg sys">Welcome to __NAME__! All phone controls, screen reading, and live coding features are 100% unlocked. Set your Gemini API key in the 🔑 tab and tap the Orb!</div>
      </div>
      <div class="input-row">
        <input type="text" id="liveQuickInput" placeholder="Send text or command to Live session (e.g. Open WhatsApp)..." onkeydown="if(event.key==='Enter')sendLiveText()">
        <button class="btn" onclick="sendLiveText()">Send</button>
      </div>
    </div>
  </section>

  <!-- TAB 2: TEXT & VISION CHAT -->
  <section class="panel" id="panel-chat">
    <div class="card" style="flex:1">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <strong style="font-size:14px;color:var(--cyan)">AI Chat + Smart Phone Executor</strong>
        <button class="pill" onclick="clearChat()">Clear</button>
      </div>
      <div class="chat-box" id="chatBox"></div>
      <div class="input-row">
        <input type="text" id="chatInput" placeholder="Ask anything or say 'Open YouTube', 'Read screen', 'Build calculator'..." onkeydown="if(event.key==='Enter')sendChatMessage()">
        <button class="btn" onclick="sendChatMessage()">Send</button>
      </div>
    </div>
  </section>

  <!-- TAB 3: ALL-UNLOCKED PHONE CONTROL & SCREEN READER -->
  <section class="panel" id="panel-phone">
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong style="font-size:14px;color:var(--green)">Accessibility Screen Reader & Phone Control</strong>
          <div style="font-size:11px;color:var(--muted)" id="accStatusText">Checking accessibility status...</div>
        </div>
        <button class="pill green" onclick="enableAccessibility()">⚙️ Enable Screen Control</button>
      </div>
      <div class="input-row">
        <input type="text" id="appOpenInput" placeholder="App name to Open or Close (e.g. WhatsApp, YouTube, Chrome)...">
        <button class="pill green" onclick="openAppManual()">Open App</button>
        <button class="pill amber" onclick="closeAppManual()">Close App</button>
      </div>
      <div class="grid-2">
        <button class="btn secondary" onclick="dumpScreenManual()">📋 Read Screen Tree</button>
        <button class="btn secondary" onclick="pressSystemKey('home')">🏠 Home Key</button>
        <button class="btn secondary" onclick="pressSystemKey('back')">🔙 Back Key</button>
        <button class="btn secondary" onclick="pressSystemKey('recents')">🗂️ Recents</button>
        <button class="btn secondary" onclick="pressSystemKey('notifications')">🔔 Notifications</button>
        <button class="btn secondary" onclick="pressSystemKey('lock_screen')">🔒 Lock Screen</button>
      </div>
      <div class="grid-2">
        <button class="pill" onclick="setPhoneVolume(80)">🔊 Volume 80%</button>
        <button class="pill" onclick="setPhoneBrightness(85)">☀️ Brightness 85%</button>
        <button class="pill" onclick="toggleFlash(true)">🔦 Flash ON</button>
        <button class="pill" onclick="toggleFlash(false)">🌑 Flash OFF</button>
      </div>
      <pre class="code-area" id="screenDumpArea">Screen hierarchy will appear here when read...</pre>
    </div>
  </section>

  <!-- TAB 4: LIVE CODING & SELF-UPDATE SYSTEM -->
  <section class="panel" id="panel-code">
    <div class="card">
      <strong style="font-size:14px;color:var(--cyan)">⚡ AI Coding Studio & Self-Update System</strong>
      <p style="font-size:12px;color:var(--muted)">Ask __NAME__ to create a new web app/tool, OR tell it how to update/upgrade its own APK interface & features! Any error can be fixed automatically.</p>
      <textarea id="codePromptInput" rows="3" placeholder="Describe what to build, update, or fix (e.g. 'Add a floating calculator and neon cyberpunk theme to this AI' or 'Build a crypto tracker web app')..."></textarea>
      <div class="controls-row">
        <button class="btn" onclick="runAiCodeGenerator(false)">💻 Generate App / Code</button>
        <button class="pill green" onclick="runAiCodeGenerator(true)">🚀 Self-Update This AI APK</button>
        <button class="pill amber" onclick="fixGeneratedCode()">🔧 Auto-Fix Errors</button>
        <button class="pill" onclick="resetSelfUpdate()">↩️ Reset Default UI</button>
      </div>
      <pre class="code-area" id="generatedCodeView">// Generated or updated code will stream here...</pre>
      <iframe id="codePreviewFrame" style="width:100%;height:260px;border:1px solid var(--line);border-radius:12px;background:#fff;display:none"></iframe>
    </div>
  </section>

  <!-- TAB 5: API KEY + GET KEY SYSTEM + MODEL & PERSONA -->
  <section class="panel" id="panel-key">
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <strong style="font-size:15px;color:var(--amber)">🔑 Gemini API Key & Get Key System</strong>
        <button class="btn" onclick="getFreeApiKey()">🌐 Get Free API Key</button>
      </div>
      <p style="font-size:12px;color:var(--muted)">Paste your Google Gemini API key below. Don't have one? Tap <b>Get Free API Key</b> to create one in Google AI Studio in seconds.</p>
      <input type="password" id="apiKeyInput" placeholder="AIzaSy...">
      <div class="controls-row" style="justify-content:flex-start">
        <button class="btn" onclick="saveApiKey()">💾 Save API Key</button>
        <button class="pill green" onclick="testApiKey()">✅ Test Key</button>
        <button class="pill" onclick="toggleShowKey()">👁️ Show/Hide</button>
      </div>
      <div id="keyTestResult" style="font-size:12px;color:var(--green)"></div>
    </div>

    <div class="card">
      <strong style="font-size:14px;color:var(--cyan)">🎙️ Gemini Live Model, Voice & Persona</strong>
      <label style="font-size:11px;color:var(--muted)">Live Voice Model</label>
      <select id="liveModelSelect" onchange="saveSettings()">
        <option value="gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Flash Native Audio (Ultra Fast • Aoede)</option>
        <option value="gemini-3.1-flash-live-preview">Gemini 3.1 Flash Live Preview (Fast • Leda)</option>
      </select>
      <label style="font-size:11px;color:var(--muted)">Voice Name</label>
      <select id="voiceSelect" onchange="saveSettings()">
        <option value="Aoede">Aoede (Natural Breezy Female)</option>
        <option value="Leda">Leda (Youthful Cute Female)</option>
        <option value="Charon">Charon (Jarvis Smooth Male)</option>
        <option value="Fenrir">Fenrir (Deep Male)</option>
        <option value="Kore">Kore (Firm Female)</option>
        <option value="Puck">Puck (Lively)</option>
      </select>
      <label style="font-size:11px;color:var(--muted)">AI Personality & System Instructions (Editable anytime)</label>
      <textarea id="personaInput" rows="4" onchange="saveSettings()">__PERSONA__</textarea>
      <button class="pill green" onclick="saveSettings()">Save AI Settings</button>
    </div>
  </section>
</main>

<script>
// ============================================================================
// __NAME__ — ALL-UNLOCKED GEMINI LIVE + PHONE CONTROL + SELF-UPDATE ENGINE
// ============================================================================
const STORAGE_KEY_API = "nisu_gen_api_key";
const STORAGE_KEY_MODEL = "nisu_gen_live_model";
const STORAGE_KEY_VOICE = "nisu_gen_voice";
const STORAGE_KEY_PERSONA = "nisu_gen_persona";

let ws = null;
let isLive = false;
let audioCtx = null;
let micStream = null;
let micProcessor = null;
let nextPlayTime = 0;
let screenStreamTimer = null;
let camStreamTimer = null;
let camStream = null;
let lastGeneratedCode = "";

function hasAndroid() { return typeof window.AndroidBridge !== "undefined"; }

function initApp() {
  const savedKey = localStorage.getItem(STORAGE_KEY_API) || "";
  document.getElementById("apiKeyInput").value = savedKey;
  const savedModel = localStorage.getItem(STORAGE_KEY_MODEL) || "gemini-2.5-flash-native-audio-preview-12-2025";
  document.getElementById("liveModelSelect").value = savedModel;
  const savedVoice = localStorage.getItem(STORAGE_KEY_VOICE) || "__VOICE__";
  document.getElementById("voiceSelect").value = savedVoice;
  const savedPersona = localStorage.getItem(STORAGE_KEY_PERSONA);
  if (savedPersona) document.getElementById("personaInput").value = savedPersona;
  refreshAccStatus();
  setInterval(refreshAccStatus, 3000);
}

function refreshAccStatus() {
  const el = document.getElementById("accStatusText");
  if (!el) return;
  if (hasAndroid()) {
    const on = window.AndroidBridge.isAccessibilityConnected();
    el.textContent = on ? "✅ Connected — Full Screen Read & Phone Control Active" : "⚠️ Accessibility Service OFF — Tap 'Enable Screen Control' to unlock taps & screen read";
    el.style.color = on ? "var(--green)" : "var(--amber)";
  } else {
    el.textContent = "Browser Mode — Web tools active";
  }
}

function switchTab(tab) {
  ["live", "chat", "phone", "code", "key"].forEach(t => {
    document.getElementById("panel-" + t).classList.toggle("active", t === tab);
    const btn = document.getElementById("tabBtn-" + t);
    if (btn) btn.classList.toggle("active", t === tab);
  });
}

function getApiKey() {
  return (localStorage.getItem(STORAGE_KEY_API) || document.getElementById("apiKeyInput").value || "").trim();
}

function saveApiKey() {
  const k = document.getElementById("apiKeyInput").value.trim();
  localStorage.setItem(STORAGE_KEY_API, k);
  document.getElementById("keyTestResult").textContent = k ? "✅ API Key saved locally!" : "⚠️ Key cleared.";
}

function toggleShowKey() {
  const inp = document.getElementById("apiKeyInput");
  inp.type = inp.type === "password" ? "text" : "password";
}

function getFreeApiKey() {
  const url = "https://aistudio.google.com/app/apikey";
  if (hasAndroid()) window.AndroidBridge.openApiKeyPage();
  else window.open(url, "_blank");
}

async function testApiKey() {
  const key = getApiKey();
  const out = document.getElementById("keyTestResult");
  if (!key) { out.textContent = "❌ Please enter an API key first."; return; }
  out.textContent = "⏳ Testing Gemini API key...";
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=5&key=" + encodeURIComponent(key));
    if (r.ok) out.textContent = "✅ API Key is valid and ready for Gemini Live & Code Generation!";
    else out.textContent = "❌ Invalid key (HTTP " + r.status + "). Tap 'Get Free API Key' to create a valid key.";
  } catch (e) {
    out.textContent = "❌ Network error: " + e.message;
  }
}

function saveSettings() {
  localStorage.setItem(STORAGE_KEY_MODEL, document.getElementById("liveModelSelect").value);
  localStorage.setItem(STORAGE_KEY_VOICE, document.getElementById("voiceSelect").value);
  localStorage.setItem(STORAGE_KEY_PERSONA, document.getElementById("personaInput").value);
}

function logLive(role, text) {
  const box = document.getElementById("liveLog");
  const d = document.createElement("div");
  d.className = "msg " + role;
  d.textContent = text;
  box.appendChild(d);
  box.scrollTop = box.scrollHeight;
}

// ============================================================================
// PHONE CONTROL TOOLS DECLARATIONS FOR GEMINI LIVE
// ============================================================================
function getToolDeclarations() {
  return [{
    functionDeclarations: [
      {
        name: "open_app",
        description: "Open any installed Android app by its name (e.g. WhatsApp, YouTube, Chrome, Settings, Camera, Facebook).",
        parameters: { type: "OBJECT", properties: { name: { type: "STRING", description: "App name" } }, required: ["name"] }
      },
      {
        name: "close_app",
        description: "Close or stop an app (or the current foreground app) and return to the home screen.",
        parameters: { type: "OBJECT", properties: { name: { type: "STRING", description: "App name to close, or 'current'" } }, required: ["name"] }
      },
      {
        name: "get_screen",
        description: "Read all visible text, buttons, and [x,y] coordinates currently shown on the phone screen.",
        parameters: { type: "OBJECT", properties: {} }
      },
      {
        name: "click_text",
        description: "Tap the button or element on screen matching the given text or label.",
        parameters: { type: "OBJECT", properties: { text: { type: "STRING", description: "Visible label to tap" } }, required: ["text"] }
      },
      {
        name: "tap",
        description: "Tap at exact screen coordinates (x, y).",
        parameters: { type: "OBJECT", properties: { x: { type: "NUMBER" }, y: { type: "NUMBER" } }, required: ["x", "y"] }
      },
      {
        name: "type_text",
        description: "Type text into the focused input or search field on screen, and optionally submit/search.",
        parameters: { type: "OBJECT", properties: { text: { type: "STRING" }, submit: { type: "BOOLEAN" } }, required: ["text"] }
      },
      {
        name: "scroll",
        description: "Scroll the screen: down, up, left, or right.",
        parameters: { type: "OBJECT", properties: { direction: { type: "STRING", description: "down|up|left|right" } }, required: ["direction"] }
      },
      {
        name: "press_key",
        description: "Press a system navigation action: back, home, recents, notifications, quick_settings, lock_screen.",
        parameters: { type: "OBJECT", properties: { key: { type: "STRING" } }, required: ["key"] }
      },
      {
        name: "set_volume",
        description: "Set phone volume percentage (0-100) for media, ring, alarm, or call.",
        parameters: { type: "OBJECT", properties: { stream: { type: "STRING" }, percent: { type: "NUMBER" } }, required: ["percent"] }
      },
      {
        name: "set_brightness",
        description: "Set screen brightness percentage (1-100).",
        parameters: { type: "OBJECT", properties: { percent: { type: "NUMBER" } }, required: ["percent"] }
      },
      {
        name: "set_flashlight",
        description: "Turn the phone flashlight/torch ON or OFF.",
        parameters: { type: "OBJECT", properties: { on: { type: "BOOLEAN" } }, required: ["on"] }
      },
      {
        name: "call_number",
        description: "Place a phone call to a number.",
        parameters: { type: "OBJECT", properties: { number: { type: "STRING" } }, required: ["number"] }
      },
      {
        name: "open_url",
        description: "Open a website URL in the browser.",
        parameters: { type: "OBJECT", properties: { url: { type: "STRING" } }, required: ["url"] }
      },
      {
        name: "device_info",
        description: "Get live phone battery percentage, device model, Android version, and accessibility status.",
        parameters: { type: "OBJECT", properties: {} }
      },
      {
        name: "self_update_ai",
        description: "Update or add features to this AI app itself using the built-in coding engine.",
        parameters: { type: "OBJECT", properties: { instruction: { type: "STRING", description: "What to add, change, or fix" } }, required: ["instruction"] }
      }
    ]
  }];
}

async function executePhoneTool(name, args) {
  try {
    if (name === "self_update_ai") {
      document.getElementById("codePromptInput").value = args.instruction || "";
      runAiCodeGenerator(true);
      return { ok: true, note: "Started self-updating the AI app in the background." };
    }
    if (!hasAndroid()) {
      if (name === "open_url" && args.url) { window.open(args.url, "_blank"); return { ok: true }; }
      if (name === "get_screen") return { ok: true, screen: document.body.innerText.slice(0, 2000) };
      return { ok: false, error: "Native AndroidBridge is only available inside the installed APK." };
    }
    switch (name) {
      case "open_app": return JSON.parse(window.AndroidBridge.openApp(args.name || ""));
      case "close_app": return JSON.parse(window.AndroidBridge.closeApp(args.name || "current"));
      case "get_screen": return JSON.parse(window.AndroidBridge.getScreen());
      case "click_text": return JSON.parse(window.AndroidBridge.clickText(args.text || ""));
      case "tap": return JSON.parse(window.AndroidBridge.tap(Number(args.x || 0), Number(args.y || 0)));
      case "type_text": return JSON.parse(window.AndroidBridge.typeText(args.text || "", Boolean(args.submit)));
      case "scroll": return JSON.parse(window.AndroidBridge.scroll(args.direction || "down"));
      case "press_key": return JSON.parse(window.AndroidBridge.pressKey(args.key || "back"));
      case "set_volume": return JSON.parse(window.AndroidBridge.setVolume(args.stream || "media", Number(args.percent ?? 75)));
      case "set_brightness": return JSON.parse(window.AndroidBridge.setBrightness(Number(args.percent ?? 80)));
      case "set_flashlight": return JSON.parse(window.AndroidBridge.setFlashlight(Boolean(args.on)));
      case "call_number": return JSON.parse(window.AndroidBridge.callNumber(args.number || ""));
      case "open_url": return JSON.parse(window.AndroidBridge.openUrl(args.url || ""));
      case "device_info": return JSON.parse(window.AndroidBridge.deviceInfo());
      default: return { ok: false, error: "Unknown tool: " + name };
    }
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  }
}

// ============================================================================
// REAL-TIME GEMINI LIVE WEBSOCKET (AUDIO IN / AUDIO OUT / VISION / TOOLS)
// ============================================================================
async function toggleGeminiLive() {
  if (isLive) { stopGeminiLive(); return; }
  const key = getApiKey();
  if (!key) {
    switchTab("key");
    logLive("sys", "Please enter your Gemini API Key first (or tap 'Get Free API Key').");
    return;
  }
  const model = document.getElementById("liveModelSelect").value;
  const voice = document.getElementById("voiceSelect").value;
  const persona = document.getElementById("personaInput").value;

  document.getElementById("liveStatus").textContent = "Connecting to Gemini Live (" + model + ")...";
  const url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + encodeURIComponent(key);

  try {
    ws = new WebSocket(url);
    ws.onopen = () => {
      const genConfig = {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } }
      };
      if (model.includes("2.5")) genConfig.thinkingConfig = { thinkingBudget: 0 };
      const setupMsg = {
        setup: {
          model: "models/" + model,
          generationConfig: genConfig,
          systemInstruction: {
            parts: [{
              text: persona + "\nYou have full unlocked Android phone control tools (open_app, close_app, get_screen, click_text, tap, type_text, scroll, press_key, set_volume, set_brightness, set_flashlight, call_number, open_url, device_info, self_update_ai). Use them immediately whenever the user asks to control the phone, read the screen, or update your code."
            }]
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          tools: getToolDeclarations()
        }
      };
      ws.send(JSON.stringify(setupMsg));
    };

    ws.onmessage = async (ev) => {
      const raw = ev.data instanceof Blob ? await ev.data.text() : ev.data;
      let j;
      try { j = JSON.parse(raw); } catch (_) { return; }

      if (j.setupComplete) {
        isLive = true;
        document.getElementById("liveOrb").classList.add("live");
        document.getElementById("startLiveBtn").textContent = "⏹ Stop Live Session";
        document.getElementById("startLiveBtn").classList.add("stop");
        document.getElementById("liveTitle").textContent = "Listening Live (" + voice + ")...";
        document.getElementById("liveStatus").textContent = "Connected • Speak naturally in any language";
        startMicCapture();
        return;
      }

      if (j.serverContent) {
        const sc = j.serverContent;
        if (sc.interrupted) { nextPlayTime = audioCtx ? audioCtx.currentTime : 0; }
        if (sc.inputTranscription && sc.inputTranscription.text) {
          logLive("user", "You: " + sc.inputTranscription.text);
        }
        if (sc.outputTranscription && sc.outputTranscription.text) {
          logLive("ai", sc.outputTranscription.text);
        }
        if (sc.modelTurn && sc.modelTurn.parts) {
          for (const part of sc.modelTurn.parts) {
            if (part.inlineData && part.inlineData.data) {
              playPcm24kBase64(part.inlineData.data);
            }
          }
        }
      }

      if (j.toolCall && j.toolCall.functionCalls) {
        for (const fc of j.toolCall.functionCalls) {
          logLive("sys", "⚡ Tool: " + fc.name + "(" + JSON.stringify(fc.args || {}) + ")");
          const res = await executePhoneTool(fc.name, fc.args || {});
          if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              toolResponse: {
                functionResponses: [{ id: fc.id, name: fc.name, response: res }]
              }
            }));
          }
        }
      }
    };

    ws.onclose = (ev) => {
      stopGeminiLive("Disconnected (" + ev.code + ")");
    };
    ws.onerror = () => {
      stopGeminiLive("Connection error — check API key or internet.");
    };
  } catch (e) {
    stopGeminiLive("Error: " + e.message);
  }
}

function stopGeminiLive(reason) {
  isLive = false;
  if (ws) { try { ws.close(); } catch (_) {} ws = null; }
  if (micProcessor) { try { micProcessor.disconnect(); } catch (_) {} micProcessor = null; }
  if (micStream) { try { micStream.getTracks().forEach(t => t.stop()); } catch (_) {} micStream = null; }
  document.getElementById("liveOrb").classList.remove("live");
  document.getElementById("startLiveBtn").textContent = "▶ Start Live Session";
  document.getElementById("startLiveBtn").classList.remove("stop");
  document.getElementById("liveTitle").textContent = "Tap Orb to Start Gemini Live Voice";
  document.getElementById("liveStatus").textContent = reason || "Stopped";
}

async function startMicCapture() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    if (audioCtx.state === "suspended") await audioCtx.resume();
    micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
    const src = audioCtx.createMediaStreamSource(micStream);
    const proc = audioCtx.createScriptProcessor(2048, 1, 1);
    proc.onaudioprocess = (e) => {
      if (!isLive || !ws || ws.readyState !== WebSocket.OPEN) return;
      const input = e.inputBuffer.getChannelData(0);
      const pcm16 = downsampleTo16kPcm(input, audioCtx.sampleRate);
      const b64 = arrayBufferToBase64(pcm16.buffer);
      ws.send(JSON.stringify({
        realtimeInput: { audio: { mimeType: "audio/pcm;rate=16000", data: b64 } }
      }));
    };
    src.connect(proc);
    proc.connect(audioCtx.destination);
    micProcessor = proc;
  } catch (e) {
    logLive("sys", "Mic warning: " + e.message);
  }
}

function downsampleTo16kPcm(float32, inRate) {
  const ratio = inRate / 16000;
  const outLen = Math.floor(float32.length / ratio);
  const out = new Int16Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const s = Math.max(-1, Math.min(1, float32[Math.floor(i * ratio)]));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
  }
  return out;
}

function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

function playPcm24kBase64(b64) {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    const bin = atob(b64);
    const samples = Math.floor(bin.length / 2);
    const buf = audioCtx.createBuffer(1, samples, 24000);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < samples; i++) {
      const lo = bin.charCodeAt(i * 2);
      const hi = bin.charCodeAt(i * 2 + 1);
      let v = (hi << 8) | lo;
      if (v >= 0x8000) v -= 0x10000;
      ch[i] = v / 32768.0;
    }
    const src = audioCtx.createBufferSource();
    src.buffer = buf;
    src.connect(audioCtx.destination);
    const now = audioCtx.currentTime;
    if (nextPlayTime < now) nextPlayTime = now + 0.02;
    src.start(nextPlayTime);
    nextPlayTime += buf.duration;
  } catch (_) {}
}

function sendLiveText() {
  const inp = document.getElementById("liveQuickInput");
  const t = inp.value.trim();
  if (!t) return;
  inp.value = "";
  logLive("user", "You: " + t);
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      clientContent: { turns: [{ role: "user", parts: [{ text: t }] }], turnComplete: true }
    }));
  } else {
    document.getElementById("chatInput").value = t;
    switchTab("chat");
    sendChatMessage();
  }
}

// ============================================================================
// LIVE SCREEN STREAM & CAMERA STREAM TO GEMINI LIVE
// ============================================================================
function toggleScreenReadStream() {
  const btn = document.getElementById("screenShareBtn");
  if (screenStreamTimer) {
    clearInterval(screenStreamTimer);
    screenStreamTimer = null;
    btn.textContent = "👁️ Screen Read: OFF";
    return;
  }
  btn.textContent = "👁️ Screen Read: ON";
  screenStreamTimer = setInterval(() => {
    if (!isLive || !ws || ws.readyState !== WebSocket.OPEN || !hasAndroid()) return;
    const b64 = window.AndroidBridge.captureScreenJpeg();
    if (b64 && b64.length > 100) {
      ws.send(JSON.stringify({
        realtimeInput: { video: { mimeType: "image/jpeg", data: b64 } }
      }));
    }
  }, 1500);
}

async function toggleCameraStream() {
  const btn = document.getElementById("camShareBtn");
  const vid = document.getElementById("camPreview");
  if (camStreamTimer) {
    clearInterval(camStreamTimer);
    camStreamTimer = null;
    if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; }
    vid.style.display = "none";
    btn.textContent = "📷 Camera Eye: OFF";
    return;
  }
  try {
    camStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: 480, height: 360 } });
    vid.srcObject = camStream;
    vid.style.display = "block";
    btn.textContent = "📷 Camera Eye: ON";
    const canvas = document.createElement("canvas");
    canvas.width = 480; canvas.height = 360;
    const ctx2d = canvas.getContext("2d");
    camStreamTimer = setInterval(() => {
      if (!isLive || !ws || ws.readyState !== WebSocket.OPEN) return;
      ctx2d.drawImage(vid, 0, 0, canvas.width, canvas.height);
      const b64 = canvas.toDataURL("image/jpeg", 0.65).split(",")[1];
      ws.send(JSON.stringify({
        realtimeInput: { video: { mimeType: "image/jpeg", data: b64 } }
      }));
    }, 1400);
  } catch (e) {
    logLive("sys", "Camera error: " + e.message);
  }
}

async function readScreenNowAndExplain() {
  const res = await executePhoneTool("get_screen", {});
  const txt = res.screen || res.error || "No screen content";
  document.getElementById("screenDumpArea").textContent = txt;
  logLive("sys", "Screen Read:\n" + txt.slice(0, 500));
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      clientContent: {
        turns: [{ role: "user", parts: [{ text: "Here is what is currently on my phone screen:\n" + txt + "\nExplain what is on the screen briefly." }] }],
        turnComplete: true
      }
    }));
  }
}

// ============================================================================
// TEXT & FUNCTION-CALLING CHAT ENGINE
// ============================================================================
async function sendChatMessage() {
  const inp = document.getElementById("chatInput");
  const text = inp.value.trim();
  if (!text) return;
  inp.value = "";
  appendChat("user", text);

  const key = getApiKey();
  if (!key) {
    appendChat("sys", "Please set your Gemini API Key in the 🔑 tab first.");
    return;
  }
  const persona = document.getElementById("personaInput").value;
  try {
    const body = {
      systemInstruction: { parts: [{ text: persona + "\nWhen the user asks to perform a phone action (open app, close app, read screen, click, type, scroll, volume, brightness, flashlight, call), call the matching function tool immediately." }] },
      contents: [{ role: "user", parts: [{ text }] }],
      tools: getToolDeclarations()
    };
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const j = await r.json();
    const parts = j.candidates?.[0]?.content?.parts || [];
    for (const p of parts) {
      if (p.text) appendChat("ai", p.text);
      if (p.functionCall) {
        const fc = p.functionCall;
        appendChat("sys", "⚡ Running: " + fc.name + " " + JSON.stringify(fc.args || {}));
        const toolRes = await executePhoneTool(fc.name, fc.args || {});
        appendChat("ai", "✅ Done: " + JSON.stringify(toolRes));
      }
    }
  } catch (e) {
    appendChat("sys", "Error: " + e.message);
  }
}

function appendChat(role, text) {
  const box = document.getElementById("chatBox");
  const d = document.createElement("div");
  d.className = "msg " + role;
  d.textContent = text;
  box.appendChild(d);
  box.scrollTop = box.scrollHeight;
}
function clearChat() { document.getElementById("chatBox").innerHTML = ""; }

// ============================================================================
// MANUAL PHONE CONTROL PANEL HELPERS
// ============================================================================
function enableAccessibility() { if (hasAndroid()) window.AndroidBridge.openAccessibilitySettings(); }
async function openAppManual() {
  const name = document.getElementById("appOpenInput").value.trim();
  const r = await executePhoneTool("open_app", { name });
  document.getElementById("screenDumpArea").textContent = JSON.stringify(r, null, 2);
}
async function closeAppManual() {
  const name = document.getElementById("appOpenInput").value.trim() || "current";
  const r = await executePhoneTool("close_app", { name });
  document.getElementById("screenDumpArea").textContent = JSON.stringify(r, null, 2);
}
async function dumpScreenManual() {
  const r = await executePhoneTool("get_screen", {});
  document.getElementById("screenDumpArea").textContent = r.screen || JSON.stringify(r, null, 2);
}
async function pressSystemKey(key) { await executePhoneTool("press_key", { key }); }
async function setPhoneVolume(percent) { await executePhoneTool("set_volume", { stream: "media", percent }); }
async function setPhoneBrightness(percent) { await executePhoneTool("set_brightness", { percent }); }
async function toggleFlash(on) { await executePhoneTool("set_flashlight", { on }); }

// ============================================================================
// BUILT-IN CODING & SELF-UPDATE ENGINE (GENERATES APPS OR UPDATES THIS APK!)
// ============================================================================
async function runAiCodeGenerator(selfUpdate) {
  const key = getApiKey();
  if (!key) { switchTab("key"); return; }
  const req = document.getElementById("codePromptInput").value.trim();
  if (!req) return;
  const view = document.getElementById("generatedCodeView");
  view.textContent = "⏳ AI Coding Engine is writing complete code...";

  const sys = selfUpdate
    ? "You are the Self-Updating Coding Engine inside an Android AI Assistant WebView APK. You receive the current complete HTML/CSS/JS of the app and the user's update request. Return ONLY the complete, updated single-file <!DOCTYPE html> code with all existing Gemini Live, API Key, AndroidBridge Phone Control, and Self-Update features preserved plus the user's requested changes/features added. No markdown fences."
    : "You are a senior full-stack web & app developer. Write a complete, self-contained single-file <!DOCTYPE html> application with modern CSS and JavaScript fulfilling the user's request. Return ONLY the HTML code, no markdown fences.";

  const payloadText = selfUpdate
    ? "USER UPDATE REQUEST:\n" + req + "\n\nCURRENT APP HTML:\n" + document.documentElement.outerHTML
    : req;

  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: sys }] },
        contents: [{ role: "user", parts: [{ text: payloadText }] }]
      })
    });
    const j = await r.json();
    let code = j.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
    code = code.replace(/^```html\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/, "").trim();
    lastGeneratedCode = code;
    view.textContent = code;

    if (selfUpdate && code.includes("<html")) {
      if (hasAndroid()) {
        window.AndroidBridge.saveSelfUpdateHtml(code);
      } else {
        document.open(); document.write(code); document.close();
      }
    } else if (code.includes("<")) {
      const frame = document.getElementById("codePreviewFrame");
      frame.style.display = "block";
      frame.srcdoc = code;
    }
  } catch (e) {
    view.textContent = "❌ Coding error: " + e.message;
  }
}

async function fixGeneratedCode() {
  const prob = document.getElementById("codePromptInput").value.trim() || "Fix any bugs or layout issues and make all buttons work.";
  document.getElementById("codePromptInput").value = "FIX ERRORS: " + prob + "\n\nCODE TO FIX:\n" + (lastGeneratedCode || "current app");
  await runAiCodeGenerator(false);
}

function resetSelfUpdate() {
  if (hasAndroid()) window.AndroidBridge.resetSelfUpdate();
  else location.reload();
}

window.addEventListener("DOMContentLoaded", initApp);
</script>
</body>
</html>
"""

    // ====================================================================================================
    // COMPLETE WEBSITE AI TEMPLATE (index.html, style.css, script.js)
    // ====================================================================================================
    private const val T_WEB_AI_INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>__NAME__ — Gemini Live Website AI & Agent Studio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <span class="pulse-dot" id="liveDot"></span>
      <div>
        <h1>__NAME__</h1>
        <p class="subtitle">Gemini Live Voice • Screen & Camera Vision • Live Coding Studio</p>
      </div>
    </div>
    <div class="top-actions">
      <button class="btn-chip amber" onclick="openKeyModal()">🔑 API Key</button>
      <a class="btn-chip cyan" href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">⚡ Get Free API Key</a>
    </div>
  </header>

  <nav class="nav-tabs">
    <button class="tab-btn active" data-tab="voice" onclick="switchWebTab('voice')">🎙️ Gemini Live Voice & Vision</button>
    <button class="tab-btn" data-tab="chat" onclick="switchWebTab('chat')">💬 AI Chat & Tools</button>
    <button class="tab-btn" data-tab="code" onclick="switchWebTab('code')">💻 Live Coding & Self-Update</button>
    <button class="tab-btn" data-tab="settings" onclick="switchWebTab('settings')">⚙️ AI Settings & Key</button>
  </nav>

  <main class="container">
    <!-- TAB 1: GEMINI LIVE VOICE + SCREEN READ + CAMERA -->
    <section class="tab-panel active" id="tab-voice">
      <div class="glass-card hero-voice">
        <div class="voice-orb" id="webOrb" onclick="toggleWebLive()">
          <span id="webOrbIcon">🎙️</span>
        </div>
        <h2 id="webLiveTitle">Tap Orb to Start Gemini Live Voice</h2>
        <p id="webLiveStatus" class="muted">Real-time 16kHz/24kHz WebSocket Voice + Live Screen Reading + Camera Vision</p>
        <div class="action-row">
          <button class="btn-primary" id="webLiveBtn" onclick="toggleWebLive()">▶ Start Live AI</button>
          <button class="btn-secondary" id="webScreenBtn" onclick="toggleWebScreenShare()">🖥️ Read Screen: OFF</button>
          <button class="btn-secondary" id="webCamBtn" onclick="toggleWebCamera()">📷 Camera Eye: OFF</button>
        </div>
        <div class="media-preview-row">
          <video id="webScreenVideo" autoplay playsinline muted class="preview-video" style="display:none"></video>
          <video id="webCamVideo" autoplay playsinline muted class="preview-video" style="display:none"></video>
        </div>
      </div>

      <div class="glass-card">
        <div class="card-head">
          <h3>Live Transcript & Vision Stream</h3>
          <button class="btn-chip" onclick="analyzeCurrentScreenOnce()">🔍 Read & Analyze Screen Now</button>
        </div>
        <div class="stream-log" id="webLiveLog">
          <div class="bubble sys">Welcome to __NAME__! Click "🔑 API Key" or "⚡ Get Free API Key" to set your Gemini key, then tap the Orb to talk live or share your screen!</div>
        </div>
        <div class="input-bar">
          <input type="text" id="webLiveInput" placeholder="Type to Gemini Live or ask it to read screen / write code..." onkeydown="if(event.key==='Enter')sendWebLiveText()">
          <button class="btn-primary" onclick="sendWebLiveText()">Send</button>
        </div>
      </div>
    </section>

    <!-- TAB 2: MULTIMODAL CHAT -->
    <section class="tab-panel" id="tab-chat">
      <div class="glass-card">
        <div class="card-head">
          <h3>Multimodal AI Chat</h3>
          <button class="btn-chip" onclick="document.getElementById('webChatLog').innerHTML=''">Clear</button>
        </div>
        <div class="stream-log" id="webChatLog"></div>
        <div class="input-bar">
          <input type="text" id="webChatInput" placeholder="Ask anything, analyze screen, or request an update..." onkeydown="if(event.key==='Enter')sendWebChat()">
          <button class="btn-primary" onclick="sendWebChat()">Send</button>
        </div>
      </div>
    </section>

    <!-- TAB 3: LIVE CODING & SELF-UPDATE -->
    <section class="tab-panel" id="tab-code">
      <div class="glass-card">
        <h3>⚡ Live Coding Studio & Self-Update Engine</h3>
        <p class="muted">Ask __NAME__ to build a new web app, fix code errors, or self-update its own Website AI interface and features!</p>
        <textarea id="webCodePrompt" rows="3" placeholder="Describe what to build, update, or fix..."></textarea>
        <div class="action-row">
          <button class="btn-primary" onclick="generateWebCode(false)">🚀 Build App / Code</button>
          <button class="btn-chip green" onclick="generateWebCode(true)">✨ Self-Update This AI</button>
          <button class="btn-chip amber" onclick="autoFixWebCode()">🔧 Auto-Fix Errors</button>
        </div>
        <pre class="code-viewer" id="webCodeOutput">// Generated code will appear here...</pre>
        <iframe id="webCodePreview" class="preview-frame" title="Live Code Preview"></iframe>
      </div>
    </section>

    <!-- TAB 4: SETTINGS & API KEY -->
    <section class="tab-panel" id="tab-settings">
      <div class="glass-card">
        <div class="card-head">
          <h3>🔑 Gemini API Key & Get Key System</h3>
          <a class="btn-primary" href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">🌐 Get Free Gemini API Key</a>
        </div>
        <p class="muted">Your API key is stored locally in your browser's localStorage and connects directly to Google Gemini.</p>
        <input type="password" id="webApiKey" placeholder="Paste Gemini API Key (AIzaSy...)">
        <div class="action-row">
          <button class="btn-primary" onclick="saveWebApiKey()">💾 Save Key</button>
          <button class="btn-secondary" onclick="testWebApiKey()">✅ Test Key</button>
        </div>
        <p id="webKeyStatus" class="status-note"></p>
      </div>

      <div class="glass-card">
        <h3>🎙️ Model, Voice & Persona</h3>
        <label>Gemini Live Model</label>
        <select id="webModelSelect" onchange="saveWebSettings()">
          <option value="gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Flash Native Audio (Ultra Fast • Aoede)</option>
          <option value="gemini-3.1-flash-live-preview">Gemini 3.1 Flash Live Preview (Leda)</option>
        </select>
        <label>Voice</label>
        <select id="webVoiceSelect" onchange="saveWebSettings()">
          <option value="Aoede">Aoede (Natural Female)</option>
          <option value="Leda">Leda (Youthful Cute Female)</option>
          <option value="Charon">Charon (Jarvis Male)</option>
          <option value="Fenrir">Fenrir (Deep Male)</option>
          <option value="Kore">Kore (Firm Female)</option>
        </select>
        <label>System Persona Instructions</label>
        <textarea id="webPersonaInput" rows="4" onchange="saveWebSettings()">__PERSONA__</textarea>
      </div>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>
"""

    private const val T_WEB_AI_STYLE_CSS = """
:root {
  --bg: #030914;
  --surface: #09152B;
  --surface-hi: #102347;
  --border: #1C3D7A;
  --cyan: #38B6FF;
  --blue: #2F6BFF;
  --green: #63D6A0;
  --amber: #F0BE6A;
  --red: #EA6F66;
  --text: #EAF2FF;
  --muted: #8DA2C8;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: radial-gradient(circle at 50% 0%, #0E254C 0%, var(--bg) 70%);
  color: var(--text);
  min-height: 100vh;
}
.topbar {
  display: flex; justify-content: space-between; align-items: center;
  padding: 14px 20px; background: rgba(9, 21, 43, 0.9);
  border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 10;
}
.brand { display: flex; align-items: center; gap: 12px; }
.brand h1 { font-size: 19px; font-weight: 800; }
.subtitle { font-size: 11px; color: var(--muted); }
.pulse-dot { width: 12px; height: 12px; border-radius: 50%; background: var(--green); box-shadow: 0 0 12px var(--green); }
.top-actions { display: flex; gap: 8px; align-items: center; }
.nav-tabs {
  display: flex; gap: 8px; padding: 10px 20px; overflow-x: auto;
  background: rgba(4, 11, 24, 0.8); border-bottom: 1px solid rgba(28, 61, 122, 0.5);
}
.tab-btn, .btn-chip {
  padding: 7px 14px; border-radius: 99px; font-size: 12px; font-weight: 600;
  background: var(--surface); color: var(--text); border: 1px solid var(--border);
  cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;
}
.tab-btn.active, .btn-chip.cyan { background: rgba(56, 182, 255, 0.2); border-color: var(--cyan); color: var(--cyan); }
.btn-chip.amber { background: rgba(240, 190, 106, 0.18); border-color: var(--amber); color: var(--amber); }
.btn-chip.green { background: rgba(99, 214, 160, 0.18); border-color: var(--green); color: var(--green); }
.container { max-width: 900px; margin: 0 auto; padding: 18px; }
.tab-panel { display: none; flex-direction: column; gap: 16px; }
.tab-panel.active { display: flex; }
.glass-card {
  background: rgba(9, 21, 43, 0.86); border: 1px solid var(--border);
  border-radius: 18px; padding: 18px; display: flex; flex-direction: column; gap: 12px;
}
.hero-voice { align-items: center; text-align: center; padding: 28px 18px; }
.voice-orb {
  width: 138px; height: 138px; border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #8AE2FF, var(--cyan) 48%, var(--blue) 82%, #061229 100%);
  box-shadow: 0 0 42px rgba(56, 182, 255, 0.5);
  display: flex; align-items: center; justify-content: center; font-size: 38px;
  cursor: pointer; transition: 0.25s;
}
.voice-orb.live {
  animation: orbPulse 1.5s infinite ease-in-out;
  background: radial-gradient(circle at 35% 30%, #A6FFE2, var(--green) 48%, var(--cyan) 82%, #061229 100%);
  box-shadow: 0 0 58px rgba(99, 214, 160, 0.7);
}
@keyframes orbPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
.action-row { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
.btn-primary {
  padding: 10px 18px; border-radius: 99px; border: none; font-size: 13px; font-weight: 700;
  background: linear-gradient(90deg, var(--cyan), var(--blue)); color: #020A18; cursor: pointer; text-decoration: none;
}
.btn-secondary {
  padding: 10px 16px; border-radius: 99px; border: 1px solid var(--border);
  background: var(--surface-hi); color: var(--text); font-size: 13px; font-weight: 600; cursor: pointer;
}
.stream-log {
  min-height: 240px; max-height: 420px; overflow-y: auto;
  display: flex; flex-direction: column; gap: 8px; padding: 12px;
  background: rgba(2, 7, 16, 0.7); border-radius: 14px; border: 1px solid var(--border);
}
.bubble { padding: 10px 14px; border-radius: 12px; font-size: 13px; line-height: 1.5; max-width: 86%; }
.bubble.user { align-self: flex-end; background: rgba(47, 107, 255, 0.3); border: 1px solid var(--blue); }
.bubble.ai { align-self: flex-start; background: var(--surface-hi); border: 1px solid var(--border); }
.bubble.sys { align-self: center; font-size: 12px; color: var(--amber); background: rgba(240, 190, 106, 0.12); }
.input-bar { display: flex; gap: 8px; }
input, textarea, select {
  width: 100%; padding: 11px 14px; border-radius: 12px; border: 1px solid var(--border);
  background: #040C1C; color: var(--text); font-size: 13px; outline: none;
}
.card-head { display: flex; justify-content: space-between; align-items: center; }
.muted { color: var(--muted); font-size: 12px; }
.media-preview-row { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
.preview-video { width: 220px; border-radius: 12px; border: 1px solid var(--cyan); }
.code-viewer {
  background: #02060E; color: var(--green); font-family: monospace; font-size: 12px;
  padding: 12px; border-radius: 12px; border: 1px solid var(--border); max-height: 260px; overflow: auto; white-space: pre-wrap;
}
.preview-frame { width: 100%; height: 320px; border-radius: 12px; border: 1px solid var(--border); background: #fff; }
"""

    private const val T_WEB_AI_SCRIPT_JS = """
const KEY_STORAGE = "nisu_web_ai_key";
const MODEL_STORAGE = "nisu_web_ai_model";
const VOICE_STORAGE = "nisu_web_ai_voice";
const PERSONA_STORAGE = "nisu_web_ai_persona";

let webWs = null;
let webLiveOn = false;
let webAudioCtx = null;
let webMicStream = null;
let webMicProc = null;
let webNextPlay = 0;
let screenStream = null;
let screenTimer = null;
let camStream = null;
let camTimer = null;
let lastWebCode = "";

window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("webApiKey").value = localStorage.getItem(KEY_STORAGE) || "";
  document.getElementById("webModelSelect").value = localStorage.getItem(MODEL_STORAGE) || "gemini-2.5-flash-native-audio-preview-12-2025";
  document.getElementById("webVoiceSelect").value = localStorage.getItem(VOICE_STORAGE) || "__VOICE__";
  const p = localStorage.getItem(PERSONA_STORAGE);
  if (p) document.getElementById("webPersonaInput").value = p;
});

function switchWebTab(tab) {
  ["voice", "chat", "code", "settings"].forEach(t => {
    document.getElementById("tab-" + t).classList.toggle("active", t === tab);
    document.querySelector(`.tab-btn[data-tab="${'$'}{t}"]`)?.classList.toggle("active", t === tab);
  });
}

function openKeyModal() { switchWebTab("settings"); }

function getWebKey() {
  return (localStorage.getItem(KEY_STORAGE) || document.getElementById("webApiKey").value || "").trim();
}

function saveWebApiKey() {
  const k = document.getElementById("webApiKey").value.trim();
  localStorage.setItem(KEY_STORAGE, k);
  document.getElementById("webKeyStatus").textContent = k ? "✅ Gemini API Key saved!" : "Key cleared.";
}

function saveWebSettings() {
  localStorage.setItem(MODEL_STORAGE, document.getElementById("webModelSelect").value);
  localStorage.setItem(VOICE_STORAGE, document.getElementById("webVoiceSelect").value);
  localStorage.setItem(PERSONA_STORAGE, document.getElementById("webPersonaInput").value);
}

async function testWebApiKey() {
  const k = getWebKey();
  const st = document.getElementById("webKeyStatus");
  if (!k) { st.textContent = "❌ Enter an API key first."; return; }
  st.textContent = "⏳ Testing key...";
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=5&key=" + encodeURIComponent(k));
    st.textContent = r.ok ? "✅ Key verified! Ready for Gemini Live & Coding." : "❌ Invalid API Key (HTTP " + r.status + ").";
  } catch (e) {
    st.textContent = "❌ Error: " + e.message;
  }
}

function addBubble(boxId, role, text) {
  const box = document.getElementById(boxId);
  const d = document.createElement("div");
  d.className = "bubble " + role;
  d.textContent = text;
  box.appendChild(d);
  box.scrollTop = box.scrollHeight;
}

function webToolsDeclaration() {
  return [{
    functionDeclarations: [
      {
        name: "read_screen_context",
        description: "Read the current page text and visible screen information.",
        parameters: { type: "OBJECT", properties: {} }
      },
      {
        name: "open_website_url",
        description: "Open a URL in a new browser tab.",
        parameters: { type: "OBJECT", properties: { url: { type: "STRING" } }, required: ["url"] }
      },
      {
        name: "generate_live_code",
        description: "Write or update code in the Live Coding Studio.",
        parameters: { type: "OBJECT", properties: { prompt: { type: "STRING" }, self_update: { type: "BOOLEAN" } }, required: ["prompt"] }
      }
    ]
  }];
}

async function runWebTool(name, args) {
  if (name === "read_screen_context") {
    return { ok: true, title: document.title, visible_text: document.body.innerText.slice(0, 2500) };
  }
  if (name === "open_website_url" && args.url) {
    const u = args.url.startsWith("http") ? args.url : "https://" + args.url;
    window.open(u, "_blank");
    return { ok: true, opened: u };
  }
  if (name === "generate_live_code") {
    document.getElementById("webCodePrompt").value = args.prompt || "";
    switchWebTab("code");
    generateWebCode(Boolean(args.self_update));
    return { ok: true, status: "Code generation started in Live Coding Studio." };
  }
  return { ok: false, error: "Unknown tool " + name };
}

async function toggleWebLive() {
  if (webLiveOn) { stopWebLive(); return; }
  const key = getWebKey();
  if (!key) {
    switchWebTab("settings");
    addBubble("webLiveLog", "sys", "Please paste your Gemini API Key first (or click 'Get Free API Key').");
    return;
  }
  const model = document.getElementById("webModelSelect").value;
  const voice = document.getElementById("webVoiceSelect").value;
  const persona = document.getElementById("webPersonaInput").value;

  document.getElementById("webLiveStatus").textContent = "Connecting to Gemini Live...";
  const url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + encodeURIComponent(key);

  webWs = new WebSocket(url);
  webWs.onopen = () => {
    const gen = {
      responseModalities: ["AUDIO"],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } }
    };
    if (model.includes("2.5")) gen.thinkingConfig = { thinkingBudget: 0 };
    webWs.send(JSON.stringify({
      setup: {
        model: "models/" + model,
        generationConfig: gen,
        systemInstruction: { parts: [{ text: persona }] },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        tools: webToolsDeclaration()
      }
    }));
  };

  webWs.onmessage = async (ev) => {
    const raw = ev.data instanceof Blob ? await ev.data.text() : ev.data;
    let j;
    try { j = JSON.parse(raw); } catch (_) { return; }

    if (j.setupComplete) {
      webLiveOn = true;
      document.getElementById("webOrb").classList.add("live");
      document.getElementById("webLiveBtn").textContent = "⏹ Stop Live AI";
      document.getElementById("webLiveTitle").textContent = "Listening Live (" + voice + ")";
      document.getElementById("webLiveStatus").textContent = "Connected • Speak freely or share screen/camera";
      startWebMic();
      return;
    }

    if (j.serverContent) {
      const sc = j.serverContent;
      if (sc.interrupted && webAudioCtx) webNextPlay = webAudioCtx.currentTime;
      if (sc.inputTranscription?.text) addBubble("webLiveLog", "user", "You: " + sc.inputTranscription.text);
      if (sc.outputTranscription?.text) addBubble("webLiveLog", "ai", sc.outputTranscription.text);
      if (sc.modelTurn?.parts) {
        for (const p of sc.modelTurn.parts) {
          if (p.inlineData?.data) playWebPcm(p.inlineData.data);
        }
      }
    }

    if (j.toolCall?.functionCalls) {
      for (const fc of j.toolCall.functionCalls) {
        addBubble("webLiveLog", "sys", "⚡ Tool: " + fc.name);
        const res = await runWebTool(fc.name, fc.args || {});
        if (webWs && webWs.readyState === WebSocket.OPEN) {
          webWs.send(JSON.stringify({
            toolResponse: { functionResponses: [{ id: fc.id, name: fc.name, response: res }] }
          }));
        }
      }
    }
  };

  webWs.onclose = (e) => stopWebLive("Disconnected (" + e.code + ")");
  webWs.onerror = () => stopWebLive("Connection error — check API key");
}

function stopWebLive(msg) {
  webLiveOn = false;
  if (webWs) { try { webWs.close(); } catch (_) {} webWs = null; }
  if (webMicProc) { try { webMicProc.disconnect(); } catch (_) {} webMicProc = null; }
  if (webMicStream) { try { webMicStream.getTracks().forEach(t => t.stop()); } catch (_) {} webMicStream = null; }
  document.getElementById("webOrb").classList.remove("live");
  document.getElementById("webLiveBtn").textContent = "▶ Start Live AI";
  document.getElementById("webLiveTitle").textContent = "Tap Orb to Start Gemini Live Voice";
  document.getElementById("webLiveStatus").textContent = msg || "Stopped";
}

async function startWebMic() {
  try {
    if (!webAudioCtx) webAudioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    if (webAudioCtx.state === "suspended") await webAudioCtx.resume();
    webMicStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const src = webAudioCtx.createMediaStreamSource(webMicStream);
    const proc = webAudioCtx.createScriptProcessor(2048, 1, 1);
    proc.onaudioprocess = (e) => {
      if (!webLiveOn || !webWs || webWs.readyState !== WebSocket.OPEN) return;
      const input = e.inputBuffer.getChannelData(0);
      const ratio = webAudioCtx.sampleRate / 16000;
      const len = Math.floor(input.length / ratio);
      const pcm = new Int16Array(len);
      for (let i = 0; i < len; i++) {
        const s = Math.max(-1, Math.min(1, input[Math.floor(i * ratio)]));
        pcm[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }
      const bytes = new Uint8Array(pcm.buffer);
      let bin = "";
      for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
      webWs.send(JSON.stringify({
        realtimeInput: { audio: { mimeType: "audio/pcm;rate=16000", data: btoa(bin) } }
      }));
    };
    src.connect(proc);
    proc.connect(webAudioCtx.destination);
    webMicProc = proc;
  } catch (e) {
    addBubble("webLiveLog", "sys", "Microphone error: " + e.message);
  }
}

function playWebPcm(b64) {
  try {
    if (!webAudioCtx) webAudioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    const bin = atob(b64);
    const n = Math.floor(bin.length / 2);
    const buf = webAudioCtx.createBuffer(1, n, 24000);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) {
      let v = (bin.charCodeAt(i * 2 + 1) << 8) | bin.charCodeAt(i * 2);
      if (v >= 0x8000) v -= 0x10000;
      ch[i] = v / 32768.0;
    }
    const src = webAudioCtx.createBufferSource();
    src.buffer = buf;
    src.connect(webAudioCtx.destination);
    const now = webAudioCtx.currentTime;
    if (webNextPlay < now) webNextPlay = now + 0.02;
    src.start(webNextPlay);
    webNextPlay += buf.duration;
  } catch (_) {}
}

function sendWebLiveText() {
  const inp = document.getElementById("webLiveInput");
  const t = inp.value.trim();
  if (!t) return;
  inp.value = "";
  addBubble("webLiveLog", "user", "You: " + t);
  if (webWs && webWs.readyState === WebSocket.OPEN) {
    webWs.send(JSON.stringify({
      clientContent: { turns: [{ role: "user", parts: [{ text: t }] }], turnComplete: true }
    }));
  } else {
    document.getElementById("webChatInput").value = t;
    switchWebTab("chat");
    sendWebChat();
  }
}

async function toggleWebScreenShare() {
  const btn = document.getElementById("webScreenBtn");
  const vid = document.getElementById("webScreenVideo");
  if (screenTimer) {
    clearInterval(screenTimer); screenTimer = null;
    if (screenStream) { screenStream.getTracks().forEach(t => t.stop()); screenStream = null; }
    vid.style.display = "none";
    btn.textContent = "🖥️ Read Screen: OFF";
    return;
  }
  try {
    screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    vid.srcObject = screenStream;
    vid.style.display = "block";
    btn.textContent = "🖥️ Read Screen: ON";
    const c = document.createElement("canvas");
    c.width = 640; c.height = 360;
    const ctx = c.getContext("2d");
    screenTimer = setInterval(() => {
      if (!webLiveOn || !webWs || webWs.readyState !== WebSocket.OPEN) return;
      ctx.drawImage(vid, 0, 0, c.width, c.height);
      const b64 = c.toDataURL("image/jpeg", 0.65).split(",")[1];
      webWs.send(JSON.stringify({ realtimeInput: { video: { mimeType: "image/jpeg", data: b64 } } }));
    }, 1500);
  } catch (e) {
    addBubble("webLiveLog", "sys", "Screen share note: " + e.message + " — falling back to DOM screen reader.");
    analyzeCurrentScreenOnce();
  }
}

async function toggleWebCamera() {
  const btn = document.getElementById("webCamBtn");
  const vid = document.getElementById("webCamVideo");
  if (camTimer) {
    clearInterval(camTimer); camTimer = null;
    if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; }
    vid.style.display = "none";
    btn.textContent = "📷 Camera Eye: OFF";
    return;
  }
  try {
    camStream = await navigator.mediaDevices.getUserMedia({ video: { width: 480, height: 360 } });
    vid.srcObject = camStream;
    vid.style.display = "block";
    btn.textContent = "📷 Camera Eye: ON";
    const c = document.createElement("canvas");
    c.width = 480; c.height = 360;
    const ctx = c.getContext("2d");
    camTimer = setInterval(() => {
      if (!webLiveOn || !webWs || webWs.readyState !== WebSocket.OPEN) return;
      ctx.drawImage(vid, 0, 0, c.width, c.height);
      const b64 = c.toDataURL("image/jpeg", 0.65).split(",")[1];
      webWs.send(JSON.stringify({ realtimeInput: { video: { mimeType: "image/jpeg", data: b64 } } }));
    }, 1500);
  } catch (e) {
    addBubble("webLiveLog", "sys", "Camera error: " + e.message);
  }
}

function analyzeCurrentScreenOnce() {
  const txt = document.body.innerText.slice(0, 2000);
  addBubble("webLiveLog", "sys", "Screen Read Snapshot:\n" + txt.slice(0, 320) + "...");
  if (webWs && webWs.readyState === WebSocket.OPEN) {
    webWs.send(JSON.stringify({
      clientContent: { turns: [{ role: "user", parts: [{ text: "Read and summarize this screen content:\n" + txt }] }], turnComplete: true }
    }));
  }
}

async function sendWebChat() {
  const inp = document.getElementById("webChatInput");
  const t = inp.value.trim();
  if (!t) return;
  inp.value = "";
  addBubble("webChatLog", "user", t);
  const key = getWebKey();
  if (!key) { addBubble("webChatLog", "sys", "Please save your Gemini API Key in Settings first."); return; }
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: document.getElementById("webPersonaInput").value }] },
        contents: [{ role: "user", parts: [{ text: t }] }]
      })
    });
    const j = await r.json();
    const ans = j.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "No response";
    addBubble("webChatLog", "ai", ans);
  } catch (e) {
    addBubble("webChatLog", "sys", "Error: " + e.message);
  }
}

async function generateWebCode(selfUpdate) {
  const key = getWebKey();
  if (!key) { switchWebTab("settings"); return; }
  const prompt = document.getElementById("webCodePrompt").value.trim();
  if (!prompt) return;
  const out = document.getElementById("webCodeOutput");
  out.textContent = "⏳ Generating complete code with Gemini...";
  const sys = selfUpdate
    ? "You are the Self-Update Coding Engine for this Website AI. Return a complete single-file <!DOCTYPE html> version of this Website AI keeping all Gemini Live, API Key, Screen Read, and Coding Studio features while adding the user's requested update. No markdown fences."
    : "You are a senior web engineer. Write a complete, interactive single-file <!DOCTYPE html> web app for the user's request. No markdown fences.";
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: sys }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }]
      })
    });
    const j = await r.json();
    let code = j.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
    code = code.replace(/^```html\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/, "").trim();
    lastWebCode = code;
    out.textContent = code;
    document.getElementById("webCodePreview").srcdoc = code;
  } catch (e) {
    out.textContent = "Error: " + e.message;
  }
}

async function autoFixWebCode() {
  const issue = document.getElementById("webCodePrompt").value.trim() || "Fix all errors and make every feature work.";
  document.getElementById("webCodePrompt").value = "FIX ERRORS: " + issue + "\n\nCODE:\n" + lastWebCode;
  await generateWebCode(false);
}
"""
}
