package ai.nisu.assistant

import android.content.Context
import android.os.Build
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * v3.148: the premium key check against the Admin Panel (admin-panel.html), through a free Firebase Realtime Database (REST, no server code).
 *
 * Data (written by the Admin Panel): keys/<sha256(KEY)> = { code, plan, note, limit, duration_ms (0 = lifetime), status (active | disabled),
 * activated_at (server time of the first activation), slots { s1..sN : false (free) | "<device id>" }, devices { <device id>: {...} } }.
 * The key itself is never sent: the phone only asks for the record under the hash of the key, so keys cannot be listed. The device limit is enforced
 * by the database rules: a phone can only take a free slot (false -> its id), and the admin frees slots again.
 */
internal object LicenseLogic {
    fun normalize(key: String): String = key.trim().uppercase()

    /**
     * v3.149 anti-crack: a TIMED key (expiresAt > 0) is never allowed to have more than this left. A copy that shows more is treated as cracked
     * (edited phone data or a fake server) and blocks itself for good. Lifetime keys (expiresAt == 0) are NOT affected.
     * 62 days = "2 months" (+ a day of slack). NOTE: admin-panel.html also offers 90 / 180 / 365 day keys: those would trigger this too. Sell only
     * keys up to 2 months + Lifetime, or raise this number.
     */
    const val MAX_TIMED_KEY_MS = 62L * 24L * 3600L * 1000L

    fun looksCracked(expiresAt: Long, now: Long, maxMs: Long = MAX_TIMED_KEY_MS): Boolean = expiresAt > 0L && expiresAt - now > maxMs

    /** Must stay identical to keyHash() in admin-panel.html: SHA-256 (hex, lower case) of the trimmed, upper-case key. */
    fun hash(key: String): String =
        MessageDigest.getInstance("SHA-256").digest(normalize(key).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    /** 0 = lifetime, -1 = the timer has not started yet (nobody has activated the key), otherwise the end in epoch ms. */
    fun expiresAt(activatedAt: Long, durationMs: Long): Long = when {
        durationMs <= 0L -> 0L
        activatedAt <= 0L -> -1L
        else -> activatedAt + durationMs
    }

    private fun slotOrder(name: String): Int = name.drop(1).toIntOrNull() ?: Int.MAX_VALUE

    /** slots: slot name to device id (null = free slot). */
    fun ownSlot(deviceId: String, slots: Map<String, String?>): String? = slots.entries.firstOrNull { it.value == deviceId }?.key

    fun freeSlots(slots: Map<String, String?>): List<String> = slots.entries.filter { it.value == null }.map { it.key }.sortedBy { slotOrder(it) }

    fun usedCount(slots: Map<String, String?>): Int = slots.values.count { it != null }
}

internal object LicenseCloud {
    sealed class Outcome {
        class Valid(
            val plan: String, val note: String, val limit: Int, val used: Int, val expiresAt: Long, val serverTime: Long, val message: String
        ) : Outcome()
        class Invalid(val message: String) : Outcome()
        /** The phone could not reach the database (no internet, wrong URL). The old state stays as it is. */
        class Offline(val message: String) : Outcome()
    }

    private val http = Net.base.newBuilder()
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).writeTimeout(12, TimeUnit.SECONDS).build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private class Reply(val code: Int, val body: String, val serverTime: Long)

    private fun call(req: Request): Reply = http.newCall(req).execute().use { r ->
        Reply(r.code, r.body?.string().orEmpty().trim(), r.headers.getDate("Date")?.time ?: System.currentTimeMillis())
    }

    private fun get(base: String, path: String): Reply = call(Request.Builder().url("$base/$path.json").build())
    private fun put(base: String, path: String, json: String): Reply = call(Request.Builder().url("$base/$path.json").put(json.toRequestBody(JSON)).build())
    private fun patch(base: String, path: String, json: String): Reply = call(Request.Builder().url("$base/$path.json").patch(json.toRequestBody(JSON)).build())

    private fun slotsOf(rec: JSONObject): Map<String, String?> {
        val out = LinkedHashMap<String, String?>()
        val s = rec.optJSONObject("slots") ?: return out
        val it = s.keys()
        while (it.hasNext()) {
            val k = it.next()
            val v = s.opt(k)
            out[k] = if (v is String && v.isNotBlank()) v else null
        }
        return out
    }

    private fun record(r: Reply): JSONObject? = if (r.code == 200 && r.body.isNotEmpty() && r.body != "null") try { JSONObject(r.body) } catch (_: Exception) { null } else null

    /** v3.149: true when the database holds a block record for this phone (tamper/<device id>), so even a reinstall stays blocked. False when offline. */
    fun blockedInCloud(base: String, dev: String): Boolean = try {
        val r = get(base, "tamper/$dev")
        r.code == 200 && r.body.isNotEmpty() && r.body != "null"
    } catch (_: Exception) { false }

    /** v3.149: tells the admin (tamper/<device id>) that this phone blocked itself. Best effort. */
    fun reportTamper(ctx: Context, base: String, keyHash: String, why: String) {
        if (base.isEmpty()) return
        try {
            val body = JSONObject().put("at", JSONObject().put(".sv", "timestamp")).put("why", why.take(80)).put("key", keyHash.take(64))
                .put("name", PremiumGate.deviceName().take(70))
            put(base, "tamper/" + PremiumGate.deviceId(ctx), body.toString())
        } catch (_: Exception) {}
    }

    /** The public contact text of the admin ("config/contact"). Empty when there is none or the phone is offline. */
    fun contact(base: String): String = try {
        val r = get(base, "config/contact")
        if (r.code == 200 && r.body.startsWith("\"")) org.json.JSONTokener(r.body).nextValue() as? String ?: "" else ""
    } catch (_: Exception) { "" }

    /**
     * Checks one key for this phone. Blocking: call it on a worker thread. [firstWrite] = also write the device info (name, app version, last seen)
     * to the database (done on every manual activation and about every 10 minutes, not on every 45 s check).
     */
    fun check(ctx: Context, base: String, rawKey: String, firstWrite: Boolean): Outcome {
        if (base.isEmpty()) return Outcome.Offline("The license cloud is not set up in this app yet (CLOUD_DB_URL in PremiumGate.kt is empty).")
        val key = LicenseLogic.normalize(rawKey)
        val h = LicenseLogic.hash(key)
        val dev = PremiumGate.deviceId(ctx)
        try {
            var reply = get(base, "keys/$h")
            if (reply.code == 401 || reply.code == 403) return Outcome.Offline("The database refused the request (check the Firebase rules).")
            if (reply.code != 200) return Outcome.Offline("The license database answered with error ${reply.code}.")
            var rec = record(reply) ?: return Outcome.Invalid("This Premium Key does not exist. Check it and try again.")
            if (rec.optString("status", "active") != "active") return Outcome.Invalid("This Premium Key was disabled by the admin.")

            var slots = slotsOf(rec)
            var changed = false
            // 1) take a device slot (the database rules only allow free -> this phone, so the limit cannot be passed)
            if (LicenseLogic.ownSlot(dev, slots) == null) {
                var taken = false
                for (s in LicenseLogic.freeSlots(slots)) {
                    val r = put(base, "keys/$h/slots/$s", "\"$dev\"")
                    if (r.code == 200) { taken = true; changed = true; break }
                    if (r.code != 401 && r.code != 403) return Outcome.Offline("The license database answered with error ${r.code}.")   // 401/403: another phone took it first, try the next one
                }
                if (!taken) {
                    // maybe it was granted a moment ago (retry of the same phone): look again before saying no
                    reply = get(base, "keys/$h")
                    rec = record(reply) ?: return Outcome.Invalid("This Premium Key does not exist. Check it and try again.")
                    slots = slotsOf(rec)
                    if (LicenseLogic.ownSlot(dev, slots) == null) {
                        val lim = rec.optInt("limit", slots.size)
                        return Outcome.Invalid("Device limit reached (${LicenseLogic.usedCount(slots)}/$lim phones use this key). Ask the admin to reset the devices.")
                    }
                }
            }
            // 2) the first activation starts the timer (server time, written once)
            if (rec.optLong("activated_at", 0L) <= 0L) {
                put(base, "keys/$h/activated_at", "{\".sv\":\"timestamp\"}")   // refused = somebody was first: fine
                changed = true
            }
            if (changed) {
                reply = get(base, "keys/$h")
                rec = record(reply) ?: return Outcome.Invalid("This Premium Key does not exist. Check it and try again.")
                if (rec.optString("status", "active") != "active") return Outcome.Invalid("This Premium Key was disabled by the admin.")
                slots = slotsOf(rec)
            }
            if (LicenseLogic.ownSlot(dev, slots) == null) return Outcome.Invalid("This phone could not be added to the key. Try again.")

            val dur = rec.optLong("duration_ms", 0L)
            val act = rec.optLong("activated_at", 0L)
            val exp = LicenseLogic.expiresAt(act, dur)
            if (exp == -1L) return Outcome.Offline("The key timer could not be started. Check the internet and try again.")   // timed key, but the first-activation write did not go through
            val now = reply.serverTime
            if (exp > 0L && now > exp) return Outcome.Invalid("Your Premium Key has expired! Activate again with a new key.")

            // 3) device info for the admin (best effort)
            if (firstWrite) {
                try {
                    val appVer = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
                    val body = JSONObject().put("name", PremiumGate.deviceName().take(70)).put("android", (Build.VERSION.RELEASE ?: "").take(15))
                        .put("app", appVer.take(15)).put("last_seen", JSONObject().put(".sv", "timestamp"))
                    if (!rec.optJSONObject("devices").let { it != null && it.has(dev) }) body.put("first_seen", JSONObject().put(".sv", "timestamp"))
                    patch(base, "keys/$h/devices/$dev", body.toString())
                } catch (_: Exception) {}
            }

            val plan = rec.optString("plan", "VIP Premium")
            val lim = rec.optInt("limit", slots.size)
            return Outcome.Valid(plan, rec.optString("note", ""), lim, LicenseLogic.usedCount(slots), exp, now, "Premium Key activated!")
        } catch (e: Exception) {
            return Outcome.Offline("Could not connect to the server! Check your internet connection.")
        }
    }
}
