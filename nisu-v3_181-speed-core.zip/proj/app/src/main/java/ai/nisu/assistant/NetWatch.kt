package ai.nisu.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.SystemClock

/**
 * v3.148: "connect the moment the internet comes". Started once in [NishuApp] (every process start, also when Android starts the app at boot).
 * When the phone gets a working internet connection (Wi-Fi or mobile data, also after a flight mode or a dead zone) it asks the Admin Panel
 * database at once: the premium key (revoked / extended / expired) or, without a key, the free talk time. It does not wait for the 45 second timer.
 */
object NetWatch {
    private var started = false
    private var lastRun = 0L
    @Volatile private var validated = false

    fun start(ctx: Context) {
        if (started) return
        val app = ctx.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { trigger(app) }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    val ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    if (ok && !validated) trigger(app)   // connected to Wi-Fi first, the internet itself works a moment later
                    validated = ok
                }
                override fun onLost(network: Network) { validated = false }
            })
            started = true
        } catch (_: Throwable) {}   // no permission / no connectivity service: the 45 s timer and the app opening still check
    }

    @Synchronized
    private fun trigger(ctx: Context) {
        val now = SystemClock.elapsedRealtime()
        if (lastRun != 0L && now - lastRun < 3000L) return   // several callbacks arrive together
        lastRun = now
        try {
            if (PremiumGate.hasSavedKey(ctx)) PremiumGate.verifyWithServer(ctx, silent = true)
            else FreeTier.sync(ctx, force = true)
            PremiumGate.refreshContact(ctx)
        } catch (_: Throwable) {}
    }
}
