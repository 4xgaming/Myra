plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "ai.nisu.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "ai.nisu.assistant"
        minSdk = 26          // Android 8.0
        targetSdk = 35       // runs on Android 8 ... 16
        versionCode = 186
        versionName = "3.181"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.apache.commons:commons-compress:1.26.2")   // v3.76: opens 7z archives (no password) in the built-in file manager
    implementation("org.tukaani:xz:1.9")
    testImplementation("junit:junit:4.13.2")   // v2.21: JVM unit tests for the wake / sleep parser and the mode state machine
}
