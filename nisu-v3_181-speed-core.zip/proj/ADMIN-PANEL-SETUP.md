# Premium keys + Admin Panel (v3.148 work)

Two parts that talk to the same free Firebase Realtime Database (REST, no server to host):

1. `admin-panel.html` - one file. Open it in any HTML runner / browser. Generate keys, disable / extend / delete, reset devices, see free users.
2. This app - `PremiumGate.kt` + `LicenseCloud.kt` check the key; `FreeTier.kt` keeps the free minutes in the same database; `NetWatch.kt` asks the database the moment internet comes back.

## One-time setup (about 10 minutes, all from a phone browser)

1. https://console.firebase.google.com -> Add project (Analytics off) -> **Build > Realtime Database > Create Database** (test mode). Copy the URL, e.g. `https://nisu-ai-default-rtdb.firebaseio.com`.
   - If you already did FREE-TIER-SETUP.md, use that same project.
2. **Build > Authentication > Get started > Sign-in method > Email/Password > Enable.** Then **Users > Add user** (your admin email + password). Copy that user's **User UID**.
3. **Project settings (gear) > General > Web API Key** - copy it.
4. Open `firebase-rules.json`, replace every `PUT_YOUR_ADMIN_UID_HERE` with your UID (or sign in to the panel first: **Settings > Security rules** shows the rules with your UID already filled in). Paste into **Realtime Database > Rules > Publish**.
5. In `app/src/main/java/ai/nisu/assistant/PremiumGate.kt` set `const val CLOUD_DB_URL = "https://....firebaseio.com"` (no slash at the end). Build and install the APK.
6. Open `admin-panel.html`, enter: database URL, Web API key, admin email, password. Make a key in **Keys > Generate**, paste it in the app.

## How it works

- Key lookup is by `sha256(KEY)`: `keys/<hash>`. The app never lists keys; only the admin (signed in) can list them.
- Duration starts at the first activation (server time). `0` = lifetime.
- Device limit: the key has slots `s1..sN` (`false` = free). A phone can only change a free slot to its own device id, and only the admin can free it again (Reset devices / Remove this device).
- Disable / delete / expiry: the app re-checks when it opens, every ~45 s, and at once when the internet returns (`NetWatch`). Offline, an already activated key keeps working until its end time.
- Free users: `free/<device id>`. Rules make the used time only go up, except after the 6 hours. Panel **Free users** tab can reset a phone.

## Honest limits

- Not compiled or run on Android (no Android SDK here). `LicenseLogicTest` covers the hash / expiry / slot logic. The admin panel was tested in a browser against a mock Firebase; the **security rules were not run against real Firebase** - after publishing them, test once: activate a key on a phone, activate it on a 2nd phone with limit 1 (must be refused), disable the key (phone locks within about a minute).
- The database URL is fixed in the APK on purpose (it was editable on the lock screen before: a phone could point itself to its own database and give itself a key).
- No server means no secret on the phone side: someone who edits and re-signs the APK can still remove the check. This stops key sharing and clock tricks, not APK patching.
- Version number was not bumped (`build.gradle.kts` still 3.147 / 158).

## v3.149: crack protection (self-block)

- A TIMED key may have at most 2 months (62 days) left. If the app sees more (edited phone data, or a fake server), it removes the key, stops every service, shows only the "COPY BLOCKED" screen (no free minutes either) and writes `tamper/<device id>` to the database. **Lifetime keys are never affected.**
- **Admin-panel keys of 90 / 180 / 365 days also trigger this.** Do not sell them, or raise `LicenseLogic.MAX_TIMED_KEY_MS` in `LicenseCloud.kt`.
- Republish `firebase-rules.json` (it now has a `tamper` node) and set your admin uid in it, otherwise the block record cannot be written.
- To unblock a genuine customer: Firebase console > Realtime Database > Data > `tamper` > delete the device id, then the customer does Settings > Apps > NISU AI > Clear data (or reinstalls).
